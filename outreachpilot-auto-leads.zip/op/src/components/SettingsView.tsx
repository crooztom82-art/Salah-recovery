import React, { useState } from "react";
import { AppSettings, Prospect, SearchProviderConfig } from "../types";
import {
  Link2,
  User,
  ShieldCheck,
  RotateCcw,
  Download,
  Upload,
  Check,
  Save,
  Moon,
  Sun,
  ExternalLink,
  Info,
  Search,
  Key,
  Sliders,
  Clock,
  FileText,
  HelpCircle,
  Globe,
  Sparkles
} from "lucide-react";
import { SAMPLE_PROSPECTS } from "../data/sampleProspects";
import { WORLD_COUNTRIES } from "../data/countries";

interface SettingsViewProps {
  settings: AppSettings;
  onUpdateSettings: (newSettings: AppSettings) => void;
  prospects: Prospect[];
  onResetData: (prospects: Prospect[]) => void;
  onShowToast: (msg: string, type: "success" | "error" | "info") => void;
  darkMode: boolean;
  onToggleDarkMode: () => void;
}

const COMMON_NICHES = [
  "Fitness & Wellness Coaching",
  "Life Coaching & Personal Growth",
  "Business & Executive Consulting",
  "Digital Marketing & Social Media Agency",
  "Course Creators & Online Educators",
  "Finance & Wealth Advisory",
  "Career & Resume Coaching",
  "Creative & Design Services"
];

const COUNTRIES = WORLD_COUNTRIES;

export const SettingsView: React.FC<SettingsViewProps> = ({
  settings,
  onUpdateSettings,
  prospects,
  onResetData,
  onShowToast,
  darkMode,
  onToggleDarkMode
}) => {
  // Affiliate & Sender
  const [affiliateLink, setAffiliateLink] = useState(settings.affiliateLink || settings.systemeAffiliateLink || "");
  const [userName, setUserName] = useState(settings.userName || "");
  const [userEmail, setUserEmail] = useState(settings.userEmail || "");
  const [userRole, setUserRole] = useState(settings.userRole || "Funnel & Automation Consultant");
  const [defaultOutreachTone, setDefaultOutreachTone] = useState(settings.defaultOutreachTone || "Helpful & Professional");

  // Search & Discovery Provider
  const [providerType, setProviderType] = useState<"google_custom_search" | "serpapi" | "google_places" | "gemini_google_search" | "direct_search">(
    (settings.searchProvider?.provider as any) || "google_custom_search"
  );
  const [providerApiKey, setProviderApiKey] = useState(settings.searchProvider?.apiKey || "");
  const [providerCx, setProviderCx] = useState(settings.searchProvider?.searchEngineId || "");
  const [showKey, setShowKey] = useState(false);

  // AI & Discovery Filters
  const [autoAnalyzeNewProspects, setAutoAnalyzeNewProspects] = useState(settings.autoAnalyzeNewProspects ?? true);
  const [minimumFitScore, setMinimumFitScore] = useState<number>(settings.minimumFitScore ?? 70);
  const [defaultTargetCountry, setDefaultTargetCountry] = useState(settings.defaultTargetCountry || "United States");
  const [defaultNiches, setDefaultNiches] = useState<string[]>(
    settings.defaultNiches && settings.defaultNiches.length > 0
      ? settings.defaultNiches
      : ["Fitness & Wellness Coaching", "Business & Executive Consulting", "Course Creators & Online Educators"]
  );

  // Disclosure
  const [includeAffiliateDisclosure, setIncludeAffiliateDisclosure] = useState(
    settings.includeAffiliateDisclosure ?? true
  );
  const [affiliateDisclosureText, setAffiliateDisclosureText] = useState(
    settings.affiliateDisclosureText ||
      "Transparency note: If you decide to test the recommended platform, my link includes partner benefits and supports my consulting work at zero additional cost to you."
  );

  // Follow-up timing
  const [followUpDelayDaysStep1, setFollowUpDelayDaysStep1] = useState(settings.followUpDelayDaysStep1 ?? 3);
  const [followUpDelayDaysStep2, setFollowUpDelayDaysStep2] = useState(settings.followUpDelayDaysStep2 ?? 4);
  const [followUpDelayDaysStep3, setFollowUpDelayDaysStep3] = useState(settings.followUpDelayDaysStep3 ?? 5);

  const toggleNiche = (niche: string) => {
    if (defaultNiches.includes(niche)) {
      setDefaultNiches(defaultNiches.filter((n) => n !== niche));
    } else {
      setDefaultNiches([...defaultNiches, niche]);
    }
  };

  const handleSave = (e: React.FormEvent) => {
    e.preventDefault();

    const searchProviderConfig: SearchProviderConfig = {
      provider: providerType,
      apiKey: providerApiKey.trim(),
      searchEngineId: providerCx.trim(),
      isConfigured:
        providerType === "serpapi"
          ? Boolean(providerApiKey.trim())
          : providerType === "google_custom_search"
          ? Boolean(providerApiKey.trim() && providerCx.trim())
          : providerType === "google_places"
          ? Boolean(providerApiKey.trim())
          : providerType === "gemini_google_search"
          ? true
          : true
    };

    const newSettings: AppSettings = {
      ...settings,
      affiliateLink: affiliateLink.trim(),
      systemeAffiliateLink: affiliateLink.trim(),
      userName: userName.trim(),
      userEmail: userEmail.trim(),
      userRole: userRole.trim(),
      defaultOutreachTone,
      autoAnalyzeNewProspects,
      searchProvider: searchProviderConfig,
      minimumFitScore,
      defaultTargetCountry,
      defaultNiches,
      includeAffiliateDisclosure,
      affiliateDisclosureText: affiliateDisclosureText.trim(),
      followUpDelayDaysStep1: Number(followUpDelayDaysStep1),
      followUpDelayDaysStep2: Number(followUpDelayDaysStep2),
      followUpDelayDaysStep3: Number(followUpDelayDaysStep3)
    };

    onUpdateSettings(newSettings);
    onShowToast("Settings and discovery preferences saved!", "success");
  };

  const handleExportJSON = () => {
    const dataStr = JSON.stringify({ settings, prospects }, null, 2);
    const blob = new Blob([dataStr], { type: "application/json" });
    const url = URL.createObjectURL(blob);
    const link = document.createElement("a");
    link.href = url;
    link.download = `outreachpilot-backup-${new Date().toISOString().slice(0, 10)}.json`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);
    onShowToast("Complete CRM backup exported!", "success");
  };

  const handleResetToSample = () => {
    if (confirm("Reset current prospect list back to sample data? (All custom prospect records will be replaced)")) {
      onResetData(SAMPLE_PROSPECTS);
      onShowToast("Prospect list reset to sample records.", "info");
    }
  };

  return (
    <div id="settings-view" className="max-w-4xl mx-auto space-y-6 pb-20">
      <div>
        <h1 className="text-2xl font-extrabold text-slate-900 dark:text-white tracking-tight">
          Settings & Configuration
        </h1>
        <p className="text-xs sm:text-sm text-slate-500 dark:text-slate-400 mt-0.5">
          Configure discovery search providers, AI qualification thresholds, affiliate link, and ethical disclosure
        </p>
      </div>

      <form onSubmit={handleSave} className="space-y-6">
        {/* 1. Affiliate / Partner Link Section */}
        <div className="bg-white dark:bg-slate-900 p-5 sm:p-6 rounded-3xl border border-slate-200/80 dark:border-slate-800 shadow-sm space-y-4">
          <div className="flex items-center gap-2 text-indigo-600 dark:text-indigo-400">
            <Link2 className="w-5 h-5" />
            <h2 className="text-base font-bold text-slate-900 dark:text-white">
              Affiliate / Partner Link
            </h2>
          </div>
          <p className="text-xs text-slate-500 dark:text-slate-400 leading-relaxed">
            Your personal partner or affiliate referral link. Automatically integrated into generated outreach, follow-ups, and one-click copy blocks.
          </p>

          <div>
            <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1">
              Your Referral / Partner Link
            </label>
            <input
              type="text"
              id="settings-affiliate-link-input"
              value={affiliateLink}
              onChange={(e) => setAffiliateLink(e.target.value)}
              placeholder="https://example.com/partner/?ref=your_id"
              className="w-full px-4 py-2.5 text-sm rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-900 dark:text-white focus:ring-2 focus:ring-indigo-500 focus:outline-none min-h-[44px]"
            />
          </div>

          <div className="p-3.5 rounded-2xl bg-indigo-50/60 dark:bg-indigo-950/40 border border-indigo-100 dark:border-indigo-900/40 flex items-start gap-2.5 text-xs text-indigo-900 dark:text-indigo-200">
            <Info className="w-4 h-4 shrink-0 text-indigo-600 dark:text-indigo-400 mt-0.5" />
            <span>
              Ethical guideline: Lead with practical funnel problem-solving rather than sales pitching. Mention your link when the prospect expresses interest in simplifying their tech stack or cutting monthly software costs.
            </span>
          </div>
        </div>

        {/* 2. Prospect Discovery & Search Provider */}
        <div className="bg-white dark:bg-slate-900 p-5 sm:p-6 rounded-3xl border border-slate-200/80 dark:border-slate-800 shadow-sm space-y-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2 text-indigo-600 dark:text-indigo-400">
              <Search className="w-5 h-5" />
              <h2 className="text-base font-bold text-slate-900 dark:text-white">
                Prospect Discovery Provider
              </h2>
            </div>
            <span className="text-[11px] px-2 py-0.5 rounded-full bg-emerald-50 dark:bg-emerald-950 text-emerald-700 dark:text-emerald-300 font-semibold border border-emerald-200 dark:border-emerald-800">
              Public Search Only
            </span>
          </div>
          <p className="text-xs text-slate-500 dark:text-slate-400 leading-relaxed">
            Choose how OutreachPilot finds public business profiles, coaches, and course creators. OutreachPilot accesses only open search engine results—no private scraping or CAPTCHA bypass.
          </p>

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
            <button
              type="button"
              onClick={() => setProviderType("gemini_google_search")}
              className={`p-3.5 rounded-2xl border text-left transition-all ${
                providerType === "gemini_google_search"
                  ? "border-indigo-600 bg-indigo-50/50 dark:bg-indigo-950/30 text-indigo-900 dark:text-white font-bold"
                  : "border-slate-200 dark:border-slate-800 hover:border-slate-300 dark:hover:border-slate-700 text-slate-700 dark:text-slate-300"
              }`}
            >
              <div className="text-xs font-bold mb-1">Built-in Live Web Search</div>
              <div className="text-[11px] text-slate-500 dark:text-slate-400 font-normal">
                Uses Gemini + Google Search grounding; no separate search API key
              </div>
            </button>

            <button
              type="button"
              onClick={() => setProviderType("google_custom_search")}
              className={`p-3.5 rounded-2xl border text-left transition-all ${
                providerType === "google_custom_search"
                  ? "border-indigo-600 bg-indigo-50/50 dark:bg-indigo-950/30 text-indigo-900 dark:text-white font-bold"
                  : "border-slate-200 dark:border-slate-800 hover:border-slate-300 dark:hover:border-slate-700 text-slate-700 dark:text-slate-300"
              }`}
            >
              <div className="text-xs font-bold mb-1">Google Custom Search</div>
              <div className="text-[11px] text-slate-500 dark:text-slate-400 font-normal">
                100 free searches/day via Google Programmable Engine
              </div>
            </button>

            <button
              type="button"
              onClick={() => setProviderType("serpapi")}
              className={`p-3.5 rounded-2xl border text-left transition-all ${
                providerType === "serpapi"
                  ? "border-indigo-600 bg-indigo-50/50 dark:bg-indigo-950/30 text-indigo-900 dark:text-white font-bold"
                  : "border-slate-200 dark:border-slate-800 hover:border-slate-300 dark:hover:border-slate-700 text-slate-700 dark:text-slate-300"
              }`}
            >
              <div className="text-xs font-bold mb-1">SerpApi (Google Search)</div>
              <div className="text-[11px] text-slate-500 dark:text-slate-400 font-normal">
                Fast Google Search scraping API (100 free searches/mo)
              </div>
            </button>

            <button
              type="button"
              onClick={() => setProviderType("google_places")}
              className={`p-3.5 rounded-2xl border text-left transition-all ${
                providerType === "google_places"
                  ? "border-indigo-600 bg-indigo-50/50 dark:bg-indigo-950/30 text-indigo-900 dark:text-white font-bold"
                  : "border-slate-200 dark:border-slate-800 hover:border-slate-300 dark:hover:border-slate-700 text-slate-700 dark:text-slate-300"
              }`}
            >
              <div className="text-xs font-bold mb-1">Google Places</div>
              <div className="text-[11px] text-slate-500 dark:text-slate-400 font-normal">
                Real business/place search with website and location data
              </div>
            </button>

            <button
              type="button"
              onClick={() => setProviderType("direct_search")}
              className={`p-3.5 rounded-2xl border text-left transition-all ${
                providerType === "direct_search"
                  ? "border-indigo-600 bg-indigo-50/50 dark:bg-indigo-950/30 text-indigo-900 dark:text-white font-bold"
                  : "border-slate-200 dark:border-slate-800 hover:border-slate-300 dark:hover:border-slate-700 text-slate-700 dark:text-slate-300"
              }`}
            >
              <div className="text-xs font-bold mb-1">Direct Guided Search</div>
              <div className="text-[11px] text-slate-500 dark:text-slate-400 font-normal">
                No API key needed; launches pre-crafted queries & quick add
              </div>
            </button>
          </div>

          {/* Configuration fields depending on selected provider */}
          {providerType === "gemini_google_search" && (
            <div className="space-y-3 pt-2">
              <div className="p-3.5 rounded-2xl bg-emerald-50 dark:bg-emerald-950/20 border border-emerald-200 dark:border-emerald-900/40 text-xs text-slate-700 dark:text-slate-300">
                <div className="font-bold text-emerald-800 dark:text-emerald-300 mb-1">Automatic lead discovery</div>
                <p>OutreachPilot will ask Gemini to search the live public web for real businesses matching your country, city, niche and keywords. It will only keep candidates with a public website URL and will not invent missing leads.</p>
                <p className="mt-2">No separate search API key is entered here. The app uses its server-side Gemini configuration.</p>
              </div>
            </div>
          )}

          {providerType === "google_custom_search" && (
            <div className="space-y-3 pt-2">
              <div>
                <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1">
                  Google Cloud Search API Key
                </label>
                <div className="relative">
                  <input
                    type={showKey ? "text" : "password"}
                    value={providerApiKey}
                    onChange={(e) => setProviderApiKey(e.target.value)}
                    placeholder="AIzaSy..."
                    className="w-full px-4 py-2.5 text-sm rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-900 dark:text-white focus:ring-2 focus:ring-indigo-500 focus:outline-none min-h-[44px]"
                  />
                  <button
                    type="button"
                    onClick={() => setShowKey(!showKey)}
                    className="absolute right-3 top-1/2 -translate-y-1/2 text-xs text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 font-medium"
                  >
                    {showKey ? "Hide" : "Show"}
                  </button>
                </div>
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1">
                  Custom Search Engine ID (CX)
                </label>
                <input
                  type="text"
                  value={providerCx}
                  onChange={(e) => setProviderCx(e.target.value)}
                  placeholder="e.g. 0123456789abcdefg:hijklmnop"
                  className="w-full px-4 py-2.5 text-sm rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-900 dark:text-white focus:ring-2 focus:ring-indigo-500 focus:outline-none min-h-[44px]"
                />
              </div>

              <p className="text-[11px] text-slate-500 dark:text-slate-400">
                You can create a free Google Custom Search Engine at{" "}
                <a
                  href="https://programmablesearchengine.google.com/"
                  target="_blank"
                  rel="noreferrer"
                  className="text-indigo-600 underline inline-flex items-center gap-0.5"
                >
                  programmablesearchengine.google.com
                  <ExternalLink className="w-3 h-3" />
                </a>{" "}
                (select "Search the entire web" = ON).
              </p>
            </div>
          )}

          {providerType === "google_places" && (
            <div className="space-y-3 pt-2">
              <div>
                <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1">
                  Google Maps Platform API Key
                </label>
                <div className="relative">
                  <input
                    type={showKey ? "text" : "password"}
                    value={providerApiKey}
                    onChange={(e) => setProviderApiKey(e.target.value)}
                    placeholder="AIzaSy..."
                    className="w-full px-4 py-2.5 text-sm rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-900 dark:text-white focus:ring-2 focus:ring-indigo-500 focus:outline-none min-h-[44px]"
                  />
                  <button
                    type="button"
                    onClick={() => setShowKey(!showKey)}
                    className="absolute right-3 top-1/2 -translate-y-1/2 text-xs text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 font-medium"
                  >
                    {showKey ? "Hide" : "Show"}
                  </button>
                </div>
              </div>
              <p className="text-[11px] text-slate-500 dark:text-slate-400">
                Enable Places API (New) for your Google Cloud project, create an API key, and restrict the key to the Places API. Google requires billing for production Places API usage.
              </p>
            </div>
          )}

          {providerType === "serpapi" && (
            <div className="space-y-3 pt-2">
              <div>
                <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1">
                  SerpApi Private Key
                </label>
                <div className="relative">
                  <input
                    type={showKey ? "text" : "password"}
                    value={providerApiKey}
                    onChange={(e) => setProviderApiKey(e.target.value)}
                    placeholder="Enter your SerpApi API key..."
                    className="w-full px-4 py-2.5 text-sm rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-900 dark:text-white focus:ring-2 focus:ring-indigo-500 focus:outline-none min-h-[44px]"
                  />
                  <button
                    type="button"
                    onClick={() => setShowKey(!showKey)}
                    className="absolute right-3 top-1/2 -translate-y-1/2 text-xs text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 font-medium"
                  >
                    {showKey ? "Hide" : "Show"}
                  </button>
                </div>
              </div>
              <p className="text-[11px] text-slate-500 dark:text-slate-400">
                Get a free key (100 searches/month) at{" "}
                <a
                  href="https://serpapi.com"
                  target="_blank"
                  rel="noreferrer"
                  className="text-indigo-600 underline inline-flex items-center gap-0.5"
                >
                  serpapi.com
                  <ExternalLink className="w-3 h-3" />
                </a>
              </p>
            </div>
          )}

          {providerType === "direct_search" && (
            <div className="p-3.5 rounded-2xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-xs text-slate-600 dark:text-slate-300">
              When Find Prospects is run, OutreachPilot generates Google-optimized targeted search links that open in a new tab. You can then quickly paste public business URLs to auto-analyze candidates.
            </div>
          )}
        </div>

        {/* 3. AI Analysis & Qualification Defaults */}
        <div className="bg-white dark:bg-slate-900 p-5 sm:p-6 rounded-3xl border border-slate-200/80 dark:border-slate-800 shadow-sm space-y-4">
          <div className="flex items-center gap-2 text-indigo-600 dark:text-indigo-400">
            <Sparkles className="w-5 h-5" />
            <h2 className="text-base font-bold text-slate-900 dark:text-white">
              AI Qualification & Fit Score Thresholds
            </h2>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            {/* Minimum Fit Score */}
            <div>
              <div className="flex items-center justify-between mb-1">
                <label className="text-xs font-bold text-slate-700 dark:text-slate-300">
                  Minimum Fit Score Threshold
                </label>
                <span className="text-xs font-black text-indigo-600 dark:text-indigo-400">
                  {minimumFitScore}/100
                </span>
              </div>
              <input
                type="range"
                min={40}
                max={90}
                step={5}
                value={minimumFitScore}
                onChange={(e) => setMinimumFitScore(Number(e.target.value))}
                className="w-full accent-indigo-600 h-2 bg-slate-200 dark:bg-slate-700 rounded-lg cursor-pointer"
              />
              <p className="text-[11px] text-slate-400 mt-1">
                Prospects scoring above this threshold are highlighted as "High Potential" on your Dashboard.
              </p>
            </div>

            {/* Default Country */}
            <div>
              <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1">
                Default Target Country
              </label>
              <select
                value={defaultTargetCountry}
                onChange={(e) => setDefaultTargetCountry(e.target.value)}
                className="w-full px-3.5 py-2.5 text-sm rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-900 dark:text-white focus:ring-2 focus:ring-indigo-500 focus:outline-none min-h-[44px]"
              >
                {COUNTRIES.map((c) => (
                  <option key={c} value={c}>
                    {c}
                  </option>
                ))}
              </select>
            </div>
          </div>

          {/* Default Niches selection */}
          <div>
            <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1.5">
              Default Target Niches
            </label>
            <div className="flex flex-wrap gap-2">
              {COMMON_NICHES.map((niche) => {
                const isSelected = defaultNiches.includes(niche);
                return (
                  <button
                    key={niche}
                    type="button"
                    onClick={() => toggleNiche(niche)}
                    className={`px-3 py-1.5 rounded-xl text-xs font-medium transition-all ${
                      isSelected
                        ? "bg-indigo-600 text-white shadow-sm"
                        : "bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 hover:bg-slate-200 dark:hover:bg-slate-700"
                    }`}
                  >
                    {niche} {isSelected && "✓"}
                  </button>
                );
              })}
            </div>
          </div>

          <div className="flex items-center gap-2 pt-1">
            <input
              type="checkbox"
              id="auto-analyze-check"
              checked={autoAnalyzeNewProspects}
              onChange={(e) => setAutoAnalyzeNewProspects(e.target.checked)}
              className="w-4 h-4 text-indigo-600 rounded border-slate-300 focus:ring-indigo-500"
            />
            <label
              htmlFor="auto-analyze-check"
              className="text-xs text-slate-700 dark:text-slate-300 cursor-pointer font-medium"
            >
              Automatically prompt AI qualification analysis when adding or importing prospects
            </label>
          </div>
        </div>

        {/* 4. Sender Profile & Signature */}
        <div className="bg-white dark:bg-slate-900 p-5 sm:p-6 rounded-3xl border border-slate-200/80 dark:border-slate-800 shadow-sm space-y-4">
          <div className="flex items-center gap-2 text-indigo-600 dark:text-indigo-400">
            <User className="w-5 h-5" />
            <h2 className="text-base font-bold text-slate-900 dark:text-white">
              Sender Profile & Signature
            </h2>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
            <div>
              <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1">
                Your Full Name
              </label>
              <input
                type="text"
                value={userName}
                onChange={(e) => setUserName(e.target.value)}
                placeholder="e.g. Alex Rivera"
                className="w-full px-3.5 py-2.5 text-sm rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-900 dark:text-white focus:ring-2 focus:ring-indigo-500 focus:outline-none min-h-[44px]"
              />
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1">
                Your Professional Email
              </label>
              <input
                type="email"
                value={userEmail}
                onChange={(e) => setUserEmail(e.target.value)}
                placeholder="e.g. alex@funnelconsult.com"
                className="w-full px-3.5 py-2.5 text-sm rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-900 dark:text-white focus:ring-2 focus:ring-indigo-500 focus:outline-none min-h-[44px]"
              />
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1">
                Your Title / Consulting Focus
              </label>
              <input
                type="text"
                value={userRole}
                onChange={(e) => setUserRole(e.target.value)}
                placeholder="e.g. Online Course Architect"
                className="w-full px-3.5 py-2.5 text-sm rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-900 dark:text-white focus:ring-2 focus:ring-indigo-500 focus:outline-none min-h-[44px]"
              />
            </div>
          </div>

          <div>
            <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1">
              Default Outreach Tone
            </label>
            <select
              value={defaultOutreachTone}
              onChange={(e) => setDefaultOutreachTone(e.target.value)}
              className="w-full px-3.5 py-2.5 text-sm rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-900 dark:text-white focus:ring-2 focus:ring-indigo-500 focus:outline-none min-h-[44px]"
            >
              <option value="Helpful & Professional">Helpful & Professional (Consultative, respectful, peer-to-peer)</option>
              <option value="Casual & Friendly">Casual & Friendly (Collaborative creator vibe)</option>
              <option value="Direct & Concise">Direct & Concise (High-signal founder pitch)</option>
            </select>
          </div>
        </div>

        {/* 5. Ethical Affiliate Disclosure Template */}
        <div className="bg-white dark:bg-slate-900 p-5 sm:p-6 rounded-3xl border border-slate-200/80 dark:border-slate-800 shadow-sm space-y-4">
          <div className="flex items-center gap-2 text-indigo-600 dark:text-indigo-400">
            <ShieldCheck className="w-5 h-5 text-emerald-500" />
            <h2 className="text-base font-bold text-slate-900 dark:text-white">
              Ethical Outreach & Affiliate Disclosure
            </h2>
          </div>
          <p className="text-xs text-slate-500 dark:text-slate-400 leading-relaxed">
            FTC and ethical marketing compliance: Be transparent whenever sharing your affiliate recommendation.
          </p>

          <div className="flex items-center gap-2">
            <input
              type="checkbox"
              id="include-disclosure-check"
              checked={includeAffiliateDisclosure}
              onChange={(e) => setIncludeAffiliateDisclosure(e.target.checked)}
              className="w-4 h-4 text-indigo-600 rounded border-slate-300 focus:ring-indigo-500"
            />
            <label
              htmlFor="include-disclosure-check"
              className="text-xs text-slate-700 dark:text-slate-300 cursor-pointer font-bold"
            >
              Append ethical affiliate disclosure note to generated email templates
            </label>
          </div>

          {includeAffiliateDisclosure && (
            <div>
              <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1">
                Custom Disclosure Template
              </label>
              <textarea
                rows={2}
                value={affiliateDisclosureText}
                onChange={(e) => setAffiliateDisclosureText(e.target.value)}
                className="w-full px-3.5 py-2.5 text-xs rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-900 dark:text-white focus:ring-2 focus:ring-indigo-500 focus:outline-none"
              />
            </div>
          )}
        </div>

        {/* 6. Follow-up Cadence & Timing */}
        <div className="bg-white dark:bg-slate-900 p-5 sm:p-6 rounded-3xl border border-slate-200/80 dark:border-slate-800 shadow-sm space-y-4">
          <div className="flex items-center gap-2 text-indigo-600 dark:text-indigo-400">
            <Clock className="w-5 h-5" />
            <h2 className="text-base font-bold text-slate-900 dark:text-white">
              Follow-Up Cadence Preferences
            </h2>
          </div>
          <p className="text-xs text-slate-500 dark:text-slate-400 leading-relaxed">
            Configure default waiting intervals before scheduling follow-ups. OutreachPilot never sends messages automatically—these schedule reminders for your manual review.
          </p>

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
            <div>
              <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1">
                Step 1: Gentle Bump
              </label>
              <div className="flex items-center gap-2">
                <input
                  type="number"
                  min={1}
                  max={14}
                  value={followUpDelayDaysStep1}
                  onChange={(e) => setFollowUpDelayDaysStep1(Number(e.target.value))}
                  className="w-20 px-3 py-2 text-sm rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-900 dark:text-white focus:ring-2 focus:ring-indigo-500"
                />
                <span className="text-xs text-slate-500">days later</span>
              </div>
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1">
                Step 2: Value & Case Angle
              </label>
              <div className="flex items-center gap-2">
                <input
                  type="number"
                  min={1}
                  max={21}
                  value={followUpDelayDaysStep2}
                  onChange={(e) => setFollowUpDelayDaysStep2(Number(e.target.value))}
                  className="w-20 px-3 py-2 text-sm rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-900 dark:text-white focus:ring-2 focus:ring-indigo-500"
                />
                <span className="text-xs text-slate-500">days later</span>
              </div>
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1">
                Step 3: Polite Breakup
              </label>
              <div className="flex items-center gap-2">
                <input
                  type="number"
                  min={1}
                  max={30}
                  value={followUpDelayDaysStep3}
                  onChange={(e) => setFollowUpDelayDaysStep3(Number(e.target.value))}
                  className="w-20 px-3 py-2 text-sm rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-900 dark:text-white focus:ring-2 focus:ring-indigo-500"
                />
                <span className="text-xs text-slate-500">days later</span>
              </div>
            </div>
          </div>
        </div>

        {/* 7. Display Theme */}
        <div className="bg-white dark:bg-slate-900 p-5 sm:p-6 rounded-3xl border border-slate-200/80 dark:border-slate-800 shadow-sm flex items-center justify-between">
          <div>
            <h3 className="text-sm font-bold text-slate-900 dark:text-white">
              Interface Theme
            </h3>
            <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">
              Switch between clean crisp light mode and high-contrast dark mode
            </p>
          </div>

          <button
            type="button"
            onClick={onToggleDarkMode}
            className="flex items-center gap-2 px-4 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-700 dark:text-slate-200 font-semibold text-xs min-h-[44px]"
          >
            {darkMode ? (
              <>
                <Sun className="w-4 h-4 text-amber-400" />
                <span>Light Mode</span>
              </>
            ) : (
              <>
                <Moon className="w-4 h-4 text-slate-600" />
                <span>Dark Mode</span>
              </>
            )}
          </button>
        </div>

        {/* 8. Local Storage & CRM Reset */}
        <div className="bg-white dark:bg-slate-900 p-5 sm:p-6 rounded-3xl border border-slate-200/80 dark:border-slate-800 shadow-sm space-y-4">
          <div>
            <h3 className="text-sm font-bold text-slate-900 dark:text-white">
              Local Storage Management
            </h3>
            <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">
              All prospect discovery results, AI qualification analyses, and outreach drafts are saved locally in your browser storage.
            </p>
          </div>

          <div className="flex flex-wrap items-center gap-3">
            <button
              type="button"
              onClick={handleExportJSON}
              className="flex items-center gap-1.5 px-3.5 py-2 rounded-xl border border-slate-200 dark:border-slate-700 text-slate-700 dark:text-slate-200 hover:bg-slate-50 dark:hover:bg-slate-800 text-xs font-semibold min-h-[44px]"
            >
              <Download className="w-4 h-4 text-slate-500" />
              <span>Export Full JSON Backup</span>
            </button>

            <button
              type="button"
              onClick={handleResetToSample}
              className="flex items-center gap-1.5 px-3.5 py-2 rounded-xl border border-rose-200 dark:border-rose-900 text-rose-600 dark:text-rose-400 hover:bg-rose-50 dark:hover:bg-rose-950/40 text-xs font-semibold min-h-[44px]"
            >
              <RotateCcw className="w-4 h-4" />
              <span>Reset to Sample Prospects</span>
            </button>
          </div>
        </div>

        {/* Save Settings Button */}
        <div className="flex justify-end sticky bottom-4 z-20">
          <button
            type="submit"
            id="save-settings-btn"
            className="flex items-center gap-2 px-7 py-3 rounded-2xl bg-indigo-600 hover:bg-indigo-700 text-white text-xs font-bold shadow-lg shadow-indigo-600/30 transition-all min-h-[46px]"
          >
            <Save className="w-4 h-4" />
            <span>Save All Preferences</span>
          </button>
        </div>
      </form>
    </div>
  );
};
