import { Prospect } from "../types";

export const SAMPLE_PROSPECTS: Prospect[] = [
  {
    id: "prospect-1",
    businessName: "Apex Fitness Coaching",
    websiteUrl: "https://apexfitnessexample.com",
    contactName: "Marcus Vance",
    publicBusinessEmail: "marcus@apexfitnessexample.com",
    niche: "Fitness & Wellness",
    country: "Canada",
    notes: "Marcus sells an 8-week workout course and nutrition guide. Mentioned on his podcast that WordPress plugins break constantly after updates and WooCommerce checkout has a 3-step lag.",
    publicBusinessInfo: "Tech stack clues visible on site: WordPress 6.4, LearnDash LMS, Mailchimp free tier, WP Forms, Stripe gateway. Sells course for $97 with ~30 sales/month.",
    status: "Interested",
    createdAt: new Date(Date.now() - 6 * 86400000).toISOString(),
    updatedAt: new Date(Date.now() - 1 * 86400000).toISOString(),
    lastContactedAt: new Date(Date.now() - 2 * 86400000).toISOString(),
    analysis: {
      opportunityScore: 92,
      systemeFitReasoning: "High fit. Marcus is experiencing classic 'plugin fatigue' where WordPress, LearnDash, and Mailchimp create maintenance overhead. An all-in-one platform hosts video courses, handles 1-click upsells, and manages email marketing with zero plugin headaches.",
      potentialProblems: [
        "Multiple disconnected WordPress plugins that require manual PHP/plugin updates and risk breaking checkout.",
        "Mailchimp list is isolated from course student enrollment, requiring fragile Zapier zaps.",
        "High friction multi-step checkout reducing cart completion on mobile devices."
      ],
      fitReasons: [
        "An all-in-one platform provides native course hosting with instant student access and automated login credentials upon purchase.",
        "Replaces Mailchimp, LearnDash, and WooCommerce with a single streamlined dashboard.",
        "Zero platform transaction fees beyond standard Stripe rates, keeping more profit per $97 course sale."
      ],
      recommendedOutreachAngle: "Eliminating WordPress plugin maintenance and simplifying course delivery into one free or low-cost dashboard.",
      assumptions: [
        "Assumes Marcus manages his WordPress site himself or pays a freelance developer for plugin fixes.",
        "Assumes his student base is currently under 2,000 active email subscribers.",
        "Verify if he requires specific fitness tracking apps that integrate directly with his site."
      ],
      lastAnalyzedAt: new Date(Date.now() - 5 * 86400000).toISOString()
    },
    outreachMessages: {
      email: {
        subject: "Quick question on Apex Fitness course delivery setup",
        body: "Hi Marcus,\n\nI came across your 8-week workout program over at Apex Fitness—great job packaging your coaching into a structured curriculum.\n\nI noticed from your site that you're running LearnDash alongside WordPress and Mailchimp. A lot of fitness creators I talk to struggle with plugins conflicting after updates or students missing login emails.\n\nNot sure if you've explored all-in-one alternatives, but a modern platform combines course hosting, student management, and automated email follow-ups in one place—without needing separate WordPress plugins. It even has a free tier for up to 2,000 subscribers.\n\nNo worries if your current setup is running smoothly, but if you'd ever like to check it out: [Platform Free Plan Link]\n\nKeep up the great work inspiring people to stay healthy!\n\nBest,\n[Your Name]"
      },
      linkedIn: {
        body: "Hi Marcus, saw the great work you're doing with Apex Fitness coaching. I often help fitness creators streamline their course delivery and cut software costs. If you ever get tired of managing WordPress plugin updates for your curriculum, check out an all-in-one platform ([Platform Free Plan Link])—it combines course hosting and email automation in one clean setup. Wishing you continued growth!"
      },
      contactForm: {
        body: "Hi Marcus & the Apex Fitness team,\n\nLoved looking through your coaching programs. Reaching out with a quick tech resource: if you're ever looking to simplify your course delivery and avoid plugin conflicts, take a look at an all-in-one platform ([Platform Free Plan Link]). It replaces multiple subscriptions with an all-in-one platform with a generous free plan. Keep up the awesome training!"
      },
      shortDm: {
        body: "Hey Marcus! Loved checking out Apex Fitness. Just wanted to share a quick resource—an all-in-one platform hosts workout courses and email lists in one dashboard with zero plugin headaches ([Platform Free Plan Link]). Has a free plan too. Hope it's helpful!"
      },
      generatedAt: new Date(Date.now() - 5 * 86400000).toISOString()
    },
    followUps: [
      {
        step: 1,
        label: "Gentle Value Check",
        timing: "3-4 days after initial message",
        subject: "Re: Quick question on Apex Fitness course delivery setup",
        body: "Hi Marcus,\n\nJust floating this quickly in case it got buried under client inquiries! I know running coaching sessions keeps you super busy.\n\nOne thing other fitness trainers like about an all-in-one platform is that it automates video course drip-feed and sends student logins instantly without any Zapier setup: [Platform Free Plan Link].\n\nNo pressure at all—hope your week is going great!",
        sent: true,
        sentAt: new Date(Date.now() - 2 * 86400000).toISOString()
      },
      {
        step: 2,
        label: "Cost & Complexity Comparison",
        timing: "7-10 days after",
        subject: "LearnDash vs All-in-one setup for Apex Fitness",
        body: "Hi Marcus,\n\nQuick thought—many coaches discover they save $600–$1,200/year just by ditching separate plugin licenses and LMS hosting fees. An all-in-one platform gives you the full course portal, unlimited video hosting, and automated email broadcast for free up to 2k contacts: [Platform Free Plan Link].\n\nHope this is useful if you ever do a tech review!",
        sent: false
      },
      {
        step: 3,
        label: "Respectful Breakup / Closing Loop",
        timing: "14-21 days after",
        subject: "Closing the loop / Best of luck with Apex Fitness",
        body: "Hi Marcus,\n\nI want to respect your time, so this will be my last note! Sounds like your WordPress and LearnDash setup is doing the job nicely right now, which is great.\n\nIf you ever want an all-in-one backup in the future, the free plan link is always active at [Platform Free Plan Link].\n\nWishing you and Apex Fitness all the best!",
        sent: false
      }
    ],
    history: [
      { date: new Date(Date.now() - 6 * 86400000).toISOString(), action: "Prospect created and initial notes logged" },
      { date: new Date(Date.now() - 5 * 86400000).toISOString(), action: "AI Opportunity analysis generated (Score: 92)" },
      { date: new Date(Date.now() - 4 * 86400000).toISOString(), action: "Status changed", previousStatus: "Not Contacted", newStatus: "Contacted" },
      { date: new Date(Date.now() - 2 * 86400000).toISOString(), action: "Follow-up #1 sent via Email" },
      { date: new Date(Date.now() - 1 * 86400000).toISOString(), action: "Marcus replied expressing interest in migrating off WordPress!", previousStatus: "Contacted", newStatus: "Interested" }
    ]
  },
  {
    id: "prospect-2",
    businessName: "Clarity Mindset Coaching",
    websiteUrl: "https://claritymindset.org",
    contactName: "Elena Rostova",
    publicBusinessEmail: "elena@claritymindset.org",
    niche: "Life Coaching & Consulting",
    country: "United States",
    notes: "Elena is paying $199/month for Kajabi basic tier, but only hosts 2 audio courses and has about 900 subscribers on her mailing list. Squeezed by high software overhead.",
    publicBusinessInfo: "Site footer states 'Powered by Kajabi'. Has free lead magnet PDF '7-Day Mindful Journal' leading to a $47 mini-course.",
    status: "Not Contacted",
    createdAt: new Date(Date.now() - 3 * 86400000).toISOString(),
    updatedAt: new Date(Date.now() - 3 * 86400000).toISOString(),
    analysis: {
      opportunityScore: 95,
      systemeFitReasoning: "Exceptional fit. Elena is overpaying significantly for Kajabi's high monthly entry fee ($199/mo) relative to her current list size (900 contacts). An all-in-one platform's free tier handles up to 2,000 contacts and 3 sales funnels with course hosting for $0/mo, saving her nearly $2,400 annually.",
      potentialProblems: [
        "Paying $199/mo ($2,388/year) for Kajabi while only utilizing basic features and fewer than 1,000 contacts.",
        "High fixed monthly overhead eating into profits from $47 mini-course sales.",
        "Limited motivation to scale email campaigns due to Kajabi tier thresholds."
      ],
      fitReasons: [
        "An all-in-one platform provides identical course hosting, email newsletter broadcasts, and checkout funnels for $0/mo up to 2,000 contacts.",
        "Instant $2,388/year reduction in operating costs with zero loss in student experience.",
        "Easy migration: can import contacts and replicate the 2 audio courses in an afternoon."
      ],
      recommendedOutreachAngle: "Slashing $2,000+ in annual software bills by migrating to a free all-in-one platform tier.",
      assumptions: [
        "Assumes Elena is on the standard $199/mo Kajabi plan based on the footer badge.",
        "Assumes her subscriber count is under 2,000 based on public newsletter counter.",
        "Verify if she uses Kajabi's mobile app heavily before pitching migration."
      ],
      lastAnalyzedAt: new Date(Date.now() - 3 * 86400000).toISOString()
    },
    history: [
      { date: new Date(Date.now() - 3 * 86400000).toISOString(), action: "Prospect created with Kajabi overhead observation" }
    ]
  },
  {
    id: "prospect-3",
    businessName: "Velox Digital Templates",
    websiteUrl: "https://veloxdesign.co",
    contactName: "Julian Reed",
    publicBusinessEmail: "hello@veloxdesign.co",
    niche: "Digital Agency & Design",
    country: "United Kingdom",
    notes: "Julian sells Notion templates and Figma UI kits via Gumroad. Gumroad takes 10% cut on every single transaction. He also uses Typeform for contact inquiries which costs another $25/mo.",
    publicBusinessInfo: "Active Gumroad profile with 14 products. Prices range from $19 to $79. Has ~4,000 Twitter followers. Gumroad fee increase has been a hot topic in design community.",
    status: "Contacted",
    createdAt: new Date(Date.now() - 4 * 86400000).toISOString(),
    updatedAt: new Date(Date.now() - 2 * 86400000).toISOString(),
    lastContactedAt: new Date(Date.now() - 2 * 86400000).toISOString(),
    analysis: {
      opportunityScore: 86,
      systemeFitReasoning: "Strong fit. Gumroad's 10% flat fee bites into creators who have multiple products. An all-in-one platform charges 0% transaction fees (only standard Stripe/PayPal processing fees) and includes automated digital file downloads and built-in affiliate referral software.",
      potentialProblems: [
        "Losing 10% on every sale to Gumroad's flat platform commission.",
        "Gumroad doesn't allow multi-step upsell funnels or integrated automated email nurturing.",
        "Paying $25/mo for Typeform when simple forms can be integrated into landing pages."
      ],
      fitReasons: [
        "0% platform transaction fees, saving 10% on every single template sale.",
        "Built-in affiliate management so other designers can promote his templates with custom links.",
        "Native order bumps and 1-click upsells to increase average order value from $25 to $45+."
      ],
      recommendedOutreachAngle: "Saving the 10% Gumroad platform tax and setting up an affiliate army for his Notion & Figma templates.",
      assumptions: [
        "Assumes he processes at least $1,000/mo in Gumroad sales, meaning Gumroad takes $100+/mo in platform cuts.",
        "Assumes he wants to own his customer email relationships rather than relying on marketplace traffic."
      ],
      lastAnalyzedAt: new Date(Date.now() - 4 * 86400000).toISOString()
    },
    history: [
      { date: new Date(Date.now() - 4 * 86400000).toISOString(), action: "Prospect added with Gumroad fee notes" },
      { date: new Date(Date.now() - 2 * 86400000).toISOString(), action: "Contacted via LinkedIn connection note", previousStatus: "Not Contacted", newStatus: "Contacted" }
    ]
  },
  {
    id: "prospect-4",
    businessName: "Heritage Brew Lab",
    websiteUrl: "https://heritagebrewlab.com.au",
    contactName: "Liam O'Connor",
    publicBusinessEmail: "liam@heritagebrewlab.com.au",
    niche: "Consulting & Training",
    country: "Australia",
    notes: "Specialty coffee consulting for cafe owners. Website is just a static Squarespace brochure. Has no email capture, no free guide, and relies 100% on manual word of mouth.",
    publicBusinessInfo: "Squarespace site. Contact page has a mailto link and phone number. Offers $500 cafe staff training workshops and coffee roasting consultation.",
    status: "Not Contacted",
    createdAt: new Date(Date.now() - 2 * 86400000).toISOString(),
    updatedAt: new Date(Date.now() - 2 * 86400000).toISOString(),
    analysis: {
      opportunityScore: 74,
      systemeFitReasoning: "Moderate to high potential. Liam is leaving significant money on the table by having zero lead capture mechanism. A simple lead magnet ('Cafe Opening Checklist') connected to an automated email sequence would nurture leads into his $500 workshops.",
      potentialProblems: [
        "No email capture mechanism; website visitors who don't call immediately bounce and are lost forever.",
        "Manual client scheduling and proposal back-and-forth over email.",
        "Zero automated follow-up sequences for prospective cafe owners."
      ],
      fitReasons: [
        "Can launch a dedicated high-converting landing page with a free downloadable PDF in under 30 minutes on an all-in-one platform.",
        "Generous free tier is perfect for local consultants wanting to test email marketing without upfront software costs.",
        "Automated email sequence can build trust over 5 days and pitch his $500 consulting package on autopilot."
      ],
      recommendedOutreachAngle: "Turning website traffic into booked cafe consulting calls with a simple automated lead capture funnel.",
      assumptions: [
        "Assumes Liam receives steady visits to his Squarespace site from local cafe searches.",
        "Assumes he has time or interest in publishing digital guides or online workshops."
      ],
      lastAnalyzedAt: new Date(Date.now() - 2 * 86400000).toISOString()
    }
  },
  {
    id: "prospect-5",
    businessName: "Zenith Language Academy",
    websiteUrl: "https://zenithspanish.com",
    contactName: "Sofia Alvarez",
    publicBusinessEmail: "sofia@zenithspanish.com",
    niche: "Education & Language",
    country: "Spain",
    notes: "Sofia runs conversational Spanish clubs. She previously used Teachable and ConvertKit ($170/mo combined) but paused because of costs. She asked for an affordable all-in-one recommendation in an online forum.",
    publicBusinessInfo: "Offers monthly membership group calls ($29/mo) and recorded pronunciation video vault.",
    status: "Affiliate Link Sent",
    createdAt: new Date(Date.now() - 8 * 86400000).toISOString(),
    updatedAt: new Date(Date.now() - 1 * 86400000).toISOString(),
    lastContactedAt: new Date(Date.now() - 1 * 86400000).toISOString(),
    analysis: {
      opportunityScore: 96,
      systemeFitReasoning: "Maximum fit. Sofia actively expressed frustration with Teachable and ConvertKit subscription costs. An all-in-one platform has built-in membership recurring billing with zero transaction fees and unlimited emails, directly solving her cost barrier.",
      potentialProblems: [
        "High recurring software expenses relative to small group membership revenue.",
        "Disjointed membership management between payment processors and video access.",
        "Paused scaling because software costs felt risky before reaching high member volume."
      ],
      fitReasons: [
        "Free plan lets her restart risk-free with up to 2,000 members and full course hosting.",
        "Handles recurring monthly membership subscriptions directly through Stripe/PayPal.",
        "Zero platform transaction fees allows maximum margins on $29/mo memberships."
      ],
      recommendedOutreachAngle: "Restarting her Spanish membership with $0/mo software overhead and zero transaction fees.",
      assumptions: [
        "Assumes her video lessons can be uploaded directly to an integrated course player.",
        "Assumes she uses Stripe or PayPal for European billing."
      ],
      lastAnalyzedAt: new Date(Date.now() - 8 * 86400000).toISOString()
    },
    history: [
      { date: new Date(Date.now() - 8 * 86400000).toISOString(), action: "Prospect added after online forum post" },
      { date: new Date(Date.now() - 5 * 86400000).toISOString(), action: "Outreach sent via Email with breakdown of all-in-one free tier" },
      { date: new Date(Date.now() - 3 * 86400000).toISOString(), action: "Sofia replied asking for direct link to check features", previousStatus: "Contacted", newStatus: "Replied" },
      { date: new Date(Date.now() - 1 * 86400000).toISOString(), action: "Sent personalized affiliate link with invitation to answer questions", previousStatus: "Replied", newStatus: "Affiliate Link Sent" }
    ]
  }
];

export const NICHE_OPTIONS = [
  "Fitness & Wellness",
  "Life Coaching & Consulting",
  "Digital Agency & Design",
  "Course Creator / Educator",
  "E-commerce & Physical Goods",
  "Freelancer / Service Provider",
  "Author / Speaker / Content Creator",
  "Software / SaaS / Tech",
  "Local Business / Brick & Mortar",
  "Finance & Real Estate",
  "Other"
];

export const COUNTRY_OPTIONS = [
  "United States",
  "United Kingdom",
  "Canada",
  "Australia",
  "Germany",
  "France",
  "Spain",
  "Netherlands",
  "Italy",
  "New Zealand",
  "South Africa",
  "India",
  "Singapore",
  "Other / Global"
];

export const PIPELINE_STAGES: Prospect["status"][] = [
  "Not Contacted",
  "Contacted",
  "Replied",
  "Interested",
  "Affiliate Link Sent",
  "Converted",
  "Not Interested"
];
