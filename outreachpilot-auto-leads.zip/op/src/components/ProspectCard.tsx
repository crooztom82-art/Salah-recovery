import React from "react";
import { Prospect, ProspectStatus } from "../types";
import { PIPELINE_STAGES } from "../data/sampleProspects";
import {
  Building2,
  User,
  Globe,
  Mail,
  Sparkles,
  Send,
  Clock,
  ArrowRight,
  ExternalLink,
  ChevronDown
} from "lucide-react";

interface ProspectCardProps {
  prospect: Prospect;
  onSelect: (prospect: Prospect, initialTab?: "overview" | "analysis" | "outreach" | "followups") => void;
  onStatusChange: (id: string, newStatus: ProspectStatus) => void;
  compact?: boolean;
  selectable?: boolean;
  selected?: boolean;
  onToggleSelect?: (id: string) => void;
}

export const ProspectCard: React.FC<ProspectCardProps> = ({
  prospect,
  onSelect,
  onStatusChange,
  compact = false,
  selectable = false,
  selected = false,
  onToggleSelect
}) => {
  const score = prospect.analysis?.opportunityScore ?? prospect.analysis?.fitScore;
  const classification = prospect.fitClassification || prospect.analysis?.fitClassification;

  // Score color helper
  const getScoreBadge = (scoreVal?: number) => {
    if (scoreVal === undefined) {
      return (
        <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded-lg text-xs font-semibold bg-slate-100 text-slate-600 dark:bg-slate-800 dark:text-slate-400">
          Unscored
        </span>
      );
    }
    if (scoreVal >= 80) {
      return (
        <div className="flex flex-col items-end gap-1">
          <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded-lg text-xs font-bold bg-emerald-100 text-emerald-800 dark:bg-emerald-950/60 dark:text-emerald-300 border border-emerald-300/40">
            <Sparkles className="w-3.5 h-3.5 text-emerald-600 dark:text-emerald-400" />
            <span>{scoreVal}/100</span>
          </span>
          <span className="text-[10px] font-bold text-emerald-700 dark:text-emerald-400">
            {classification || "Strong Potential"}
          </span>
        </div>
      );
    }
    if (scoreVal >= 65) {
      return (
        <div className="flex flex-col items-end gap-1">
          <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded-lg text-xs font-bold bg-indigo-100 text-indigo-800 dark:bg-indigo-950/60 dark:text-indigo-300 border border-indigo-300/40">
            <span>{scoreVal}/100</span>
          </span>
          <span className="text-[10px] font-semibold text-indigo-700 dark:text-indigo-400">
            {classification || "Good Potential"}
          </span>
        </div>
      );
    }
    if (scoreVal >= 50) {
      return (
        <div className="flex flex-col items-end gap-1">
          <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded-lg text-xs font-bold bg-amber-100 text-amber-800 dark:bg-amber-950/60 dark:text-amber-300 border border-amber-300/40">
            <span>{scoreVal}/100</span>
          </span>
          <span className="text-[10px] font-medium text-amber-700 dark:text-amber-400">
            {classification || "Possible"}
          </span>
        </div>
      );
    }
    return (
      <div className="flex flex-col items-end gap-1">
        <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded-lg text-xs font-bold bg-slate-100 text-slate-700 dark:bg-slate-800 dark:text-slate-300">
          <span>{scoreVal}/100</span>
        </span>
        <span className="text-[10px] text-slate-500">
          {classification || "Low Potential"}
        </span>
      </div>
    );
  };

  // Status color pill
  const getStatusColor = (status: ProspectStatus) => {
    switch (status) {
      case "Not Contacted":
        return "bg-slate-100 text-slate-700 dark:bg-slate-800 dark:text-slate-300 border-slate-300 dark:border-slate-700";
      case "Contacted":
        return "bg-blue-100 text-blue-800 dark:bg-blue-950/60 dark:text-blue-300 border-blue-300 dark:border-blue-800";
      case "Replied":
        return "bg-purple-100 text-purple-800 dark:bg-purple-950/60 dark:text-purple-300 border-purple-300 dark:border-purple-800";
      case "Interested":
        return "bg-amber-100 text-amber-800 dark:bg-amber-950/60 dark:text-amber-300 border-amber-300 dark:border-amber-800";
      case "Affiliate Link Sent":
        return "bg-cyan-100 text-cyan-800 dark:bg-cyan-950/60 dark:text-cyan-300 border-cyan-300 dark:border-cyan-800";
      case "Converted":
        return "bg-emerald-100 text-emerald-800 dark:bg-emerald-950/60 dark:text-emerald-300 border-emerald-300 dark:border-emerald-800 font-bold";
      case "Not Interested":
        return "bg-rose-50 text-rose-700 dark:bg-rose-950/40 dark:text-rose-400 border-rose-200 dark:border-rose-900";
      default:
        return "bg-slate-100 text-slate-700";
    }
  };

  // Next status progression helper
  const getNextStatus = (current: ProspectStatus): ProspectStatus | null => {
    const order: ProspectStatus[] = [
      "Not Contacted",
      "Contacted",
      "Replied",
      "Interested",
      "Affiliate Link Sent",
      "Converted"
    ];
    const idx = order.indexOf(current);
    if (idx !== -1 && idx < order.length - 1) {
      return order[idx + 1];
    }
    return null;
  };

  const nextStatus = getNextStatus(prospect.status);

  return (
    <div
      id={`prospect-card-${prospect.id}`}
      className={`group relative bg-white dark:bg-slate-900 rounded-2xl border p-4 sm:p-5 shadow-sm hover:shadow-md transition-all flex flex-col justify-between ${
        selected
          ? "border-indigo-500 ring-2 ring-indigo-500/20 bg-indigo-50/20 dark:bg-indigo-950/20"
          : "border-slate-200/90 dark:border-slate-800"
      }`}
    >
      {/* Top Header: Selection, Business Name & Opportunity Score */}
      <div>
        <div className="flex items-start justify-between gap-3 mb-2.5">
          <div className="flex items-start gap-2.5 flex-1 min-w-0">
            {selectable && (
              <input
                type="checkbox"
                checked={selected}
                onChange={() => onToggleSelect && onToggleSelect(prospect.id)}
                className="mt-1 w-4 h-4 rounded text-indigo-600 border-slate-300 focus:ring-indigo-500 cursor-pointer shrink-0"
                aria-label={`Select ${prospect.businessName}`}
              />
            )}
            <div className="flex-1 min-w-0">
              <h3
                onClick={() => onSelect(prospect, "overview")}
                className="text-base sm:text-lg font-bold text-slate-900 dark:text-white truncate cursor-pointer hover:text-indigo-600 dark:hover:text-indigo-400 transition-colors"
              >
                {prospect.businessName}
              </h3>
              <div className="flex items-center gap-2 mt-0.5 text-xs text-slate-500 dark:text-slate-400">
                <span className="flex items-center gap-1 font-medium truncate">
                  <User className="w-3.5 h-3.5 text-slate-400 shrink-0" />
                  {prospect.contactName}
                </span>
                <span>•</span>
                <span className="truncate">{prospect.city ? `${prospect.city}, ${prospect.country}` : prospect.country}</span>
              </div>
            </div>
          </div>

          <div className="shrink-0">{getScoreBadge(score)}</div>
        </div>

        {/* Niche & Website */}
        <div className="flex flex-wrap items-center gap-1.5 mb-3">
          <span className="inline-flex items-center px-2 py-0.5 rounded-md text-[11px] font-medium bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300">
            {prospect.niche}
          </span>

          {prospect.websiteUrl && (
            <a
              href={
                prospect.websiteUrl.startsWith("http")
                  ? prospect.websiteUrl
                  : `https://${prospect.websiteUrl}`
              }
              target="_blank"
              rel="noopener noreferrer"
              onClick={(e) => e.stopPropagation()}
              className="inline-flex items-center gap-1 px-2 py-0.5 rounded-md text-[11px] font-medium text-slate-500 hover:text-indigo-600 dark:text-slate-400 dark:hover:text-indigo-400 hover:bg-indigo-50 dark:hover:bg-indigo-950/40 transition-colors"
            >
              <Globe className="w-3 h-3" />
              <span className="truncate max-w-[140px]">
                {prospect.websiteUrl.replace(/^https?:\/\/(www\.)?/, "").replace(/\/$/, "")}
              </span>
              <ExternalLink className="w-2.5 h-2.5" />
            </a>
          )}

          {prospect.publicBusinessEmail && (
            <span className="hidden sm:inline-flex items-center gap-1 px-2 py-0.5 rounded-md text-[11px] font-medium text-slate-500 dark:text-slate-400">
              <Mail className="w-3 h-3" />
              <span className="truncate max-w-[130px]">{prospect.publicBusinessEmail}</span>
            </span>
          )}
        </div>

        {/* Notes preview or Recommended Angle */}
        {!compact && (
          <div className="text-xs text-slate-600 dark:text-slate-400 bg-slate-50 dark:bg-slate-800/60 p-2.5 rounded-xl mb-4 line-clamp-2 border border-slate-100 dark:border-slate-800">
            {prospect.analysis?.recommendedOutreachAngle ? (
              <p>
                <strong className="text-slate-800 dark:text-slate-200">Angle: </strong>
                {prospect.analysis.recommendedOutreachAngle}
              </p>
            ) : prospect.notes ? (
              <p>{prospect.notes}</p>
            ) : (
              <p className="text-slate-400 italic">No notes added yet.</p>
            )}
          </div>
        )}
      </div>

      {/* Card Footer: Status Selector & Actions */}
      <div className="pt-2 border-t border-slate-100 dark:border-slate-800/80 flex flex-col gap-2.5">
        {/* Status Dropdown & Advance Button */}
        <div className="flex items-center justify-between gap-2">
          {/* Status selector */}
          <div className="relative inline-block w-auto">
            <select
              aria-label="Prospect Status"
              value={prospect.status}
              onChange={(e) => onStatusChange(prospect.id, e.target.value as ProspectStatus)}
              className={`text-xs font-semibold px-2.5 py-1.5 rounded-lg border appearance-none pr-7 cursor-pointer focus:outline-none focus:ring-2 focus:ring-indigo-500 min-h-[36px] ${getStatusColor(
                prospect.status
              )}`}
            >
              {PIPELINE_STAGES.map((st) => (
                <option key={st} value={st} className="bg-white dark:bg-slate-900 text-slate-900 dark:text-slate-100">
                  {st}
                </option>
              ))}
            </select>
            <ChevronDown className="w-3.5 h-3.5 absolute right-2 top-1/2 -translate-y-1/2 pointer-events-none opacity-60" />
          </div>

          {/* Quick advance to next pipeline stage */}
          {nextStatus && (
            <button
              onClick={() => onStatusChange(prospect.id, nextStatus)}
              title={`Advance to ${nextStatus}`}
              className="flex items-center gap-1 text-xs font-semibold text-indigo-600 dark:text-indigo-400 hover:text-indigo-800 dark:hover:text-indigo-300 p-1.5 rounded-lg hover:bg-indigo-50 dark:hover:bg-indigo-950/50 transition-colors min-h-[36px]"
            >
              <span>{nextStatus}</span>
              <ArrowRight className="w-3.5 h-3.5" />
            </button>
          )}
        </div>

        {/* Large touch targets for core features (Analysis, Outreach, Follow-ups) */}
        <div className="grid grid-cols-3 gap-1.5">
          <button
            onClick={() => onSelect(prospect, "analysis")}
            className="flex items-center justify-center gap-1 py-2 px-2 rounded-xl text-xs font-semibold bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-200 hover:bg-indigo-50 dark:hover:bg-indigo-950/40 hover:text-indigo-600 dark:hover:text-indigo-400 transition-colors min-h-[44px]"
          >
            <Sparkles className="w-3.5 h-3.5 text-indigo-500" />
            <span>Analysis</span>
          </button>

          <button
            onClick={() => onSelect(prospect, "outreach")}
            className="flex items-center justify-center gap-1 py-2 px-2 rounded-xl text-xs font-semibold bg-indigo-50 dark:bg-indigo-950/40 text-indigo-700 dark:text-indigo-300 hover:bg-indigo-100 dark:hover:bg-indigo-900/60 transition-colors min-h-[44px]"
          >
            <Send className="w-3.5 h-3.5" />
            <span>Outreach</span>
          </button>

          <button
            onClick={() => onSelect(prospect, "followups")}
            className="flex items-center justify-center gap-1 py-2 px-2 rounded-xl text-xs font-semibold bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-200 hover:bg-purple-50 dark:hover:bg-purple-950/40 hover:text-purple-600 dark:hover:text-purple-400 transition-colors min-h-[44px]"
          >
            <Clock className="w-3.5 h-3.5 text-purple-500" />
            <span>Follow-up</span>
          </button>
        </div>
      </div>
    </div>
  );
};
