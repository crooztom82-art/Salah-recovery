export type ProspectStatus =
  | "Not Contacted"
  | "Contacted"
  | "Replied"
  | "Interested"
  | "Affiliate Link Sent"
  | "Converted"
  | "Not Interested";

export type FitClassification =
  | "Strong Potential"
  | "Good Potential"
  | "Possible"
  | "Low Potential"
  | "Insufficient Information";

export interface FitScoreBreakdown {
  businessModelFit: number; // max 20
  digitalProductCoaching: number; // max 20
  funnelOpportunity: number; // max 20
  emailLeadCapture: number; // max 15
  automationOpportunity: number; // max 15
  publicEvidenceQuality: number; // max 10
  total: number; // 0-100
}

export interface AnalysisEvidenceItem {
  sourceUrl: string;
  pageSection?: string;
  observation: string;
  timestamp: string;
}

export interface VisibleMarketingSignals {
  leadForms?: boolean | string;
  emailNewsletterCapture?: boolean | string;
  landingPages?: boolean | string;
  funnels?: boolean | string;
  booking?: boolean | string;
  onlineSelling?: boolean | string;
  coursesDigitalProducts?: boolean | string;
}

export interface ProspectAnalysis {
  // Transparent Fit Score: 0–100
  opportunityScore: number;
  fitScore?: number; // Alias for opportunityScore
  fitClassification?: FitClassification;
  scoreBreakdown?: FitScoreBreakdown;

  // Real public website analysis details
  website?: string;
  businessType?: string;
  services?: string[];
  visibleMarketingSignals?: VisibleMarketingSignals;
  visibleOpportunitySignals?: string[];
  analysisTimestamp?: string;

  // Observable opportunity signals
  opportunitySignals?: string[]; // e.g. ["Coaching business", "Sells digital services", "Lead capture opportunity"]

  // Specific all-in-one platform opportunities
  potentialOpportunities?: string[]; // e.g. ["Sales funnel", "Email marketing", "Lead capture", "Course delivery", "Automation"]

  // Public evidence & sources used for recommendations
  evidenceSources?: AnalysisEvidenceItem[];

  // Confidence level (High / Medium / Low) with reasoning
  confidenceLevel?: "High" | "Medium" | "Low";
  confidenceReasoning?: string;

  // 3–5 specific business observations based ONLY on information entered or publicly verified
  businessObservations?: string[];
  observedFacts?: string[];

  // Possible funnel/marketing gaps
  funnelGaps?: string[];
  potentialProblems: string[]; // Backwards compatibility

  // Which platform features could potentially solve those gaps
  systemeSolvingFeatures?: string[];
  platformSolvingFeatures?: string[];
  systemeFitReasoning: string;
  fitReasons: string[];

  // Recommended sales angle
  recommendedSalesAngle?: string;
  recommendedOutreachAngle: string; // Backwards compatibility

  // Why this prospect may or may not be a good prospect
  whyGoodOrNot?: {
    summary?: string;
    whyGood: string[];
    whyNotGoodOrLimitations: string[];
  };
  whyGoodOrNotGood?: {
    summary?: string;
    whyGood: string;
    whyNot: string;
  };

  // Clearly separated assumptions (Never invent facts; clearly separate observed facts from assumptions)
  assumptions: string[];

  lastAnalyzedAt?: string;
}

export interface OutreachMessages {
  // Message A: Short DM (for IG/X/contact form)
  shortDm: {
    body: string;
  };

  // Message B: Email (subject + body)
  email: {
    subject: string;
    body: string;
  };

  // Message C: Longer personalized message (deep-dive, consultative)
  longerPersonalizedMessage?: {
    subject?: string;
    body: string;
  };

  // Backwards compatibility mappings
  coldEmail?: {
    subject: string;
    body: string;
  };
  linkedIn?: {
    body: string;
  };
  shortDmOrContactForm?: {
    body: string;
  };
  contactForm?: {
    body: string;
  };

  affiliateDisclosureIncluded?: boolean;
  generatedAt?: string;
}

export interface FollowUpItem {
  step: number;
  label: string;
  timing: string;
  subject?: string;
  body: string;
  sent?: boolean;
  sentAt?: string;
}

export interface OutreachHistoryEntry {
  id: string;
  date: string;
  channel: "Cold Email" | "LinkedIn" | "Short DM / Contact Form" | "Other";
  message: string;
  subject?: string;
  response:
    | "No Response / Pending"
    | "Opened"
    | "Replied Positive"
    | "Replied Negative"
    | "Requested Link"
    | "Converted"
    | "Follow-up Needed";
  notes?: string;
  followUpDueDate?: string;
}

export interface Prospect {
  id: string;
  businessName: string;
  websiteUrl: string;
  contactName: string;
  publicBusinessEmail?: string;
  niche: string;
  country: string;
  stateRegion?: string;
  city?: string;
  notes: string;
  publicBusinessInfo?: string;
  status: ProspectStatus;
  createdAt: string;
  updatedAt: string;
  lastContactedAt?: string;

  websiteStatus?: "Active" | "Under Construction" | "Not Found" | "No Website Provided";
  businessModel?: string;
  publicContactInfo?: string;
  fitClassification?: FitClassification;

  analysis?: ProspectAnalysis;
  outreachMessages?: OutreachMessages;
  followUps?: FollowUpItem[];
  outreachHistory?: OutreachHistoryEntry[];
  history?: {
    date: string;
    action: string;
    previousStatus?: ProspectStatus;
    newStatus?: ProspectStatus;
  }[];
}

export interface SearchProviderConfig {
  provider: "google_custom_search" | "serpapi" | "google_places" | "gemini_google_search" | "direct_search";
  apiKey?: string;
  searchEngineId?: string; // cx
  isConfigured: boolean;
}

export interface AppSettings {
  affiliateLink?: string;
  systemeAffiliateLink?: string;
  userName?: string;
  userEmail?: string;
  userRole?: string;
  theme?: "light" | "dark" | "system";
  defaultChannel?: "email" | "linkedIn" | "contactForm" | "shortDm";
  defaultOutreachTone?: string;
  autoAnalyzeNewProspects?: boolean;

  defaultTargetCountry?: string;
  defaultNiches?: string[];
  minimumFitScore?: number;

  includeAffiliateDisclosure?: boolean;
  affiliateDisclosureText?: string;

  followUpDelayDaysStep1?: number;
  followUpDelayDaysStep2?: number;
  followUpDelayDaysStep3?: number;

  searchProvider?: SearchProviderConfig;
}

export interface ProspectDiscoveryParams {
  country: string;
  stateRegion?: string;
  city?: string;
  niche: string;
  desiredCount: number;
  minFitScore: number;
  keywords?: string;
}

export interface DiscoveredProspectCandidate {
  businessName: string;
  websiteUrl: string;
  contactName?: string;
  niche: string;
  country: string;
  stateRegion?: string;
  city?: string;
  publicBusinessEmail?: string;
  publicContactInfo?: string;
  notes?: string;
  publicBusinessInfo?: string;
  sourceUrl: string;
  estimatedFitScore?: number;
  fitClassification?: FitClassification;
}

export interface ToastMessage {
  id: string;
  type: "success" | "error" | "info";
  message?: string;
  text?: string;
}

export type ViewTab = "dashboard" | "pipeline" | "prospects" | "settings";

