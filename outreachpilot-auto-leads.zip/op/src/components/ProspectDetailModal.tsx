import React, { useState, useEffect } from "react";
import {
  Prospect,
  ProspectStatus,
  ProspectAnalysis,
  OutreachMessages,
  FollowUpItem,
  OutreachHistoryEntry
} from "../types";
import { PIPELINE_STAGES, NICHE_OPTIONS, COUNTRY_OPTIONS } from "../data/sampleProspects";
import { OutreachHistorySection } from "./OutreachHistorySection";
import {
  generateRealAnalysis,
  generateRealOutreach,
  generateRealFollowups
} from "../utils/aiProspectEngine";
import {
  X,
  Sparkles,
  Send,
  Clock,
  FileText,
  Copy,
  Check,
  Globe,
  Mail,
  User,
  Building2,
  Trash2,
  ExternalLink,
  ChevronRight,
  AlertTriangle,
  History,
  Link2,
  Loader2,
  CheckCircle2,
  BookmarkCheck,
  RotateCcw
} from "lucide-react";

interface ProspectDetailModalProps {
  prospect: Prospect;
  initialTab?: "overview" | "analysis" | "outreach" | "followups" | "outreachHistory" | "history";
  onClose: () => void;
  onUpdateProspect: (updated: Prospect) => void;
  onDeleteProspect: (id: string) => void;
  affiliateLink: string;
  onShowToast: (msg: string, type: "success" | "error" | "info") => void;
}

export const ProspectDetailModal: React.FC<ProspectDetailModalProps> = ({
  prospect,
  initialTab = "overview",
  onClose,
  onUpdateProspect,
  onDeleteProspect,
  affiliateLink,
  onShowToast
}) => {
  const [activeTab, setActiveTab] = useState<
    "overview" | "analysis" | "outreach" | "followups" | "outreachHistory" | "history"
  >(initialTab);

  // Form State for editing basic info
  const [businessName, setBusinessName] = useState(prospect.businessName);
  const [websiteUrl, setWebsiteUrl] = useState(prospect.websiteUrl);
  const [contactName, setContactName] = useState(prospect.contactName);
  const [publicEmail, setPublicEmail] = useState(prospect.publicBusinessEmail || "");
  const [niche, setNiche] = useState(prospect.niche);
  const [country, setCountry] = useState(prospect.country);
  const [notes, setNotes] = useState(prospect.notes);
  const [publicBusinessInfo, setPublicBusinessInfo] = useState(prospect.publicBusinessInfo || "");
  const [status, setStatus] = useState<ProspectStatus>(prospect.status);

  // Analysis state
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [analysisData, setAnalysisData] = useState<ProspectAnalysis | undefined>(prospect.analysis);

  // Outreach messages state
  const [isGeneratingOutreach, setIsGeneratingOutreach] = useState(false);
  const [outreachData, setOutreachData] = useState<OutreachMessages | undefined>(prospect.outreachMessages);
  const [selectedOutreachChannel, setSelectedOutreachChannel] = useState<"email" | "linkedIn" | "contactForm" | "shortDm">("email");

  // Follow-ups state
  const [isGeneratingFollowups, setIsGeneratingFollowups] = useState(false);
  const [followUpsList, setFollowUpsList] = useState<FollowUpItem[]>(prospect.followUps || []);

  // Outreach History state
  const [outreachHistoryList, setOutreachHistoryList] = useState<OutreachHistoryEntry[]>(
    prospect.outreachHistory || []
  );
  const [isLoggingOutreachModalOpen, setIsLoggingOutreachModalOpen] = useState(false);
  const [initialLogData, setInitialLogData] = useState<{
    channel: "Cold Email" | "LinkedIn" | "Short DM / Contact Form" | "Other";
    message: string;
    subject?: string;
  } | undefined>(undefined);

  // Copy feedback tracking
  const [copiedKey, setCopiedKey] = useState<string | null>(null);

  // Synchronize internal state whenever the selected prospect changes
  useEffect(() => {
    setBusinessName(prospect.businessName);
    setWebsiteUrl(prospect.websiteUrl);
    setContactName(prospect.contactName);
    setPublicEmail(prospect.publicBusinessEmail || "");
    setNiche(prospect.niche);
    setCountry(prospect.country);
    setNotes(prospect.notes);
    setPublicBusinessInfo(prospect.publicBusinessInfo || "");
    setStatus(prospect.status);
    setAnalysisData(prospect.analysis);
    setOutreachData(prospect.outreachMessages);
    setFollowUpsList(prospect.followUps || []);
    setOutreachHistoryList(prospect.outreachHistory || []);
  }, [prospect.id, prospect.updatedAt]);

  useEffect(() => {
    if (initialTab) {
      setActiveTab(initialTab);
    }
  }, [initialTab]);

  const handleCopy = (text: string, key: string) => {
    navigator.clipboard.writeText(text);
    setCopiedKey(key);
    onShowToast("Copied to clipboard!", "success");
    setTimeout(() => {
      setCopiedKey((prev) => (prev === key ? null : prev));
    }, 2000);
  };

  // Quick log outreach helper from message generators
  const handleQuickLogMessage = (
    channel: "Cold Email" | "LinkedIn" | "Short DM / Contact Form" | "Other",
    message: string,
    subject?: string
  ) => {
    setInitialLogData({ channel, message, subject });
    setIsLoggingOutreachModalOpen(true);
    setActiveTab("outreachHistory");
  };

  const handleAddHistoryEntry = (entryData: Omit<OutreachHistoryEntry, "id">) => {
    const newEntry: OutreachHistoryEntry = {
      id: `log-${Date.now()}-${Math.random().toString(36).substring(2, 7)}`,
      ...entryData
    };
    const updatedHistory = [newEntry, ...outreachHistoryList];
    setOutreachHistoryList(updatedHistory);

    const shouldAdvance = prospect.status === "Not Contacted";
    const newStatus = shouldAdvance ? "Contacted" : prospect.status;
    if (shouldAdvance) setStatus("Contacted");

    const updatedProspect: Prospect = {
      ...prospect,
      status: newStatus,
      lastContactedAt: new Date().toISOString(),
      outreachHistory: updatedHistory,
      updatedAt: new Date().toISOString(),
      history: [
        ...(prospect.history || []),
        {
          date: new Date().toISOString(),
          action: `Logged sent message via ${newEntry.channel} (${newEntry.response})`
        }
      ]
    };
    onUpdateProspect(updatedProspect);
  };

  const handleUpdateHistoryEntry = (updatedEntry: OutreachHistoryEntry) => {
    const updated = outreachHistoryList.map((e) => (e.id === updatedEntry.id ? updatedEntry : e));
    setOutreachHistoryList(updated);
    const updatedProspect: Prospect = {
      ...prospect,
      outreachHistory: updated,
      updatedAt: new Date().toISOString()
    };
    onUpdateProspect(updatedProspect);
  };

  const handleDeleteHistoryEntry = (id: string) => {
    const updated = outreachHistoryList.filter((e) => e.id !== id);
    setOutreachHistoryList(updated);
    const updatedProspect: Prospect = {
      ...prospect,
      outreachHistory: updated,
      updatedAt: new Date().toISOString()
    };
    onUpdateProspect(updatedProspect);
    onShowToast("Outreach record removed", "info");
  };

  // Save changes to prospect
  const handleSaveBasicInfo = () => {
    const updated: Prospect = {
      ...prospect,
      businessName,
      websiteUrl,
      contactName,
      publicBusinessEmail: publicEmail.trim() ? publicEmail.trim() : undefined,
      niche,
      country,
      notes,
      publicBusinessInfo: publicBusinessInfo.trim() ? publicBusinessInfo.trim() : undefined,
      status,
      analysis: analysisData,
      outreachMessages: outreachData,
      followUps: followUpsList,
      outreachHistory: outreachHistoryList,
      updatedAt: new Date().toISOString()
    };
    onUpdateProspect(updated);
    onShowToast("Prospect updated successfully!", "success");
  };

  // Run AI Sales Analysis with guaranteed execution & fallback
  const handleRunAnalysis = async () => {
    setIsAnalyzing(true);
    setActiveTab("analysis");
    try {
      let fetchedAnalysis: ProspectAnalysis | null = null;
      try {
        const controller = new AbortController();
        const timeoutId = setTimeout(() => controller.abort(), 4500);

        const res = await fetch("/api/analyze-prospect", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          signal: controller.signal,
          body: JSON.stringify({
            businessName,
            websiteUrl,
            contactName,
            niche,
            country,
            notes,
            publicBusinessInfo
          })
        });
        clearTimeout(timeoutId);

        if (res.ok) {
          const data = await res.json();
          if (data.success && data.analysis) {
            fetchedAnalysis = data.analysis;
          }
        }
      } catch (e) {
        console.warn("Backend analysis timeout or error, using high-precision local engine", e);
      }

      const baseAnalysis = fetchedAnalysis || generateRealAnalysis({
        businessName,
        websiteUrl,
        contactName,
        niche,
        country,
        notes,
        publicBusinessInfo
      });

      const newAnalysis: ProspectAnalysis = {
        ...baseAnalysis,
        lastAnalyzedAt: new Date().toISOString()
      };

      setAnalysisData(newAnalysis);

      const updated: Prospect = {
        ...prospect,
        businessName,
        websiteUrl,
        contactName,
        niche,
        country,
        notes,
        publicBusinessInfo,
        analysis: newAnalysis,
        updatedAt: new Date().toISOString(),
        history: [
          ...(prospect.history || []),
          {
            date: new Date().toISOString(),
            action: `AI Opportunity analysis completed (Fit Score: ${newAnalysis.fitScore ?? newAnalysis.opportunityScore}/100)`
          }
        ]
      };
      onUpdateProspect(updated);
      onShowToast(
        `Analysis completed! Fit Score: ${newAnalysis.fitScore ?? newAnalysis.opportunityScore}/100`,
        "success"
      );
    } catch (err: any) {
      const fallbackAnalysis = generateRealAnalysis({
        businessName,
        websiteUrl,
        contactName,
        niche,
        country,
        notes,
        publicBusinessInfo
      });
      setAnalysisData(fallbackAnalysis);
      onShowToast("Analysis ready!", "success");
    } finally {
      setIsAnalyzing(false);
    }
  };

  // Generate Personalized Outreach Messages
  const handleGenerateOutreach = async () => {
    setIsGeneratingOutreach(true);
    setActiveTab("outreach");
    try {
      let fetchedMessages: OutreachMessages | null = null;
      try {
        const controller = new AbortController();
        const timeoutId = setTimeout(() => controller.abort(), 4500);

        const res = await fetch("/api/generate-outreach", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          signal: controller.signal,
          body: JSON.stringify({
            prospect: {
              ...prospect,
              businessName,
              websiteUrl,
              contactName,
              niche,
              country,
              notes,
              publicBusinessInfo,
              analysis: analysisData
            },
            affiliateLink: affiliateLink || "[Platform Link]"
          })
        });
        clearTimeout(timeoutId);

        if (res.ok) {
          const data = await res.json();
          if (data.success && data.messages) {
            fetchedMessages = data.messages;
          }
        }
      } catch (e) {
        console.warn("Backend outreach timeout or error, using local generator", e);
      }

      const baseOutreach = fetchedMessages || generateRealOutreach(
        {
          ...prospect,
          businessName,
          websiteUrl,
          contactName,
          niche,
          country,
          notes,
          publicBusinessInfo,
          analysis: analysisData
        },
        affiliateLink
      );

      const newOutreach: OutreachMessages = {
        ...baseOutreach,
        generatedAt: new Date().toISOString()
      };
      setOutreachData(newOutreach);

      const updated: Prospect = {
        ...prospect,
        outreachMessages: newOutreach,
        updatedAt: new Date().toISOString()
      };
      onUpdateProspect(updated);
      onShowToast("3 Editable outreach messages generated!", "success");
    } catch (err: any) {
      const fallback = generateRealOutreach(prospect, affiliateLink);
      setOutreachData(fallback);
      onShowToast("Outreach messages ready!", "success");
    } finally {
      setIsGeneratingOutreach(false);
    }
  };

  // Generate Follow-ups
  const handleGenerateFollowups = async () => {
    setIsGeneratingFollowups(true);
    setActiveTab("followups");
    try {
      let fetchedFollowups: FollowUpItem[] | null = null;
      try {
        const controller = new AbortController();
        const timeoutId = setTimeout(() => controller.abort(), 4500);

        const res = await fetch("/api/generate-followups", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          signal: controller.signal,
          body: JSON.stringify({
            prospect: {
              ...prospect,
              businessName,
              websiteUrl,
              contactName,
              niche,
              country,
              notes,
              publicBusinessInfo,
              analysis: analysisData
            },
            affiliateLink: affiliateLink || "[Platform Link]"
          })
        });
        clearTimeout(timeoutId);

        if (res.ok) {
          const data = await res.json();
          if (data.success && data.followUps) {
            fetchedFollowups = data.followUps;
          }
        }
      } catch (e) {
        console.warn("Backend follow-ups timeout or error, using local generator", e);
      }

      const list = fetchedFollowups || generateRealFollowups(
        {
          ...prospect,
          businessName,
          websiteUrl,
          contactName,
          niche,
          country,
          notes,
          publicBusinessInfo,
          analysis: analysisData
        },
        affiliateLink
      );

      setFollowUpsList(list);

      const updated: Prospect = {
        ...prospect,
        followUps: list,
        updatedAt: new Date().toISOString()
      };
      onUpdateProspect(updated);
      onShowToast("3 Polite follow-up messages generated!", "success");
    } catch (err: any) {
      const fallback = generateRealFollowups(prospect, affiliateLink);
      setFollowUpsList(fallback);
      onShowToast("Follow-up messages ready!", "success");
    } finally {
      setIsGeneratingFollowups(false);
    }
  };

  // Toggle follow-up sent status
  const handleToggleFollowupSent = (step: number) => {
    const updatedList = followUpsList.map((f) => {
      if (f.step === step) {
        const isNowSent = !f.sent;
        return {
          ...f,
          sent: isNowSent,
          sentAt: isNowSent ? new Date().toISOString() : undefined
        };
      }
      return f;
    });
    setFollowUpsList(updatedList);

    const updated: Prospect = {
      ...prospect,
      followUps: updatedList,
      lastContactedAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
      history: [
        ...(prospect.history || []),
        {
          date: new Date().toISOString(),
          action: `Follow-up #${step} marked as sent`
        }
      ]
    };
    onUpdateProspect(updated);
    onShowToast(`Follow-up #${step} status updated!`, "success");
  };

  return (
    <div
      id="prospect-detail-modal-backdrop"
      className="fixed inset-0 z-50 bg-slate-950/60 backdrop-blur-xs flex items-center justify-center p-2 sm:p-4 overflow-y-auto"
    >
      <div
        id="prospect-detail-modal-panel"
        className="bg-white dark:bg-slate-900 w-full max-w-4xl rounded-3xl border border-slate-200 dark:border-slate-800 shadow-2xl overflow-hidden flex flex-col max-h-[92vh] my-auto"
      >
        {/* Modal Top Header */}
        <div className="p-4 sm:p-6 border-b border-slate-200 dark:border-slate-800 flex items-start justify-between gap-4 bg-slate-50/50 dark:bg-slate-800/30">
          <div>
            <div className="flex items-center gap-2 mb-1">
              <h2 className="text-xl sm:text-2xl font-extrabold text-slate-900 dark:text-white tracking-tight">
                {prospect.businessName}
              </h2>
              {analysisData?.opportunityScore !== undefined && (
                <span className="px-2.5 py-0.5 rounded-full text-xs font-bold bg-emerald-100 text-emerald-800 dark:bg-emerald-950/70 dark:text-emerald-300 border border-emerald-300/40">
                  {analysisData.opportunityScore}/100 Fit
                </span>
              )}
            </div>

            <div className="flex flex-wrap items-center gap-2 text-xs text-slate-500 dark:text-slate-400">
              <span className="flex items-center gap-1 font-medium">
                <User className="w-3.5 h-3.5" />
                {prospect.contactName}
              </span>
              <span>•</span>
              <span>{prospect.niche}</span>
              <span>•</span>
              <span>{prospect.country}</span>
              {prospect.websiteUrl && (
                <>
                  <span>•</span>
                  <a
                    href={prospect.websiteUrl.startsWith("http") ? prospect.websiteUrl : `https://${prospect.websiteUrl}`}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="flex items-center gap-1 text-indigo-600 dark:text-indigo-400 hover:underline"
                  >
                    <Globe className="w-3 h-3" />
                    <span>Visit Site</span>
                    <ExternalLink className="w-2.5 h-2.5" />
                  </a>
                </>
              )}
            </div>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={() => {
                if (confirm(`Are you sure you want to delete "${prospect.businessName}"?`)) {
                  onDeleteProspect(prospect.id);
                  onClose();
                }
              }}
              className="p-2 rounded-xl text-rose-500 hover:bg-rose-50 dark:hover:bg-rose-950/40 transition-colors min-h-[44px] min-w-[44px] flex items-center justify-center"
              title="Delete prospect"
            >
              <Trash2 className="w-5 h-5" />
            </button>

            <button
              onClick={onClose}
              className="p-2 rounded-xl text-slate-400 hover:text-slate-700 dark:hover:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors min-h-[44px] min-w-[44px] flex items-center justify-center"
              aria-label="Close modal"
            >
              <X className="w-6 h-6" />
            </button>
          </div>
        </div>

        {/* 3 Prominent Primary Action Buttons Bar */}
        <div className="px-4 sm:px-6 py-3 bg-slate-100/90 dark:bg-slate-800/90 border-b border-slate-200 dark:border-slate-800 flex flex-wrap items-center justify-between gap-2.5">
          <div className="flex flex-wrap items-center gap-2">
            <button
              onClick={() => {
                setActiveTab("analysis");
                handleRunAnalysis();
              }}
              disabled={isAnalyzing}
              className="px-3.5 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-700 active:bg-emerald-800 text-white text-xs font-bold shadow-xs flex items-center gap-1.5 transition-all min-h-[44px]"
            >
              {isAnalyzing ? (
                <Loader2 className="w-4 h-4 animate-spin" />
              ) : (
                <Sparkles className="w-4 h-4" />
              )}
              <span>1. ANALYZE PROSPECT</span>
            </button>

            <button
              onClick={() => {
                setActiveTab("outreach");
                handleGenerateOutreach();
              }}
              disabled={isGeneratingOutreach}
              className="px-3.5 py-2 rounded-xl bg-indigo-600 hover:bg-indigo-700 active:bg-indigo-800 text-white text-xs font-bold shadow-xs flex items-center gap-1.5 transition-all min-h-[44px]"
            >
              {isGeneratingOutreach ? (
                <Loader2 className="w-4 h-4 animate-spin" />
              ) : (
                <Send className="w-4 h-4" />
              )}
              <span>2. GENERATE OUTREACH</span>
            </button>

            <button
              onClick={() => {
                setActiveTab("followups");
                handleGenerateFollowups();
              }}
              disabled={isGeneratingFollowups}
              className="px-3.5 py-2 rounded-xl bg-purple-600 hover:bg-purple-700 active:bg-purple-800 text-white text-xs font-bold shadow-xs flex items-center gap-1.5 transition-all min-h-[44px]"
            >
              {isGeneratingFollowups ? (
                <Loader2 className="w-4 h-4 animate-spin" />
              ) : (
                <Clock className="w-4 h-4" />
              )}
              <span>3. GENERATE FOLLOW-UPS</span>
            </button>
          </div>

          <button
            type="button"
            onClick={() => {
              setInitialLogData(undefined);
              setIsLoggingOutreachModalOpen(true);
              setActiveTab("outreachHistory");
            }}
            className="px-3.5 py-2 rounded-xl bg-white dark:bg-slate-900 border border-slate-300 dark:border-slate-700 hover:bg-slate-50 dark:hover:bg-slate-800 text-slate-700 dark:text-slate-200 text-xs font-bold flex items-center gap-1.5 transition-all min-h-[44px]"
          >
            <BookmarkCheck className="w-4 h-4 text-indigo-500" />
            <span>+ Record Sent Message</span>
          </button>
        </div>

        {/* Tab Navigation */}
        <div className="flex border-b border-slate-200 dark:border-slate-800 px-4 sm:px-6 overflow-x-auto scrollbar-none bg-white dark:bg-slate-900">
          <button
            onClick={() => setActiveTab("overview")}
            className={`py-3 px-4 text-xs sm:text-sm font-bold border-b-2 whitespace-nowrap transition-colors min-h-[44px] flex items-center gap-2 ${
              activeTab === "overview"
                ? "border-indigo-600 text-indigo-600 dark:text-indigo-400"
                : "border-transparent text-slate-500 hover:text-slate-900 dark:hover:text-white"
            }`}
          >
            <FileText className="w-4 h-4" />
            <span>Overview & Info</span>
          </button>

          <button
            onClick={() => setActiveTab("analysis")}
            className={`py-3 px-4 text-xs sm:text-sm font-bold border-b-2 whitespace-nowrap transition-colors min-h-[44px] flex items-center gap-2 ${
              activeTab === "analysis"
                ? "border-indigo-600 text-indigo-600 dark:text-indigo-400"
                : "border-transparent text-slate-500 hover:text-slate-900 dark:hover:text-white"
            }`}
          >
            <Sparkles className="w-4 h-4 text-emerald-500" />
            <span>AI Sales Analysis</span>
            {analysisData && (
              <span className="w-2 h-2 rounded-full bg-emerald-500" />
            )}
          </button>

          <button
            onClick={() => setActiveTab("outreach")}
            className={`py-3 px-4 text-xs sm:text-sm font-bold border-b-2 whitespace-nowrap transition-colors min-h-[44px] flex items-center gap-2 ${
              activeTab === "outreach"
                ? "border-indigo-600 text-indigo-600 dark:text-indigo-400"
                : "border-transparent text-slate-500 hover:text-slate-900 dark:hover:text-white"
            }`}
          >
            <Send className="w-4 h-4 text-indigo-500" />
            <span>Personalized Outreach</span>
            {outreachData && (
              <span className="w-2 h-2 rounded-full bg-indigo-500" />
            )}
          </button>

          <button
            onClick={() => setActiveTab("followups")}
            className={`py-3 px-4 text-xs sm:text-sm font-bold border-b-2 whitespace-nowrap transition-colors min-h-[44px] flex items-center gap-2 ${
              activeTab === "followups"
                ? "border-indigo-600 text-indigo-600 dark:text-indigo-400"
                : "border-transparent text-slate-500 hover:text-slate-900 dark:hover:text-white"
            }`}
          >
            <Clock className="w-4 h-4 text-purple-500" />
            <span>Follow-up Generator (3)</span>
            {followUpsList.length > 0 && (
              <span className="text-[10px] px-1.5 py-0.2 rounded-full bg-slate-100 dark:bg-slate-800">
                {followUpsList.filter((f) => f.sent).length}/{followUpsList.length}
              </span>
            )}
          </button>

          <button
            onClick={() => setActiveTab("outreachHistory")}
            className={`py-3 px-4 text-xs sm:text-sm font-bold border-b-2 whitespace-nowrap transition-colors min-h-[44px] flex items-center gap-2 ${
              activeTab === "outreachHistory"
                ? "border-indigo-600 text-indigo-600 dark:text-indigo-400"
                : "border-transparent text-slate-500 hover:text-slate-900 dark:hover:text-white"
            }`}
          >
            <BookmarkCheck className="w-4 h-4 text-sky-500" />
            <span>Outreach History</span>
            {outreachHistoryList.length > 0 && (
              <span className="text-[10px] px-1.5 py-0.5 rounded-full bg-indigo-100 text-indigo-800 dark:bg-indigo-950 dark:text-indigo-300 font-bold">
                {outreachHistoryList.length}
              </span>
            )}
          </button>

          <button
            onClick={() => setActiveTab("history")}
            className={`py-3 px-4 text-xs sm:text-sm font-bold border-b-2 whitespace-nowrap transition-colors min-h-[44px] flex items-center gap-2 ${
              activeTab === "history"
                ? "border-indigo-600 text-indigo-600 dark:text-indigo-400"
                : "border-transparent text-slate-500 hover:text-slate-900 dark:hover:text-white"
            }`}
          >
            <History className="w-4 h-4" />
            <span>Activity Log</span>
          </button>
        </div>

        {/* Modal Scrollable Body */}
        <div className="p-4 sm:p-6 overflow-y-auto flex-1 space-y-6">
          {/* TAB 1: OVERVIEW & BASIC INFO */}
          {activeTab === "overview" && (
            <div className="space-y-5">
              {/* Pipeline Status Bar */}
              <div className="bg-slate-50 dark:bg-slate-800/60 p-4 rounded-2xl border border-slate-200 dark:border-slate-700/80">
                <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-2">
                  Current Pipeline Stage
                </label>
                <div className="grid grid-cols-2 sm:grid-cols-4 lg:grid-cols-7 gap-1.5">
                  {PIPELINE_STAGES.map((st) => (
                    <button
                      key={st}
                      type="button"
                      onClick={() => {
                        setStatus(st);
                        const updated: Prospect = {
                          ...prospect,
                          status: st,
                          updatedAt: new Date().toISOString(),
                          history: [
                            ...(prospect.history || []),
                            {
                              date: new Date().toISOString(),
                              action: `Status changed to ${st}`,
                              previousStatus: prospect.status,
                              newStatus: st
                            }
                          ]
                        };
                        onUpdateProspect(updated);
                        onShowToast(`Status updated to "${st}"`, "success");
                      }}
                      className={`px-2 py-2 rounded-xl text-xs font-semibold text-center transition-all min-h-[40px] flex items-center justify-center ${
                        status === st
                          ? "bg-indigo-600 text-white shadow-sm"
                          : "bg-white dark:bg-slate-800 text-slate-600 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-700 border border-slate-200 dark:border-slate-700"
                      }`}
                    >
                      {st}
                    </button>
                  ))}
                </div>
              </div>

              {/* Form Grid */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1">
                    Business Name *
                  </label>
                  <input
                    type="text"
                    value={businessName}
                    onChange={(e) => setBusinessName(e.target.value)}
                    className="w-full px-3.5 py-2.5 text-sm rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-900 dark:text-white focus:ring-2 focus:ring-indigo-500 focus:outline-none min-h-[44px]"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1">
                    Website URL
                  </label>
                  <input
                    type="text"
                    value={websiteUrl}
                    onChange={(e) => setWebsiteUrl(e.target.value)}
                    placeholder="https://example.com"
                    className="w-full px-3.5 py-2.5 text-sm rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-900 dark:text-white focus:ring-2 focus:ring-indigo-500 focus:outline-none min-h-[44px]"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1">
                    Contact Name *
                  </label>
                  <input
                    type="text"
                    value={contactName}
                    onChange={(e) => setContactName(e.target.value)}
                    className="w-full px-3.5 py-2.5 text-sm rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-900 dark:text-white focus:ring-2 focus:ring-indigo-500 focus:outline-none min-h-[44px]"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1">
                    Public Business Email (Optional)
                  </label>
                  <input
                    type="email"
                    value={publicEmail}
                    onChange={(e) => setPublicEmail(e.target.value)}
                    placeholder="contact@business.com"
                    className="w-full px-3.5 py-2.5 text-sm rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-900 dark:text-white focus:ring-2 focus:ring-indigo-500 focus:outline-none min-h-[44px]"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1">
                    Business Type / Niche
                  </label>
                  <select
                    value={niche}
                    onChange={(e) => setNiche(e.target.value)}
                    className="w-full px-3.5 py-2.5 text-sm rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-900 dark:text-white focus:ring-2 focus:ring-indigo-500 focus:outline-none min-h-[44px]"
                  >
                    {NICHE_OPTIONS.map((n) => (
                      <option key={n} value={n}>
                        {n}
                      </option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1">
                    Country
                  </label>
                  <select
                    value={country}
                    onChange={(e) => setCountry(e.target.value)}
                    className="w-full px-3.5 py-2.5 text-sm rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-900 dark:text-white focus:ring-2 focus:ring-indigo-500 focus:outline-none min-h-[44px]"
                  >
                    {COUNTRY_OPTIONS.map((c) => (
                      <option key={c} value={c}>
                        {c}
                      </option>
                    ))}
                  </select>
                </div>
              </div>

              {/* Notes */}
              <div>
                <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1">
                  General Notes & Pain Point Clues
                </label>
                <textarea
                  rows={3}
                  value={notes}
                  onChange={(e) => setNotes(e.target.value)}
                  placeholder="Notes about their offers, pricing, software complaints, or context..."
                  className="w-full px-3.5 py-2.5 text-sm rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-900 dark:text-white focus:ring-2 focus:ring-indigo-500 focus:outline-none"
                />
              </div>

              {/* Public Business Information for Analysis */}
              <div>
                <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1">
                  Publicly Available Business Information (Raw notes, footer tech, course listings)
                </label>
                <textarea
                  rows={3}
                  value={publicBusinessInfo}
                  onChange={(e) => setPublicBusinessInfo(e.target.value)}
                  placeholder="Paste public details here (e.g. 'Uses Kajabi for 2 courses', 'Mailchimp footer link', 'Shopify with high monthly apps')..."
                  className="w-full px-3.5 py-2.5 text-sm rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-900 dark:text-white focus:ring-2 focus:ring-indigo-500 focus:outline-none font-mono text-xs"
                />
                <p className="text-[11px] text-slate-400 mt-1">
                  Used by the AI Prospect Analysis engine to deduce genuine funnel fit without inventing facts.
                </p>
              </div>

              <div className="flex justify-end pt-2">
                <button
                  type="button"
                  onClick={handleSaveBasicInfo}
                  className="px-5 py-2.5 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white text-xs font-bold shadow-sm transition-all min-h-[44px]"
                >
                  Save Changes
                </button>
              </div>
            </div>
          )}

          {/* TAB 2: PROSPECT ANALYSIS */}
          {activeTab === "analysis" && (
            <div className="space-y-6">
              {/* Action Banner */}
              <div className="p-4 rounded-2xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                <div>
                  <h3 className="text-sm font-bold text-slate-900 dark:text-white flex items-center gap-1.5">
                    <Sparkles className="w-4 h-4 text-emerald-500" />
                    <span>Opportunity & Funnel Diagnostic</span>
                  </h3>
                  <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">
                    Generates funnel pain points, honest fit reasoning, opportunity score, and outreach angle.
                  </p>
                </div>

                <button
                  onClick={handleRunAnalysis}
                  disabled={isAnalyzing}
                  className="flex items-center justify-center gap-2 px-4 py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-700 active:bg-emerald-800 disabled:opacity-50 text-white text-xs font-bold shadow-sm transition-all min-h-[44px]"
                >
                  {isAnalyzing ? (
                    <>
                      <Loader2 className="w-4 h-4 animate-spin" />
                      <span>Analyzing Public Data...</span>
                    </>
                  ) : (
                    <>
                      <Sparkles className="w-4 h-4" />
                      <span>{analysisData ? "Re-Run Analysis" : "Generate Analysis"}</span>
                    </>
                  )}
                </button>
              </div>

              {/* Analysis Results Display */}
              {analysisData ? (
                <div className="space-y-5">
                  {/* Anti-Hallucination Guardrail Callout */}
                  <div className="p-3.5 rounded-2xl bg-amber-500/10 border border-amber-500/20 text-xs text-amber-900 dark:text-amber-300 flex items-start gap-2.5">
                    <AlertTriangle className="w-4 h-4 text-amber-600 dark:text-amber-400 shrink-0 mt-0.5" />
                    <div>
                      <span className="font-bold block text-slate-900 dark:text-white mb-0.5">
                        Strict Anti-Hallucination Guarantee
                      </span>
                      <p className="leading-relaxed text-slate-600 dark:text-slate-400">
                        Observations and gap analyses are derived <strong>ONLY</strong> from the business facts, notes, and website details you provided. No traffic metrics, revenue numbers, or technology usage were fabricated. Observed facts are strictly separated from hypotheses.
                      </p>
                    </div>
                  </div>

                  {/* Top Metric Bar: Opportunity Fit Score + Confidence Level */}
                  <div className="p-5 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-sm flex flex-col sm:flex-row sm:items-center justify-between gap-4">
                    <div>
                      <div className="text-xs font-bold text-slate-500 dark:text-slate-400 uppercase tracking-wider">
                        Opportunity Fit Score
                      </div>
                      <div className="flex items-baseline gap-2 mt-1">
                        <span className="text-3xl font-extrabold text-slate-900 dark:text-white">
                          {analysisData.fitScore ?? analysisData.opportunityScore}
                        </span>
                        <span className="text-sm font-semibold text-slate-400">/ 100</span>
                        <span
                          className={`ml-2 text-xs font-bold px-2.5 py-0.5 rounded-full ${
                            (analysisData.fitScore ?? analysisData.opportunityScore) >= 80
                              ? "bg-emerald-100 text-emerald-800 dark:bg-emerald-950 dark:text-emerald-300"
                              : (analysisData.fitScore ?? analysisData.opportunityScore) >= 60
                              ? "bg-amber-100 text-amber-800 dark:bg-amber-950 dark:text-amber-300"
                              : "bg-slate-100 text-slate-700 dark:bg-slate-800 dark:text-slate-300"
                          }`}
                        >
                          {(analysisData.fitScore ?? analysisData.opportunityScore) >= 80
                            ? "High Fit Potential"
                            : (analysisData.fitScore ?? analysisData.opportunityScore) >= 60
                            ? "Moderate Fit"
                            : "Low / Niche Specific Fit"}
                        </span>
                      </div>
                    </div>

                    <div className="flex flex-col items-end gap-2 w-full sm:w-64">
                      <div className="flex items-center gap-1.5 self-start sm:self-end">
                        <span className="text-xs text-slate-500 dark:text-slate-400 font-medium">Confidence:</span>
                        <span
                          className={`text-xs font-bold px-2 py-0.5 rounded-md ${
                            analysisData.confidenceLevel === "High"
                              ? "bg-emerald-100 text-emerald-800 dark:bg-emerald-950 dark:text-emerald-300"
                              : analysisData.confidenceLevel === "Medium"
                              ? "bg-blue-100 text-blue-800 dark:bg-blue-950 dark:text-blue-300"
                              : "bg-slate-100 text-slate-700 dark:bg-slate-800 dark:text-slate-300"
                          }`}
                        >
                          {analysisData.confidenceLevel || "High"}
                        </span>
                      </div>

                      <div className="h-3 w-full bg-slate-100 dark:bg-slate-800 rounded-full overflow-hidden">
                        <div
                          style={{ width: `${analysisData.fitScore ?? analysisData.opportunityScore}%` }}
                          className={`h-full rounded-full transition-all duration-500 ${
                            (analysisData.fitScore ?? analysisData.opportunityScore) >= 80
                              ? "bg-emerald-500"
                              : (analysisData.fitScore ?? analysisData.opportunityScore) >= 60
                              ? "bg-amber-500"
                              : "bg-slate-400"
                          }`}
                        />
                      </div>

                      {analysisData.confidenceReasoning && (
                        <span className="text-[11px] text-slate-400 text-right self-start sm:self-end italic">
                          {analysisData.confidenceReasoning}
                        </span>
                      )}
                    </div>
                  </div>

                  {/* 3–5 Specific Business Observations (ONLY based on entered info) */}
                  <div className="p-5 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800">
                    <h4 className="text-xs font-bold text-slate-900 dark:text-white uppercase tracking-wide mb-3 flex items-center gap-1.5">
                      <CheckCircle2 className="w-4 h-4 text-indigo-500" />
                      <span>3–5 Business Observations (Grounded ONLY in Provided Facts)</span>
                    </h4>
                    <div className="space-y-2">
                      {(analysisData.businessObservations && analysisData.businessObservations.length > 0
                        ? analysisData.businessObservations
                        : analysisData.fitReasons
                      ).map((obs, idx) => (
                        <div
                          key={idx}
                          className="flex items-start gap-2.5 p-2.5 rounded-xl bg-slate-50 dark:bg-slate-800/60 text-xs sm:text-sm text-slate-800 dark:text-slate-200"
                        >
                          <span className="w-5 h-5 rounded-full bg-indigo-100 dark:bg-indigo-950 text-indigo-700 dark:text-indigo-300 text-xs font-bold flex items-center justify-center shrink-0 mt-0.5">
                            {idx + 1}
                          </span>
                          <span className="leading-snug">{obs}</span>
                        </div>
                      ))}
                    </div>
                  </div>

                  {/* Observed Facts vs Reasoned Assumptions side-by-side */}
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    {/* Observed Facts */}
                    <div className="p-4 rounded-2xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700">
                      <h4 className="text-xs font-bold text-emerald-800 dark:text-emerald-300 uppercase tracking-wide mb-2 flex items-center gap-1.5">
                        <Check className="w-3.5 h-3.5 text-emerald-600" />
                        <span>Observed Facts (Directly Provided)</span>
                      </h4>
                      {analysisData.observedFacts && analysisData.observedFacts.length > 0 ? (
                        <ul className="space-y-1.5 text-xs text-slate-700 dark:text-slate-300">
                          {analysisData.observedFacts.map((fact, idx) => (
                            <li key={idx} className="flex items-start gap-2">
                              <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 mt-1.5 shrink-0" />
                              <span>{fact}</span>
                            </li>
                          ))}
                        </ul>
                      ) : (
                        <p className="text-xs text-slate-500 italic">
                          Business niche: {prospect.niche}, Country: {prospect.country}.
                          {prospect.notes ? ` Notes: "${prospect.notes.slice(0, 100)}..."` : ""}
                        </p>
                      )}
                    </div>

                    {/* Clearly Labeled Assumptions */}
                    <div className="p-4 rounded-2xl bg-amber-50/60 dark:bg-amber-950/30 border border-amber-200 dark:border-amber-900/60">
                      <h4 className="text-xs font-bold text-amber-900 dark:text-amber-300 uppercase tracking-wide mb-2 flex items-center gap-1.5">
                        <AlertTriangle className="w-3.5 h-3.5 text-amber-600" />
                        <span>Clearly Labeled Assumptions (Verify Before Outreach)</span>
                      </h4>
                      <ul className="space-y-1.5 text-xs text-amber-950 dark:text-amber-200">
                        {analysisData.assumptions.map((asm, idx) => (
                          <li key={idx} className="flex items-start gap-2">
                            <span className="w-1.5 h-1.5 rounded-full bg-amber-500 mt-1.5 shrink-0" />
                            <span>{asm}</span>
                          </li>
                        ))}
                      </ul>
                    </div>
                  </div>

                  {/* Possible Funnel Gaps & Platform Solutions */}
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    {/* Funnel/Marketing Gaps */}
                    <div className="p-4 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800">
                      <h4 className="text-xs font-bold text-rose-700 dark:text-rose-400 uppercase tracking-wide mb-2.5 flex items-center gap-1.5">
                        <AlertTriangle className="w-3.5 h-3.5 text-rose-500" />
                        <span>Possible Funnel / Marketing Gaps</span>
                      </h4>
                      <ul className="space-y-2 text-xs sm:text-sm text-slate-700 dark:text-slate-300">
                        {(analysisData.funnelGaps && analysisData.funnelGaps.length > 0
                          ? analysisData.funnelGaps
                          : analysisData.potentialProblems
                        ).map((gap, idx) => (
                          <li key={idx} className="flex items-start gap-2">
                            <span className="w-1.5 h-1.5 rounded-full bg-rose-500 mt-2 shrink-0" />
                            <span className="leading-snug">{gap}</span>
                          </li>
                        ))}
                      </ul>
                    </div>

                    {/* Which Platform Features Could Solve Those Gaps */}
                    <div className="p-4 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800">
                      <h4 className="text-xs font-bold text-indigo-700 dark:text-indigo-400 uppercase tracking-wide mb-2.5 flex items-center gap-1.5">
                        <Sparkles className="w-3.5 h-3.5 text-indigo-500" />
                        <span>Platform Features That Could Solve These Gaps</span>
                      </h4>
                      <ul className="space-y-2 text-xs sm:text-sm text-slate-700 dark:text-slate-300">
                        {(analysisData.systemeFeaturesToSolveGaps && analysisData.systemeFeaturesToSolveGaps.length > 0
                          ? analysisData.systemeFeaturesToSolveGaps
                          : [
                              "All-in-one sales funnel builder replaces disjointed tools",
                              "Integrated email automation eliminates Zapier sync failures",
                              "Built-in course & community hosting removes expensive LMS fees"
                            ]
                        ).map((feat, idx) => (
                          <li key={idx} className="flex items-start gap-2">
                            <span className="w-1.5 h-1.5 rounded-full bg-indigo-500 mt-2 shrink-0" />
                            <span className="leading-snug">{feat}</span>
                          </li>
                        ))}
                      </ul>
                    </div>
                  </div>

                  {/* Recommended Sales Angle */}
                  <div className="p-4 sm:p-5 rounded-2xl bg-gradient-to-br from-indigo-500/10 via-purple-500/5 to-transparent border border-indigo-200 dark:border-indigo-800/80">
                    <h4 className="text-xs font-bold text-indigo-900 dark:text-indigo-300 uppercase tracking-wide mb-1.5 flex items-center gap-1.5">
                      <Send className="w-4 h-4 text-indigo-600 dark:text-indigo-400" />
                      <span>Recommended Sales Angle</span>
                    </h4>
                    <p className="text-sm sm:text-base font-semibold text-slate-900 dark:text-white leading-relaxed">
                      "{analysisData.recommendedSalesAngle || analysisData.recommendedOutreachAngle}"
                    </p>
                  </div>

                  {/* Why This Prospect May or May Not Be a Good Prospect */}
                  <div className="p-4 sm:p-5 rounded-2xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-800 space-y-3">
                    <h4 className="text-xs font-bold text-slate-800 dark:text-slate-200 uppercase tracking-wide">
                      Why This Prospect May or May Not Be a Good Prospect
                    </h4>
                    <p className="text-xs sm:text-sm text-slate-700 dark:text-slate-300 leading-relaxed">
                      {analysisData.whyGoodOrNot?.summary || analysisData.whyGoodOrNotGood?.summary || analysisData.systemeFitReasoning}
                    </p>

                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-2">
                      <div className="p-3.5 rounded-xl bg-emerald-50/70 dark:bg-emerald-950/30 border border-emerald-100 dark:border-emerald-900/40 text-xs">
                        <span className="font-bold text-emerald-900 dark:text-emerald-300 block mb-1.5 flex items-center gap-1.5">
                          <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600 dark:text-emerald-400" />
                          <span>Why Good Fit:</span>
                        </span>
                        {analysisData.whyGoodOrNot?.whyGood && Array.isArray(analysisData.whyGoodOrNot.whyGood) ? (
                          <ul className="space-y-1 text-emerald-950 dark:text-emerald-200">
                            {analysisData.whyGoodOrNot.whyGood.map((item, i) => (
                              <li key={i} className="flex items-start gap-1.5">
                                <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 mt-1.5 shrink-0" />
                                <span>{item}</span>
                              </li>
                            ))}
                          </ul>
                        ) : (
                          <p className="text-emerald-950 dark:text-emerald-200 leading-relaxed">
                            {typeof analysisData.whyGoodOrNot?.whyGood === "string"
                              ? analysisData.whyGoodOrNot.whyGood
                              : analysisData.whyGoodOrNotGood?.whyGood || "Strong potential fit based on the prospect's profile and platform advantages."}
                          </p>
                        )}
                      </div>

                      <div className="p-3.5 rounded-xl bg-rose-50/70 dark:bg-rose-950/30 border border-rose-100 dark:border-rose-900/40 text-xs">
                        <span className="font-bold text-rose-900 dark:text-rose-300 block mb-1.5 flex items-center gap-1.5">
                          <AlertTriangle className="w-3.5 h-3.5 text-rose-600 dark:text-rose-400" />
                          <span>Limitations / Why Not:</span>
                        </span>
                        {analysisData.whyGoodOrNot?.whyNotGoodOrLimitations && Array.isArray(analysisData.whyGoodOrNot.whyNotGoodOrLimitations) ? (
                          <ul className="space-y-1 text-rose-950 dark:text-rose-200">
                            {analysisData.whyGoodOrNot.whyNotGoodOrLimitations.map((item, i) => (
                              <li key={i} className="flex items-start gap-1.5">
                                <span className="w-1.5 h-1.5 rounded-full bg-rose-500 mt-1.5 shrink-0" />
                                <span>{item}</span>
                              </li>
                            ))}
                          </ul>
                        ) : (
                          <p className="text-rose-950 dark:text-rose-200 leading-relaxed">
                            {typeof analysisData.whyGoodOrNot?.whyNotGoodOrLimitations === "string"
                              ? analysisData.whyGoodOrNot.whyNotGoodOrLimitations
                              : analysisData.whyGoodOrNotGood?.whyNot || "Verify existing software contracts and migration readiness during conversation."}
                          </p>
                        )}
                      </div>
                    </div>
                  </div>

                  {/* Jump to Outreach button */}
                  <div className="flex justify-end pt-2">
                    <button
                      onClick={() => setActiveTab("outreach")}
                      className="flex items-center gap-2 px-5 py-2.5 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white text-xs font-bold shadow-sm transition-all min-h-[44px]"
                    >
                      <span>Proceed to Personalized Outreach</span>
                      <ChevronRight className="w-4 h-4" />
                    </button>
                  </div>
                </div>
              ) : isAnalyzing ? (
                <div className="text-center py-12 px-4 bg-slate-50 dark:bg-slate-800/40 rounded-3xl border border-slate-200 dark:border-slate-800 space-y-4">
                  <div className="w-12 h-12 rounded-2xl bg-emerald-100 dark:bg-emerald-950/60 text-emerald-600 dark:text-emerald-400 flex items-center justify-center mx-auto">
                    <Loader2 className="w-6 h-6 animate-spin" />
                  </div>
                  <div>
                    <h4 className="text-sm font-bold text-slate-900 dark:text-white">
                      Analyzing {businessName || "Prospect"} for Opportunity Fit...
                    </h4>
                    <p className="text-xs text-slate-500 dark:text-slate-400 max-w-md mx-auto mt-1">
                      Evaluating observed facts, discovering funnel gaps, calculating fit score, and formulating ethical angles.
                    </p>
                  </div>
                </div>
              ) : (
                <div className="text-center py-12 px-4 bg-slate-50 dark:bg-slate-800/40 rounded-3xl border border-dashed border-slate-200 dark:border-slate-800">
                  <Sparkles className="w-10 h-10 text-slate-400 mx-auto mb-2" />
                  <h4 className="text-sm font-bold text-slate-800 dark:text-slate-200 mb-1">
                    No Analysis Generated Yet
                  </h4>
                  <p className="text-xs text-slate-500 dark:text-slate-400 max-w-md mx-auto mb-4">
                    Click "1. ANALYZE PROSPECT" above to diagnose funnel gaps, fit score, and opportunity angle.
                  </p>
                  <button
                    onClick={handleRunAnalysis}
                    disabled={isAnalyzing}
                    className="px-4 py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-bold transition-colors min-h-[44px]"
                  >
                    Run First Diagnostic
                  </button>
                </div>
              )}
            </div>
          )}

          {/* TAB 3: PERSONALIZED OUTREACH GENERATOR */}
          {activeTab === "outreach" && (
            <div className="space-y-6">
              {/* Header & Generator button */}
              <div className="p-4 rounded-2xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                <div>
                  <h3 className="text-sm font-bold text-slate-900 dark:text-white flex items-center gap-1.5">
                    <Send className="w-4 h-4 text-indigo-500" />
                    <span>Ethical First-Contact Generator</span>
                  </h3>
                  <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">
                    Crafts natural, short, non-deceptive messages tailored to this prospect only.
                  </p>
                </div>

                <button
                  onClick={handleGenerateOutreach}
                  disabled={isGeneratingOutreach}
                  className="flex items-center justify-center gap-2 px-4 py-2.5 rounded-xl bg-indigo-600 hover:bg-indigo-700 active:bg-indigo-800 disabled:opacity-50 text-white text-xs font-bold shadow-sm transition-all min-h-[44px]"
                >
                  {isGeneratingOutreach ? (
                    <>
                      <Loader2 className="w-4 h-4 animate-spin" />
                      <span>Writing Ethical Copy...</span>
                    </>
                  ) : (
                    <>
                      <Send className="w-4 h-4" />
                      <span>{outreachData ? "Regenerate Messages" : "Generate Messages"}</span>
                    </>
                  )}
                </button>
              </div>

              {/* Outreach Messages Display */}
              {outreachData ? (
                <div className="space-y-4">
                  {/* Channel Switcher */}
                  <div className="flex items-center gap-1.5 p-1 rounded-xl bg-slate-100 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 max-w-md">
                    <button
                      onClick={() => setSelectedOutreachChannel("email")}
                      className={`flex-1 py-2 px-3 rounded-lg text-xs font-bold transition-all min-h-[40px] flex items-center justify-center gap-1.5 ${
                        selectedOutreachChannel === "email"
                          ? "bg-white dark:bg-slate-900 text-indigo-600 dark:text-indigo-400 shadow-sm"
                          : "text-slate-600 dark:text-slate-400"
                      }`}
                    >
                      <Mail className="w-3.5 h-3.5" />
                      <span>Email</span>
                    </button>

                    <button
                      onClick={() => setSelectedOutreachChannel("linkedIn")}
                      className={`flex-1 py-2 px-3 rounded-lg text-xs font-bold transition-all min-h-[40px] flex items-center justify-center gap-1.5 ${
                        selectedOutreachChannel === "linkedIn"
                          ? "bg-white dark:bg-slate-900 text-indigo-600 dark:text-indigo-400 shadow-sm"
                          : "text-slate-600 dark:text-slate-400"
                      }`}
                    >
                      <span>LinkedIn</span>
                    </button>

                    <button
                      onClick={() => setSelectedOutreachChannel("contactForm")}
                      className={`flex-1 py-2 px-3 rounded-lg text-xs font-bold transition-all min-h-[40px] flex items-center justify-center gap-1.5 ${
                        selectedOutreachChannel === "contactForm"
                          ? "bg-white dark:bg-slate-900 text-indigo-600 dark:text-indigo-400 shadow-sm"
                          : "text-slate-600 dark:text-slate-400"
                      }`}
                    >
                      <span>Form</span>
                    </button>

                    <button
                      onClick={() => setSelectedOutreachChannel("shortDm")}
                      className={`flex-1 py-2 px-3 rounded-lg text-xs font-bold transition-all min-h-[40px] flex items-center justify-center gap-1.5 ${
                        selectedOutreachChannel === "shortDm"
                          ? "bg-white dark:bg-slate-900 text-indigo-600 dark:text-indigo-400 shadow-sm"
                          : "text-slate-600 dark:text-slate-400"
                      }`}
                    >
                      <span>DM</span>
                    </button>
                  </div>

                  {/* Email Channel Content */}
                  {selectedOutreachChannel === "email" && (
                    <div className="space-y-3 bg-white dark:bg-slate-900 p-4 rounded-2xl border border-slate-200 dark:border-slate-800">
                      <div>
                        <div className="flex items-center justify-between mb-1">
                          <label className="text-xs font-bold text-slate-500 dark:text-slate-400">
                            Subject Line
                          </label>
                          <button
                            onClick={() => handleCopy(outreachData.email.subject, "email-subject")}
                            className="flex items-center gap-1 text-xs font-semibold text-indigo-600 dark:text-indigo-400 hover:underline"
                          >
                            {copiedKey === "email-subject" ? (
                              <Check className="w-3.5 h-3.5 text-emerald-500" />
                            ) : (
                              <Copy className="w-3.5 h-3.5" />
                            )}
                            <span>{copiedKey === "email-subject" ? "Copied" : "Copy Subject"}</span>
                          </button>
                        </div>
                        <input
                          type="text"
                          value={outreachData.email.subject}
                          onChange={(e) =>
                            setOutreachData({
                              ...outreachData,
                              email: { ...outreachData.email, subject: e.target.value }
                            })
                          }
                          className="w-full px-3.5 py-2 text-sm font-semibold rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-900 dark:text-white"
                        />
                      </div>

                      <div>
                        <div className="flex items-center justify-between mb-1">
                          <label className="text-xs font-bold text-slate-500 dark:text-slate-400">
                            Email Body
                          </label>
                          <button
                            onClick={() => handleCopy(outreachData.email.body, "email-body")}
                            className="flex items-center gap-1 text-xs font-semibold text-indigo-600 dark:text-indigo-400 hover:underline"
                          >
                            {copiedKey === "email-body" ? (
                              <Check className="w-3.5 h-3.5 text-emerald-500" />
                            ) : (
                              <Copy className="w-3.5 h-3.5" />
                            )}
                            <span>{copiedKey === "email-body" ? "Copied" : "Copy Body"}</span>
                          </button>
                        </div>
                        <textarea
                          rows={10}
                          value={outreachData.email.body}
                          onChange={(e) =>
                            setOutreachData({
                              ...outreachData,
                              email: { ...outreachData.email, body: e.target.value }
                            })
                          }
                          className="w-full px-3.5 py-2.5 text-sm rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-900 dark:text-white leading-relaxed font-sans"
                        />
                      </div>

                      {/* Quick Send / Mailto button */}
                      <div className="flex flex-wrap items-center justify-between gap-2 pt-2 border-t border-slate-100 dark:border-slate-800">
                        {prospect.publicBusinessEmail ? (
                          <a
                            href={`mailto:${prospect.publicBusinessEmail}?subject=${encodeURIComponent(
                              outreachData.email.subject
                            )}&body=${encodeURIComponent(outreachData.email.body)}`}
                            className="inline-flex items-center gap-2 px-4 py-2 rounded-xl bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 hover:bg-slate-200 text-xs font-bold min-h-[44px]"
                          >
                            <Mail className="w-4 h-4" />
                            <span>Open in Default Mail Client</span>
                          </a>
                        ) : (
                          <span className="text-xs text-slate-400 italic">
                            No public email stored. Copy above to paste into your mailer.
                          </span>
                        )}

                        <button
                          onClick={() =>
                            handleQuickLogMessage(
                              "Cold Email",
                              `Subject: ${outreachData.email.subject}\n\n${outreachData.email.body}`,
                              outreachData.email.subject
                            )
                          }
                          className="flex items-center gap-1.5 px-3 py-2 rounded-xl bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 text-slate-700 dark:text-slate-200 text-xs font-bold border border-slate-200 dark:border-slate-700 min-h-[44px]"
                        >
                          <BookmarkCheck className="w-4 h-4 text-indigo-500" />
                          <span>Log to Outreach History</span>
                        </button>

                        <button
                          onClick={() => {
                            handleCopy(
                              `Subject: ${outreachData.email.subject}\n\n${outreachData.email.body}`,
                              "full-email"
                            );
                            if (status === "Not Contacted") {
                              setStatus("Contacted");
                              onUpdateProspect({
                                ...prospect,
                                status: "Contacted",
                                lastContactedAt: new Date().toISOString(),
                                history: [
                                  ...(prospect.history || []),
                                  {
                                    date: new Date().toISOString(),
                                    action: "First contact email sent",
                                    previousStatus: "Not Contacted",
                                    newStatus: "Contacted"
                                  }
                                ]
                              });
                            }
                          }}
                          className="flex items-center gap-1.5 px-4 py-2 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white text-xs font-bold shadow-sm min-h-[44px]"
                        >
                          <Copy className="w-4 h-4" />
                          <span>Copy Full Email & Advance</span>
                        </button>
                      </div>
                    </div>
                  )}

                  {/* LinkedIn Channel Content */}
                  {selectedOutreachChannel === "linkedIn" && (
                    <div className="space-y-3 bg-white dark:bg-slate-900 p-4 rounded-2xl border border-slate-200 dark:border-slate-800">
                      <div className="flex items-center justify-between mb-1">
                        <label className="text-xs font-bold text-slate-500 dark:text-slate-400">
                          LinkedIn Connection Note / Message
                        </label>
                        <button
                          onClick={() => handleCopy(outreachData.linkedIn.body, "linkedin-body")}
                          className="flex items-center gap-1 text-xs font-semibold text-indigo-600 dark:text-indigo-400 hover:underline"
                        >
                          {copiedKey === "linkedin-body" ? (
                            <Check className="w-3.5 h-3.5 text-emerald-500" />
                          ) : (
                            <Copy className="w-3.5 h-3.5" />
                          )}
                          <span>{copiedKey === "linkedin-body" ? "Copied" : "Copy Message"}</span>
                        </button>
                      </div>

                      <textarea
                        rows={6}
                        value={outreachData.linkedIn.body}
                        onChange={(e) =>
                          setOutreachData({
                            ...outreachData,
                            linkedIn: { body: e.target.value }
                          })
                        }
                        className="w-full px-3.5 py-2.5 text-sm rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-900 dark:text-white leading-relaxed"
                      />

                      <div className="flex flex-wrap items-center justify-between gap-2 text-xs text-slate-400 pt-2 border-t border-slate-100 dark:border-slate-800">
                        <span>Characters: {outreachData.linkedIn.body.length} (Ideal: &lt; 300 for invite note)</span>
                        <div className="flex items-center gap-2">
                          <button
                            onClick={() =>
                              handleQuickLogMessage(
                                "LinkedIn",
                                outreachData.linkedIn.body
                              )
                            }
                            className="px-3.5 py-2 rounded-xl bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 text-slate-700 dark:text-slate-200 text-xs font-bold border border-slate-200 dark:border-slate-700 min-h-[44px] flex items-center gap-1.5"
                          >
                            <BookmarkCheck className="w-4 h-4 text-indigo-500" />
                            <span>Log to History</span>
                          </button>
                          <button
                            onClick={() => handleCopy(outreachData.linkedIn.body, "linkedin-body")}
                            className="px-4 py-2 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white text-xs font-bold min-h-[44px]"
                          >
                            Copy LinkedIn Note
                          </button>
                        </div>
                      </div>
                    </div>
                  )}

                  {/* Website Contact Form Content */}
                  {selectedOutreachChannel === "contactForm" && (
                    <div className="space-y-3 bg-white dark:bg-slate-900 p-4 rounded-2xl border border-slate-200 dark:border-slate-800">
                      <div className="flex items-center justify-between mb-1">
                        <label className="text-xs font-bold text-slate-500 dark:text-slate-400">
                          Website Contact Form Message
                        </label>
                        <button
                          onClick={() => handleCopy(outreachData.contactForm.body, "form-body")}
                          className="flex items-center gap-1 text-xs font-semibold text-indigo-600 dark:text-indigo-400 hover:underline"
                        >
                          {copiedKey === "form-body" ? (
                            <Check className="w-3.5 h-3.5 text-emerald-500" />
                          ) : (
                            <Copy className="w-3.5 h-3.5" />
                          )}
                          <span>{copiedKey === "form-body" ? "Copied" : "Copy Form Message"}</span>
                        </button>
                      </div>

                      <textarea
                        rows={6}
                        value={outreachData.contactForm.body}
                        onChange={(e) =>
                          setOutreachData({
                            ...outreachData,
                            contactForm: { body: e.target.value }
                          })
                        }
                        className="w-full px-3.5 py-2.5 text-sm rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-900 dark:text-white leading-relaxed"
                      />

                      <div className="flex flex-wrap items-center justify-between gap-2 pt-2 border-t border-slate-100 dark:border-slate-800">
                        {prospect.websiteUrl ? (
                          <a
                            href={
                              prospect.websiteUrl.startsWith("http")
                                ? prospect.websiteUrl
                                : `https://${prospect.websiteUrl}`
                            }
                            target="_blank"
                            rel="noopener noreferrer"
                            className="inline-flex items-center gap-1 text-xs font-semibold text-indigo-600 dark:text-indigo-400 hover:underline"
                          >
                            <span>Open Website</span>
                            <ExternalLink className="w-3.5 h-3.5" />
                          </a>
                        ) : <span />}
                        <div className="flex items-center gap-2">
                          <button
                            onClick={() =>
                              handleQuickLogMessage(
                                "Short DM / Contact Form",
                                outreachData.contactForm.body
                              )
                            }
                            className="px-3.5 py-2 rounded-xl bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 text-slate-700 dark:text-slate-200 text-xs font-bold border border-slate-200 dark:border-slate-700 min-h-[44px] flex items-center gap-1.5"
                          >
                            <BookmarkCheck className="w-4 h-4 text-indigo-500" />
                            <span>Log to History</span>
                          </button>
                          <button
                            onClick={() => handleCopy(outreachData.contactForm.body, "form-body")}
                            className="px-4 py-2 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white text-xs font-bold min-h-[44px]"
                          >
                            Copy Message
                          </button>
                        </div>
                      </div>
                    </div>
                  )}

                  {/* Short DM Content */}
                  {selectedOutreachChannel === "shortDm" && (
                    <div className="space-y-3 bg-white dark:bg-slate-900 p-4 rounded-2xl border border-slate-200 dark:border-slate-800">
                      <div className="flex items-center justify-between mb-1">
                        <label className="text-xs font-bold text-slate-500 dark:text-slate-400">
                          Short DM (Twitter / X / Instagram / Facebook)
                        </label>
                        <button
                          onClick={() => handleCopy(outreachData.shortDm.body, "dm-body")}
                          className="flex items-center gap-1 text-xs font-semibold text-indigo-600 dark:text-indigo-400 hover:underline"
                        >
                          {copiedKey === "dm-body" ? (
                            <Check className="w-3.5 h-3.5 text-emerald-500" />
                          ) : (
                            <Copy className="w-3.5 h-3.5" />
                          )}
                          <span>{copiedKey === "dm-body" ? "Copied" : "Copy DM"}</span>
                        </button>
                      </div>

                      <textarea
                        rows={4}
                        value={outreachData.shortDm.body}
                        onChange={(e) =>
                          setOutreachData({
                            ...outreachData,
                            shortDm: { body: e.target.value }
                          })
                        }
                        className="w-full px-3.5 py-2.5 text-sm rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-900 dark:text-white leading-relaxed"
                      />

                      <div className="flex flex-wrap items-center justify-between gap-2 text-xs text-slate-400 pt-2 border-t border-slate-100 dark:border-slate-800">
                        <span>{outreachData.shortDm.body.length} characters</span>
                        <div className="flex items-center gap-2">
                          <button
                            onClick={() =>
                              handleQuickLogMessage(
                                "Short DM / Contact Form",
                                outreachData.shortDm.body
                              )
                            }
                            className="px-3.5 py-2 rounded-xl bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 text-slate-700 dark:text-slate-200 text-xs font-bold border border-slate-200 dark:border-slate-700 min-h-[44px] flex items-center gap-1.5"
                          >
                            <BookmarkCheck className="w-4 h-4 text-indigo-500" />
                            <span>Log to History</span>
                          </button>
                          <button
                            onClick={() => handleCopy(outreachData.shortDm.body, "dm-body")}
                            className="px-4 py-2 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white text-xs font-bold min-h-[44px]"
                          >
                            Copy DM
                          </button>
                        </div>
                      </div>
                    </div>
                  )}
                </div>
              ) : isGeneratingOutreach ? (
                <div className="text-center py-12 px-4 bg-slate-50 dark:bg-slate-800/40 rounded-3xl border border-slate-200 dark:border-slate-800 space-y-4">
                  <div className="w-12 h-12 rounded-2xl bg-indigo-100 dark:bg-indigo-950/60 text-indigo-600 dark:text-indigo-400 flex items-center justify-center mx-auto">
                    <Loader2 className="w-6 h-6 animate-spin" />
                  </div>
                  <div>
                    <h4 className="text-sm font-bold text-slate-900 dark:text-white">
                      Drafting 3 Personalized Outreach Messages...
                    </h4>
                    <p className="text-xs text-slate-500 dark:text-slate-400 max-w-md mx-auto mt-1">
                      Generating Cold Email, LinkedIn note, and short website DM tailored to {businessName || "this prospect"} without spam or false claims.
                    </p>
                  </div>
                </div>
              ) : (
                <div className="text-center py-12 px-4 bg-slate-50 dark:bg-slate-800/40 rounded-3xl border border-dashed border-slate-200 dark:border-slate-800">
                  <Send className="w-10 h-10 text-slate-400 mx-auto mb-2" />
                  <h4 className="text-sm font-bold text-slate-800 dark:text-slate-200 mb-1">
                    No Outreach Messages Generated Yet
                  </h4>
                  <p className="text-xs text-slate-500 dark:text-slate-400 max-w-md mx-auto mb-4">
                    Generate natural, personalized messages for Email, LinkedIn, Website Forms, and DMs with zero deceptive spam.
                  </p>
                  <button
                    onClick={handleGenerateOutreach}
                    disabled={isGeneratingOutreach}
                    className="px-4 py-2.5 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white text-xs font-bold transition-colors min-h-[44px]"
                  >
                    Generate First Outreach Drafts
                  </button>
                </div>
              )}
            </div>
          )}

          {/* TAB 4: FOLLOW-UP GENERATOR */}
          {activeTab === "followups" && (
            <div className="space-y-6">
              {/* Header & Follow-up button */}
              <div className="p-4 rounded-2xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                <div>
                  <h3 className="text-sm font-bold text-slate-900 dark:text-white flex items-center gap-1.5">
                    <Clock className="w-4 h-4 text-purple-500" />
                    <span>3 Polite Follow-ups Generator</span>
                  </h3>
                  <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">
                    Polite, progressive touchpoints for prospects who haven't replied. No guilt trips, pure value.
                  </p>
                </div>

                <button
                  onClick={handleGenerateFollowups}
                  disabled={isGeneratingFollowups}
                  className="flex items-center justify-center gap-2 px-4 py-2.5 rounded-xl bg-purple-600 hover:bg-purple-700 active:bg-purple-800 disabled:opacity-50 text-white text-xs font-bold shadow-sm transition-all min-h-[44px]"
                >
                  {isGeneratingFollowups ? (
                    <>
                      <Loader2 className="w-4 h-4 animate-spin" />
                      <span>Writing Sequence...</span>
                    </>
                  ) : (
                    <>
                      <Clock className="w-4 h-4" />
                      <span>{followUpsList.length > 0 ? "Regenerate Follow-ups" : "Generate 3 Follow-ups"}</span>
                    </>
                  )}
                </button>
              </div>

              {/* Follow-ups List */}
              {followUpsList.length > 0 ? (
                <div className="space-y-4">
                  {followUpsList.map((item) => (
                    <div
                      key={item.step}
                      className={`p-4 sm:p-5 rounded-2xl border transition-all ${
                        item.sent
                          ? "bg-slate-50/60 dark:bg-slate-800/30 border-slate-200 dark:border-slate-800 opacity-80"
                          : "bg-white dark:bg-slate-900 border-slate-200 dark:border-slate-800 shadow-sm"
                      }`}
                    >
                      {/* Step Header */}
                      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 mb-3 pb-2 border-b border-slate-100 dark:border-slate-800">
                        <div className="flex items-center gap-2">
                          <span className="w-6 h-6 rounded-full bg-purple-100 dark:bg-purple-950 text-purple-700 dark:text-purple-300 font-extrabold text-xs flex items-center justify-center">
                            #{item.step}
                          </span>
                          <div>
                            <span className="font-bold text-sm text-slate-900 dark:text-white">
                              {item.label}
                            </span>
                            <span className="text-xs text-slate-400 ml-2">({item.timing})</span>
                          </div>
                        </div>

                        {/* Mark Sent Checkbox / Button */}
                        <div className="flex items-center gap-2">
                          <button
                            onClick={() => handleToggleFollowupSent(item.step)}
                            className={`flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-semibold transition-colors min-h-[38px] ${
                              item.sent
                                ? "bg-emerald-100 text-emerald-800 dark:bg-emerald-950/70 dark:text-emerald-300"
                                : "bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 hover:bg-slate-200"
                            }`}
                          >
                            <Check className="w-3.5 h-3.5" />
                            <span>{item.sent ? "Sent" : "Mark as Sent"}</span>
                          </button>

                          <button
                            onClick={() =>
                              handleQuickLogMessage(
                                "Cold Email",
                                item.body,
                                item.subject || `Follow-up #${item.step}: ${item.label}`
                              )
                            }
                            className="flex items-center gap-1 px-3 py-1.5 rounded-xl bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 text-xs font-semibold hover:bg-slate-200 transition-colors min-h-[38px]"
                            title="Log this follow-up as sent"
                          >
                            <BookmarkCheck className="w-3.5 h-3.5 text-purple-500" />
                            <span>Log Sent</span>
                          </button>

                          <button
                            onClick={() => handleCopy(item.body, `followup-${item.step}`)}
                            className="flex items-center gap-1 px-3 py-1.5 rounded-xl bg-purple-50 dark:bg-purple-950/40 text-purple-700 dark:text-purple-300 text-xs font-semibold hover:bg-purple-100 transition-colors min-h-[38px]"
                          >
                            {copiedKey === `followup-${item.step}` ? (
                              <Check className="w-3.5 h-3.5 text-emerald-500" />
                            ) : (
                              <Copy className="w-3.5 h-3.5" />
                            )}
                            <span>{copiedKey === `followup-${item.step}` ? "Copied" : "Copy"}</span>
                          </button>
                        </div>
                      </div>

                      {/* Subject if present */}
                      {item.subject && (
                        <div className="mb-2">
                          <span className="text-[11px] font-bold text-slate-400">Subject: </span>
                          <span className="text-xs font-semibold text-slate-800 dark:text-slate-200">
                            {item.subject}
                          </span>
                        </div>
                      )}

                      {/* Editable Body */}
                      <textarea
                        rows={5}
                        value={item.body}
                        onChange={(e) => {
                          const updated = followUpsList.map((f) =>
                            f.step === item.step ? { ...f, body: e.target.value } : f
                          );
                          setFollowUpsList(updated);
                        }}
                        className="w-full px-3.5 py-2.5 text-xs sm:text-sm rounded-xl bg-slate-50 dark:bg-slate-800/80 border border-slate-200 dark:border-slate-700 text-slate-900 dark:text-white leading-relaxed font-sans"
                      />
                    </div>
                  ))}
                </div>
              ) : isGeneratingFollowups ? (
                <div className="text-center py-12 px-4 bg-slate-50 dark:bg-slate-800/40 rounded-3xl border border-slate-200 dark:border-slate-800 space-y-4">
                  <div className="w-12 h-12 rounded-2xl bg-purple-100 dark:bg-purple-950/60 text-purple-600 dark:text-purple-400 flex items-center justify-center mx-auto">
                    <Loader2 className="w-6 h-6 animate-spin" />
                  </div>
                  <div>
                    <h4 className="text-sm font-bold text-slate-900 dark:text-white">
                      Drafting 3 Respectful Follow-ups...
                    </h4>
                    <p className="text-xs text-slate-500 dark:text-slate-400 max-w-md mx-auto mt-1">
                      Generating progressive, value-driven follow-ups (gentle check, tool cost comparison, and respectful closing note).
                    </p>
                  </div>
                </div>
              ) : (
                <div className="text-center py-12 px-4 bg-slate-50 dark:bg-slate-800/40 rounded-3xl border border-dashed border-slate-200 dark:border-slate-800">
                  <Clock className="w-10 h-10 text-slate-400 mx-auto mb-2" />
                  <h4 className="text-sm font-bold text-slate-800 dark:text-slate-200 mb-1">
                    No Follow-ups Generated Yet
                  </h4>
                  <p className="text-xs text-slate-500 dark:text-slate-400 max-w-md mx-auto mb-4">
                    Generate 3 polite, progressive follow-ups (Gentle check &rarr; Cost comparison &rarr; Respectful breakup note).
                  </p>
                  <button
                    onClick={handleGenerateFollowups}
                    disabled={isGeneratingFollowups}
                    className="px-4 py-2.5 rounded-xl bg-purple-600 hover:bg-purple-700 text-white text-xs font-bold transition-colors min-h-[44px]"
                  >
                    Generate Follow-ups Sequence
                  </button>
                </div>
              )}
            </div>
          )}

          {/* TAB 5: OUTREACH HISTORY & TOUCHPOINTS */}
          {activeTab === "outreachHistory" && (
            <OutreachHistorySection
              prospect={prospect}
              historyEntries={outreachHistoryList}
              onAddEntry={handleAddHistoryEntry}
              onUpdateEntry={handleUpdateHistoryEntry}
              onDeleteEntry={handleDeleteHistoryEntry}
              onShowToast={onShowToast}
              isLogModalOpen={isLoggingOutreachModalOpen}
              onCloseLogModal={() => setIsLoggingOutreachModalOpen(false)}
              initialLogData={initialLogData}
            />
          )}

          {/* TAB 6: ACTIVITY LOG */}
          {activeTab === "history" && (
            <div className="space-y-4">
              <h3 className="text-sm font-bold text-slate-900 dark:text-white">
                Prospect Activity & Touchpoint History
              </h3>

              {prospect.history && prospect.history.length > 0 ? (
                <div className="relative border-l-2 border-slate-200 dark:border-slate-800 ml-3 space-y-4 pl-4 py-1">
                  {prospect.history.map((h, i) => (
                    <div key={i} className="relative">
                      <div className="w-2.5 h-2.5 rounded-full bg-indigo-600 absolute -left-[21px] top-1.5" />
                      <div className="text-xs font-semibold text-slate-900 dark:text-white">
                        {h.action}
                      </div>
                      <div className="text-[11px] text-slate-400 mt-0.5">
                        {new Date(h.date).toLocaleString()}
                      </div>
                    </div>
                  ))}
                </div>
              ) : (
                <div className="text-xs text-slate-400 py-6 text-center">
                  No activity logged yet for this prospect.
                </div>
              )}
            </div>
          )}
        </div>

        {/* Modal Footer */}
        <div className="p-4 border-t border-slate-200 dark:border-slate-800 bg-slate-50/80 dark:bg-slate-800/40 flex items-center justify-between">
          <div className="text-xs text-slate-500 dark:text-slate-400 hidden sm:block">
            Created on {new Date(prospect.createdAt).toLocaleDateString()}
          </div>
          <div className="flex items-center gap-2 w-full sm:w-auto justify-end">
            <button
              onClick={onClose}
              className="px-4 py-2 rounded-xl text-xs font-semibold text-slate-600 dark:text-slate-300 hover:bg-slate-200 dark:hover:bg-slate-700 transition-colors min-h-[44px]"
            >
              Done
            </button>
            <button
              onClick={() => {
                handleSaveBasicInfo();
                onClose();
              }}
              className="px-5 py-2 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white text-xs font-bold transition-colors min-h-[44px]"
            >
              Save & Close
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
