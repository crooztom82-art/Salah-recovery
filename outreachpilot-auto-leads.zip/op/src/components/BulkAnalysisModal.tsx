import React, { useState, useEffect, useRef } from "react";
import {
  X,
  Sparkles,
  CheckCircle2,
  AlertCircle,
  Loader2,
  Pause,
  Play,
  ArrowRight,
  ShieldCheck
} from "lucide-react";
import { Prospect, ProspectAnalysis, FitClassification } from "../types";
import { analyzeProspectLocally } from "../utils/aiProspectEngine";

interface BulkAnalysisModalProps {
  isOpen: boolean;
  onClose: () => void;
  selectedProspects: Prospect[];
  onUpdateProspects: (updated: Prospect[]) => void;
  onShowToast: (msg: string, type: "success" | "error" | "info") => void;
}

export const BulkAnalysisModal: React.FC<BulkAnalysisModalProps> = ({
  isOpen,
  onClose,
  selectedProspects,
  onUpdateProspects,
  onShowToast
}) => {
  const [status, setStatus] = useState<"idle" | "running" | "paused" | "completed">("idle");
  const [currentIndex, setCurrentIndex] = useState(0);
  const [currentName, setCurrentName] = useState("");
  const [results, setResults] = useState<Prospect[]>([]);
  const isCancelledRef = useRef(false);
  const isPausedRef = useRef(false);

  useEffect(() => {
    if (isOpen) {
      setStatus("idle");
      setCurrentIndex(0);
      setCurrentName("");
      setResults([]);
      isCancelledRef.current = false;
      isPausedRef.current = false;
    }
  }, [isOpen]);

  if (!isOpen) return null;

  const total = selectedProspects.length;

  const runBulkAnalysis = async () => {
    setStatus("running");
    isCancelledRef.current = false;
    isPausedRef.current = false;

    const updatedList: Prospect[] = [];

    for (let i = 0; i < selectedProspects.length; i++) {
      if (isCancelledRef.current) break;

      while (isPausedRef.current) {
        await new Promise((resolve) => setTimeout(resolve, 300));
        if (isCancelledRef.current) break;
      }

      const p = selectedProspects[i];
      setCurrentIndex(i + 1);
      setCurrentName(p.businessName);

      try {
        // Perform analysis: try server first, fallback to client-side engine
        let analysis: ProspectAnalysis;
        try {
          const res = await fetch("/api/analyze-prospect", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({
              businessName: p.businessName,
              websiteUrl: p.websiteUrl,
              contactName: p.contactName,
              niche: p.niche,
              country: p.country,
              city: p.city,
              notes: p.notes,
              publicBusinessInfo: p.publicBusinessInfo
            })
          });

          if (res.ok) {
            const data = await res.json();
            analysis = data.analysis;
          } else {
            analysis = analyzeProspectLocally(p);
          }
        } catch {
          analysis = analyzeProspectLocally(p);
        }

        const score = analysis.fitScore ?? analysis.opportunityScore;
        const fitClass: FitClassification =
          analysis.fitClassification ||
          (score >= 80 ? "Strong Potential" : score >= 65 ? "Good Potential" : score >= 50 ? "Possible" : "Low Potential");

        const updatedProspect: Prospect = {
          ...p,
          fitClassification: fitClass,
          analysis: {
            ...analysis,
            fitScore: score,
            fitClassification: fitClass
          },
          updatedAt: new Date().toISOString(),
          history: [
            {
              date: new Date().toISOString(),
              action: `Bulk AI fit analysis: ${score}/100 (${fitClass})`
            },
            ...(p.history || [])
          ]
        };

        updatedList.push(updatedProspect);
        setResults([...updatedList]);

        // Pacing delay (600ms) to respect rate limits and allow smooth animation
        await new Promise((resolve) => setTimeout(resolve, 600));
      } catch (err) {
        console.error("Error analyzing prospect:", p.businessName, err);
      }
    }

    if (!isCancelledRef.current) {
      setStatus("completed");
      onUpdateProspects(updatedList);
      onShowToast(`Completed bulk analysis for ${updatedList.length} prospects!`, "success");
    }
  };

  const handlePauseResume = () => {
    if (status === "running") {
      isPausedRef.current = true;
      setStatus("paused");
    } else if (status === "paused") {
      isPausedRef.current = false;
      setStatus("running");
    }
  };

  const handleCancel = () => {
    isCancelledRef.current = true;
    if (results.length > 0) {
      onUpdateProspects(results);
    }
    onClose();
  };

  const strongCount = results.filter((p) => (p.analysis?.fitScore ?? 0) >= 80).length;
  const goodCount = results.filter((p) => {
    const s = p.analysis?.fitScore ?? 0;
    return s >= 65 && s < 80;
  }).length;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-slate-950/60 backdrop-blur-xs overflow-y-auto">
      <div className="w-full max-w-lg bg-white dark:bg-slate-900 rounded-3xl border border-slate-200/80 dark:border-slate-800 shadow-2xl overflow-hidden animate-in fade-in zoom-in-95 duration-200">
        {/* Header */}
        <div className="flex items-center justify-between px-5 sm:px-6 py-4 border-b border-slate-100 dark:border-slate-800">
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-xl bg-indigo-50 dark:bg-indigo-950/70 text-indigo-600 dark:text-indigo-400 flex items-center justify-center">
              <Sparkles className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-base font-bold text-slate-900 dark:text-white">
                Bulk Prospect Analysis
              </h2>
              <p className="text-xs text-slate-500 dark:text-slate-400">
                Safe-paced, multi-factor opportunity qualification
              </p>
            </div>
          </div>
          {status !== "running" && (
            <button
              onClick={onClose}
              className="p-2 rounded-xl text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors"
            >
              <X className="w-5 h-5" />
            </button>
          )}
        </div>

        <div className="p-5 sm:p-6 space-y-5">
          {/* INITIAL STATE */}
          {status === "idle" && (
            <div className="space-y-4">
              <div className="p-4 rounded-2xl bg-indigo-50/60 dark:bg-indigo-950/30 border border-indigo-100 dark:border-indigo-900/50 space-y-2">
                <div className="flex items-center justify-between">
                  <span className="text-xs font-bold text-indigo-900 dark:text-indigo-200">
                    Ready to analyze {total} selected prospects
                  </span>
                  <span className="text-xs text-indigo-600 dark:text-indigo-400 font-semibold">
                    ~{Math.ceil(total * 0.8)} seconds
                  </span>
                </div>
                <p className="text-xs text-indigo-800/80 dark:text-indigo-300/80 leading-relaxed">
                  Each prospect will be evaluated sequentially across 6 objective fit categories (business model, digital product/coaching presence, funnel opportunity, and email automation).
                </p>
              </div>

              <div className="max-h-48 overflow-y-auto space-y-1.5 pr-1">
                {selectedProspects.map((p) => (
                  <div
                    key={p.id}
                    className="flex items-center justify-between p-2.5 rounded-xl bg-slate-50 dark:bg-slate-800/60 border border-slate-100 dark:border-slate-800 text-xs"
                  >
                    <span className="font-semibold text-slate-900 dark:text-white truncate">
                      {p.businessName}
                    </span>
                    <span className="text-slate-500 dark:text-slate-400 text-[11px] truncate">
                      {p.niche}
                    </span>
                  </div>
                ))}
              </div>

              <div className="flex items-center justify-between pt-2">
                <div className="flex items-center gap-1.5 text-xs text-slate-500">
                  <ShieldCheck className="w-4 h-4 text-emerald-500" />
                  <span>No auto-contacting. Pure qualification.</span>
                </div>

                <div className="flex items-center gap-2">
                  <button
                    type="button"
                    onClick={onClose}
                    className="px-4 py-2 text-xs font-semibold text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white"
                  >
                    Cancel
                  </button>
                  <button
                    type="button"
                    onClick={runBulkAnalysis}
                    className="flex items-center gap-2 px-5 py-2.5 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white text-xs font-bold shadow-md shadow-indigo-600/25 transition-all min-h-[44px]"
                  >
                    <Sparkles className="w-4 h-4" />
                    <span>Start Analysis ({total})</span>
                  </button>
                </div>
              </div>
            </div>
          )}

          {/* RUNNING OR PAUSED STATE */}
          {(status === "running" || status === "paused") && (
            <div className="space-y-4 py-2">
              <div className="text-center space-y-1">
                <span className="text-xs font-bold text-indigo-600 dark:text-indigo-400 uppercase tracking-wider">
                  Analyzing {currentIndex} of {total}
                </span>
                <h3 className="text-base font-bold text-slate-900 dark:text-white truncate px-4">
                  {currentName}
                </h3>
              </div>

              {/* Progress Bar */}
              <div className="w-full bg-slate-100 dark:bg-slate-800 h-2.5 rounded-full overflow-hidden">
                <div
                  className="bg-indigo-600 h-full rounded-full transition-all duration-300"
                  style={{ width: `${(currentIndex / total) * 100}%` }}
                />
              </div>

              <div className="flex items-center justify-between text-xs text-slate-500 dark:text-slate-400">
                <span>Paced safely to prevent rate limits</span>
                <span>{Math.round((currentIndex / total) * 100)}%</span>
              </div>

              {/* Controls */}
              <div className="flex items-center justify-center gap-3 pt-2">
                <button
                  type="button"
                  onClick={handlePauseResume}
                  className="flex items-center gap-1.5 px-4 py-2 rounded-xl bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 text-xs font-semibold hover:bg-slate-200 dark:hover:bg-slate-700 min-h-[44px]"
                >
                  {status === "running" ? (
                    <>
                      <Pause className="w-3.5 h-3.5" />
                      <span>Pause</span>
                    </>
                  ) : (
                    <>
                      <Play className="w-3.5 h-3.5" />
                      <span>Resume</span>
                    </>
                  )}
                </button>

                <button
                  type="button"
                  onClick={handleCancel}
                  className="px-4 py-2 rounded-xl border border-slate-200 dark:border-slate-700 text-slate-600 dark:text-slate-400 text-xs font-semibold hover:bg-slate-50 dark:hover:bg-slate-800 min-h-[44px]"
                >
                  Cancel & Keep Progress
                </button>
              </div>
            </div>
          )}

          {/* COMPLETED STATE */}
          {status === "completed" && (
            <div className="space-y-4 py-2 text-center">
              <div className="w-12 h-12 rounded-2xl bg-emerald-100 dark:bg-emerald-950/70 text-emerald-600 dark:text-emerald-400 flex items-center justify-center mx-auto">
                <CheckCircle2 className="w-6 h-6" />
              </div>

              <div className="space-y-1">
                <h3 className="text-base font-bold text-slate-900 dark:text-white">
                  Analysis Complete!
                </h3>
                <p className="text-xs text-slate-500 dark:text-slate-400">
                  Successfully analyzed all {results.length} prospects. All results saved.
                </p>
              </div>

              <div className="grid grid-cols-2 gap-3 pt-2">
                <div className="p-3 rounded-xl bg-emerald-50 dark:bg-emerald-950/40 border border-emerald-200 dark:border-emerald-900/50">
                  <span className="block text-xl font-extrabold text-emerald-700 dark:text-emerald-300">
                    {strongCount}
                  </span>
                  <span className="text-xs text-emerald-800 dark:text-emerald-400 font-medium">
                    Strong Potential (80-100)
                  </span>
                </div>

                <div className="p-3 rounded-xl bg-indigo-50 dark:bg-indigo-950/40 border border-indigo-200 dark:border-indigo-900/50">
                  <span className="block text-xl font-extrabold text-indigo-700 dark:text-indigo-300">
                    {goodCount}
                  </span>
                  <span className="text-xs text-indigo-800 dark:text-indigo-400 font-medium">
                    Good Potential (65-79)
                  </span>
                </div>
              </div>

              <div className="pt-3">
                <button
                  type="button"
                  onClick={onClose}
                  className="w-full flex items-center justify-center gap-2 py-3 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white text-xs font-bold shadow-md shadow-indigo-600/25 transition-all min-h-[44px]"
                >
                  <span>Done & View Prospects</span>
                  <ArrowRight className="w-4 h-4" />
                </button>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
