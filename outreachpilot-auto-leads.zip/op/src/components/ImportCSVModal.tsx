import React, { useState, useRef } from "react";
import { Prospect } from "../types";
import { parseCSVToProspects } from "../utils/csv";
import { X, Upload, FileText, CheckCircle2, AlertCircle } from "lucide-react";

interface ImportCSVModalProps {
  onClose: () => void;
  onImport: (importedProspects: Prospect[]) => void;
}

export const ImportCSVModal: React.FC<ImportCSVModalProps> = ({
  onClose,
  onImport
}) => {
  const [csvText, setCsvText] = useState("");
  const [fileName, setFileName] = useState("");
  const [previewProspects, setPreviewProspects] = useState<Prospect[]>([]);
  const [error, setError] = useState<string | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const processContent = (text: string) => {
    try {
      const parsed = parseCSVToProspects(text);
      if (parsed.length === 0) {
        setError("No valid prospect rows found in the CSV. Ensure headers match: Business Name, Contact Name, etc.");
        setPreviewProspects([]);
      } else {
        setError(null);
        setPreviewProspects(parsed);
      }
    } catch (err: any) {
      setError(err.message || "Failed to parse CSV.");
      setPreviewProspects([]);
    }
  };

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    setFileName(file.name);
    const reader = new FileReader();
    reader.onload = (event) => {
      const text = event.target?.result as string;
      setCsvText(text);
      processContent(text);
    };
    reader.readAsText(file);
  };

  const handleTextChange = (e: React.ChangeEvent<HTMLTextAreaElement>) => {
    const val = e.target.value;
    setCsvText(val);
    if (val.trim()) {
      processContent(val);
    } else {
      setPreviewProspects([]);
      setError(null);
    }
  };

  const handleConfirmImport = () => {
    if (previewProspects.length > 0) {
      onImport(previewProspects);
      onClose();
    }
  };

  return (
    <div
      id="import-csv-modal-backdrop"
      className="fixed inset-0 z-50 bg-slate-950/60 backdrop-blur-xs flex items-center justify-center p-2 sm:p-4 overflow-y-auto"
    >
      <div
        id="import-csv-modal-panel"
        className="bg-white dark:bg-slate-900 w-full max-w-xl rounded-3xl border border-slate-200 dark:border-slate-800 shadow-2xl overflow-hidden flex flex-col max-h-[90vh] my-auto"
      >
        {/* Modal Header */}
        <div className="p-4 sm:p-5 border-b border-slate-200 dark:border-slate-800 flex items-center justify-between bg-slate-50/50 dark:bg-slate-800/30">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-xl bg-indigo-100 dark:bg-indigo-950/60 text-indigo-600 dark:text-indigo-400 flex items-center justify-center font-bold">
              <Upload className="w-5 h-5" />
            </div>
            <div>
              <h3 className="font-bold text-base text-slate-900 dark:text-white">
                Import Prospects from CSV
              </h3>
              <p className="text-xs text-slate-500 dark:text-slate-400">
                Upload a .csv file or paste spreadsheet data
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-2 rounded-xl text-slate-400 hover:text-slate-700 dark:hover:text-slate-200 min-h-[44px] min-w-[44px] flex items-center justify-center"
            aria-label="Close"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Modal Body */}
        <div className="p-4 sm:p-6 overflow-y-auto space-y-4 flex-1">
          {/* File Picker */}
          <div
            onClick={() => fileInputRef.current?.click()}
            className="border-2 border-dashed border-slate-300 dark:border-slate-700 rounded-2xl p-6 text-center hover:border-indigo-500 cursor-pointer transition-colors bg-slate-50/50 dark:bg-slate-800/40"
          >
            <input
              type="file"
              ref={fileInputRef}
              accept=".csv,text/csv"
              onChange={handleFileUpload}
              className="hidden"
            />
            <Upload className="w-8 h-8 text-slate-400 mx-auto mb-2" />
            <p className="text-xs sm:text-sm font-semibold text-slate-700 dark:text-slate-200">
              {fileName ? fileName : "Click to select a CSV file"}
            </p>
            <p className="text-[11px] text-slate-400 mt-1">
              Supports standard CSV format with Business Name, Contact Name, Website URL, etc.
            </p>
          </div>

          {/* Paste CSV text alternative */}
          <div>
            <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1">
              Or Paste CSV Text Below:
            </label>
            <textarea
              rows={4}
              value={csvText}
              onChange={handleTextChange}
              placeholder={`"Business Name","Website URL","Contact Name","Public Business Email","Business Type/Niche","Country","Notes"\n"Sample Agency","https://sample.com","John Doe","john@sample.com","Digital Marketing","United States","Looking for funnel tools"`}
              className="w-full px-3 py-2 text-xs font-mono rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-900 dark:text-white focus:ring-2 focus:ring-indigo-500 focus:outline-none"
            />
          </div>

          {/* Error notice */}
          {error && (
            <div className="p-3 rounded-xl bg-rose-50 dark:bg-rose-950/40 border border-rose-200 dark:border-rose-900 text-rose-700 dark:text-rose-300 text-xs flex items-start gap-2">
              <AlertCircle className="w-4 h-4 shrink-0 mt-0.5" />
              <span>{error}</span>
            </div>
          )}

          {/* Preview Parsed Prospects */}
          {previewProspects.length > 0 && (
            <div className="p-3.5 rounded-xl bg-emerald-50 dark:bg-emerald-950/40 border border-emerald-200 dark:border-emerald-800">
              <div className="flex items-center gap-2 text-emerald-800 dark:text-emerald-300 font-bold text-xs mb-2">
                <CheckCircle2 className="w-4 h-4" />
                <span>Ready to import {previewProspects.length} prospect(s):</span>
              </div>
              <div className="max-h-36 overflow-y-auto space-y-1 text-xs text-slate-700 dark:text-slate-300">
                {previewProspects.slice(0, 5).map((p, i) => (
                  <div key={i} className="truncate">
                    • <strong>{p.businessName}</strong> ({p.contactName}) — {p.niche}, {p.country}
                  </div>
                ))}
                {previewProspects.length > 5 && (
                  <div className="text-[11px] text-slate-500 italic">
                    ...and {previewProspects.length - 5} more
                  </div>
                )}
              </div>
            </div>
          )}
        </div>

        {/* Modal Footer */}
        <div className="p-4 border-t border-slate-200 dark:border-slate-800 bg-slate-50/80 dark:bg-slate-800/40 flex items-center justify-end gap-2">
          <button
            type="button"
            onClick={onClose}
            className="px-4 py-2.5 rounded-xl text-xs font-semibold text-slate-600 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors min-h-[44px]"
          >
            Cancel
          </button>
          <button
            type="button"
            disabled={previewProspects.length === 0}
            onClick={handleConfirmImport}
            className="px-5 py-2.5 rounded-xl bg-indigo-600 hover:bg-indigo-700 active:bg-indigo-800 disabled:opacity-50 text-white text-xs font-bold shadow-sm transition-all min-h-[44px]"
          >
            Import {previewProspects.length > 0 ? `(${previewProspects.length})` : ""}
          </button>
        </div>
      </div>
    </div>
  );
};
