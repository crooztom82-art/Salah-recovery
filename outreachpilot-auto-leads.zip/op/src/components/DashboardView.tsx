import React, { useState } from "react";
import { Prospect, ProspectStatus, ViewTab } from "../types";
import {
  Users,
  Send,
  MessageSquare,
  Sparkles,
  Link2,
  CheckCircle2,
  ArrowRight,
  TrendingUp,
  ShieldCheck,
  Plus,
  Compass,
  AlertCircle,
  ExternalLink,
  Trophy,
  Flame,
  Star,
  ChevronRight,
  Target,
  Sparkle,
  Search
} from "lucide-react";
import { ProspectCard } from "./ProspectCard";

interface DashboardViewProps {
  prospects: Prospect[];
  setActiveTab: (tab: ViewTab) => void;
  onOpenAddProspect: () => void;
  onOpenFindProspects?: () => void;
  onSelectProspect: (prospect: Prospect, tab?: "overview" | "analysis" | "outreach" | "followups") => void;
  onStatusChange: (id: string, newStatus: ProspectStatus) => void;
  affiliateLink: string;
}

export const DashboardView: React.FC<DashboardViewProps> = ({
  prospects,
  setActiveTab,
  onOpenAddProspect,
  onOpenFindProspects,
  onSelectProspect,
  onStatusChange,
  affiliateLink
}) => {
  const [bestFilter, setBestFilter] = useState<"all" | "high" | "uncontacted">("all");

  // Counts
  const total = prospects.length;
  const notContacted = prospects.filter((p) => p.status === "Not Contacted").length;
  const contacted = prospects.filter((p) => p.status === "Contacted").length;
  const replied = prospects.filter((p) => p.status === "Replied").length;
  const interested = prospects.filter((p) => p.status === "Interested").length;
  const linkSent = prospects.filter((p) => p.status === "Affiliate Link Sent").length;
  const converted = prospects.filter((p) => p.status === "Converted").length;
  const notInterested = prospects.filter((p) => p.status === "Not Interested").length;

  // Conversion rate: Converted / Total (if total > 0)
  const conversionRate = total > 0 ? Math.round((converted / total) * 100) : 0;
  const replyRate = contacted + replied + interested + linkSent + converted > 0
    ? Math.round(((replied + interested + linkSent + converted) / (contacted + replied + interested + linkSent + converted)) * 100)
    : 0;

  // High-potential prospects: Fit Score 80-100 or 'Strong Potential'
  const highPotentialProspects = prospects
    .filter((p) => {
      const score = p.analysis?.fitScore ?? p.analysis?.opportunityScore ?? 0;
      const classification = p.fitClassification || p.analysis?.fitClassification;
      return score >= 80 || classification === "Strong Potential";
    })
    .sort((a, b) => {
      const scoreA = a.analysis?.fitScore ?? a.analysis?.opportunityScore ?? 0;
      const scoreB = b.analysis?.fitScore ?? b.analysis?.opportunityScore ?? 0;
      return scoreB - scoreA;
    });

  // Best prospects sorted by Platform Fit Score (fitScore or opportunityScore)
  const allScoredProspects = prospects
    .filter((p) => {
      const score = p.analysis?.fitScore ?? p.analysis?.opportunityScore;
      return score !== undefined && score > 0;
    })
    .sort((a, b) => {
      const scoreA = a.analysis?.fitScore ?? a.analysis?.opportunityScore ?? 0;
      const scoreB = b.analysis?.fitScore ?? b.analysis?.opportunityScore ?? 0;
      return scoreB - scoreA;
    });

  // Filter best prospects
  const bestProspects = allScoredProspects.filter((p) => {
    const score = p.analysis?.fitScore ?? p.analysis?.opportunityScore ?? 0;
    if (bestFilter === "high") {
      return score >= 80;
    }
    if (bestFilter === "uncontacted") {
      return p.status === "Not Contacted";
    }
    return true;
  }).slice(0, 6);

  // High opportunity count (score 80+)
  const topTierCount = highPotentialProspects.length;

  // Recent prospects
  const recentProspects = [...prospects]
    .sort((a, b) => new Date(b.updatedAt).getTime() - new Date(a.updatedAt).getTime())
    .slice(0, 4);

  const metrics = [
    {
      label: "Total Prospects",
      count: total,
      icon: Users,
      color: "text-slate-700 dark:text-slate-200",
      bg: "bg-slate-100 dark:bg-slate-800",
      targetTab: "prospects",
      filterStatus: "All"
    },
    {
      label: "Not Contacted",
      count: notContacted,
      icon: Compass,
      color: "text-amber-600 dark:text-amber-400",
      bg: "bg-amber-50 dark:bg-amber-950/40",
      targetTab: "pipeline",
      filterStatus: "Not Contacted"
    },
    {
      label: "Contacted",
      count: contacted,
      icon: Send,
      color: "text-blue-600 dark:text-blue-400",
      bg: "bg-blue-50 dark:bg-blue-950/40",
      targetTab: "pipeline",
      filterStatus: "Contacted"
    },
    {
      label: "Replied",
      count: replied,
      icon: MessageSquare,
      color: "text-purple-600 dark:text-purple-400",
      bg: "bg-purple-50 dark:bg-purple-950/40",
      targetTab: "pipeline",
      filterStatus: "Replied"
    },
    {
      label: "Interested",
      count: interested,
      icon: Sparkles,
      color: "text-indigo-600 dark:text-indigo-400",
      bg: "bg-indigo-50 dark:bg-indigo-950/40",
      targetTab: "pipeline",
      filterStatus: "Interested"
    },
    {
      label: "Affiliate Link Sent",
      count: linkSent,
      icon: Link2,
      color: "text-cyan-600 dark:text-cyan-400",
      bg: "bg-cyan-50 dark:bg-cyan-950/40",
      targetTab: "pipeline",
      filterStatus: "Affiliate Link Sent"
    },
    {
      label: "Converted",
      count: converted,
      icon: CheckCircle2,
      color: "text-emerald-600 dark:text-emerald-400",
      bg: "bg-emerald-50 dark:bg-emerald-950/40",
      targetTab: "pipeline",
      filterStatus: "Converted"
    }
  ];

  return (
    <div id="dashboard-view" className="space-y-6 sm:space-y-8 pb-12">
      {/* Welcome Banner / Affiliate reminder */}
      <div className="bg-gradient-to-r from-indigo-700 via-indigo-600 to-blue-600 rounded-3xl p-6 sm:p-8 text-white shadow-xl shadow-indigo-600/15 relative overflow-hidden">
        <div className="absolute top-0 right-0 -mt-8 -mr-8 w-64 h-64 bg-white/10 rounded-full blur-2xl pointer-events-none" />
        <div className="relative z-10 max-w-3xl">
          <div className="flex items-center gap-2 text-indigo-200 text-xs sm:text-sm font-semibold mb-2">
            <ShieldCheck className="w-4 h-4 text-emerald-300" />
            <span>Ethical Direct Outreach Assistant</span>
          </div>
          <h1 className="text-2xl sm:text-3xl font-extrabold tracking-tight text-white mb-2">
            Prospect Outreach Pipeline
          </h1>
          <p className="text-sm sm:text-base text-indigo-100 leading-relaxed mb-5">
            Turn public business information into respectful, high-conversion conversations. No spam, no scraping, no fake personalization.
          </p>

          <div className="flex flex-wrap items-center gap-3">
            {onOpenFindProspects && (
              <button
                onClick={onOpenFindProspects}
                className="flex items-center gap-2 px-4 py-2.5 rounded-xl bg-white text-indigo-700 hover:bg-indigo-50 font-bold text-sm shadow-md transition-all min-h-[44px]"
              >
                <Search className="w-4 h-4" />
                <span>Find Prospects</span>
              </button>
            )}

            <button
              onClick={onOpenAddProspect}
              className="flex items-center gap-2 px-4 py-2.5 rounded-xl bg-indigo-800/60 hover:bg-indigo-800 text-white font-bold text-sm border border-indigo-400/30 transition-all min-h-[44px]"
            >
              <Plus className="w-4 h-4" />
              <span>Add New Prospect</span>
            </button>

            <button
              onClick={() => setActiveTab("pipeline")}
              className="flex items-center gap-2 px-4 py-2.5 rounded-xl bg-white/15 hover:bg-white/25 text-white font-semibold text-sm backdrop-blur-sm transition-all min-h-[44px]"
            >
              <span>Open CRM Pipeline</span>
              <ArrowRight className="w-4 h-4" />
            </button>

            {!affiliateLink && (
              <button
                onClick={() => setActiveTab("settings")}
                className="flex items-center gap-1.5 px-3 py-2 rounded-xl bg-amber-400 text-amber-950 font-bold text-xs shadow hover:bg-amber-300 transition-colors min-h-[44px]"
              >
                <AlertCircle className="w-3.5 h-3.5" />
                <span>Save Your Affiliate/Partner Link in Settings</span>
              </button>
            )}
          </div>
        </div>
      </div>

      {/* 7 Required Metrics Grid */}
      <div>
        <div className="flex items-center justify-between mb-3.5">
          <h2 className="text-base sm:text-lg font-bold text-slate-900 dark:text-white">
            Pipeline Performance
          </h2>
          <span className="text-xs text-slate-500 dark:text-slate-400 font-medium">
            Live local CRM metrics
          </span>
        </div>

        <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-7 gap-2.5 sm:gap-3.5">
          {metrics.map((m, idx) => {
            const Icon = m.icon;
            return (
              <div
                key={m.label}
                id={`metric-card-${idx}`}
                onClick={() => setActiveTab(m.targetTab as ViewTab)}
                className="p-3.5 sm:p-4 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200/80 dark:border-slate-800 shadow-sm hover:shadow-md cursor-pointer transition-all flex flex-col justify-between group"
              >
                <div className="flex items-center justify-between mb-2">
                  <span className="text-[11px] sm:text-xs font-semibold text-slate-500 dark:text-slate-400 truncate">
                    {m.label}
                  </span>
                  <div className={`p-1.5 rounded-lg ${m.bg} ${m.color} group-hover:scale-110 transition-transform`}>
                    <Icon className="w-3.5 h-3.5 sm:w-4 sm:h-4" />
                  </div>
                </div>
                <div className="flex items-baseline justify-between">
                  <span className="text-xl sm:text-2xl font-extrabold text-slate-900 dark:text-white tracking-tight">
                    {m.count}
                  </span>
                  <span className="text-[10px] text-slate-400 group-hover:text-indigo-600 dark:group-hover:text-indigo-400 flex items-center font-medium">
                    View &rarr;
                  </span>
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* Visual Pipeline Funnel Bar */}
      <div className="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200/80 dark:border-slate-800 p-5 shadow-sm">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 mb-4">
          <div>
            <h3 className="text-sm font-bold text-slate-900 dark:text-white flex items-center gap-2">
              <TrendingUp className="w-4 h-4 text-indigo-600 dark:text-indigo-400" />
              <span>Conversion Funnel Health</span>
            </h3>
            <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">
              Visualizing drop-off and momentum across pipeline stages
            </p>
          </div>
          <div className="flex items-center gap-3">
            <div className="text-left sm:text-right">
              <div className="text-xs font-medium text-slate-500 dark:text-slate-400">Reply Rate</div>
              <div className="text-sm font-bold text-slate-900 dark:text-white">{replyRate}%</div>
            </div>
            <div className="h-7 w-px bg-slate-200 dark:bg-slate-800" />
            <div className="text-left sm:text-right">
              <div className="text-xs font-medium text-slate-500 dark:text-slate-400">Conversion Rate</div>
              <div className="text-sm font-bold text-emerald-600 dark:text-emerald-400">{conversionRate}%</div>
            </div>
          </div>
        </div>

        {/* Progress distribution bar */}
        {total > 0 ? (
          <div>
            <div className="h-3 w-full rounded-full bg-slate-100 dark:bg-slate-800 flex overflow-hidden gap-0.5 mb-3">
              {notContacted > 0 && (
                <div
                  style={{ width: `${(notContacted / total) * 100}%` }}
                  className="bg-amber-400 h-full"
                  title={`Not Contacted: ${notContacted}`}
                />
              )}
              {contacted > 0 && (
                <div
                  style={{ width: `${(contacted / total) * 100}%` }}
                  className="bg-blue-500 h-full"
                  title={`Contacted: ${contacted}`}
                />
              )}
              {replied > 0 && (
                <div
                  style={{ width: `${(replied / total) * 100}%` }}
                  className="bg-purple-500 h-full"
                  title={`Replied: ${replied}`}
                />
              )}
              {interested > 0 && (
                <div
                  style={{ width: `${(interested / total) * 100}%` }}
                  className="bg-indigo-500 h-full"
                  title={`Interested: ${interested}`}
                />
              )}
              {linkSent > 0 && (
                <div
                  style={{ width: `${(linkSent / total) * 100}%` }}
                  className="bg-cyan-500 h-full"
                  title={`Link Sent: ${linkSent}`}
                />
              )}
              {converted > 0 && (
                <div
                  style={{ width: `${(converted / total) * 100}%` }}
                  className="bg-emerald-500 h-full"
                  title={`Converted: ${converted}`}
                />
              )}
              {notInterested > 0 && (
                <div
                  style={{ width: `${(notInterested / total) * 100}%` }}
                  className="bg-rose-400 h-full"
                  title={`Not Interested: ${notInterested}`}
                />
              )}
            </div>

            {/* Legend */}
            <div className="flex flex-wrap items-center gap-x-4 gap-y-1.5 text-[11px] text-slate-600 dark:text-slate-400">
              <span className="flex items-center gap-1.5">
                <span className="w-2.5 h-2.5 rounded-full bg-amber-400" />
                <span>Not Contacted ({notContacted})</span>
              </span>
              <span className="flex items-center gap-1.5">
                <span className="w-2.5 h-2.5 rounded-full bg-blue-500" />
                <span>Contacted ({contacted})</span>
              </span>
              <span className="flex items-center gap-1.5">
                <span className="w-2.5 h-2.5 rounded-full bg-purple-500" />
                <span>Replied ({replied})</span>
              </span>
              <span className="flex items-center gap-1.5">
                <span className="w-2.5 h-2.5 rounded-full bg-indigo-500" />
                <span>Interested ({interested})</span>
              </span>
              <span className="flex items-center gap-1.5">
                <span className="w-2.5 h-2.5 rounded-full bg-cyan-500" />
                <span>Link Sent ({linkSent})</span>
              </span>
              <span className="flex items-center gap-1.5">
                <span className="w-2.5 h-2.5 rounded-full bg-emerald-500" />
                <span className="font-semibold text-emerald-600 dark:text-emerald-400">
                  Converted ({converted})
                </span>
              </span>
            </div>
          </div>
        ) : (
          <div className="text-center py-4 text-xs text-slate-400">
            No prospect data yet. Add a prospect to view your pipeline funnel.
          </div>
        )}
      </div>

      {/* High-Potential Prospects (80-100 & Strong Potential) */}
      <div id="high-potential-prospects-section" className="space-y-4">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 pb-1 border-b border-slate-200 dark:border-slate-800">
          <div className="flex items-center gap-2.5">
            <div className="p-1.5 rounded-xl bg-emerald-500/10 text-emerald-600 dark:text-emerald-400 border border-emerald-500/20">
              <Sparkles className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h2 className="text-lg sm:text-xl font-extrabold text-slate-900 dark:text-white tracking-tight">
                  High-Potential Prospects
                </h2>
                <span className="px-2.5 py-0.5 rounded-full text-xs font-bold bg-emerald-100 dark:bg-emerald-950/80 text-emerald-800 dark:text-emerald-300 border border-emerald-300/60">
                  Fit Score 80–100 · Strong Potential ({highPotentialProspects.length})
                </span>
              </div>
              <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">
                Top qualified candidates with verified funnel gaps ready for high-converting 1-on-1 outreach
              </p>
            </div>
          </div>

          <button
            onClick={() => setActiveTab("prospects")}
            className="text-xs font-bold text-indigo-600 dark:text-indigo-400 hover:underline min-h-[36px] flex items-center gap-1 self-start sm:self-auto"
          >
            <span>View all directory</span>
            <ArrowRight className="w-3.5 h-3.5" />
          </button>
        </div>

        {highPotentialProspects.length > 0 ? (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {highPotentialProspects.slice(0, 6).map((prospect) => {
              const score = prospect.analysis?.fitScore ?? prospect.analysis?.opportunityScore ?? 80;
              const classification = prospect.fitClassification || prospect.analysis?.fitClassification || "Strong Potential";
              const topReason =
                prospect.analysis?.fitReasons?.[0] ||
                prospect.analysis?.systemeSolvingFeatures?.[0] ||
                prospect.analysis?.systemeFitReasoning ||
                "High synergy with all-in-one courses and sales funnels";
              const angle =
                prospect.analysis?.recommendedSalesAngle ||
                prospect.analysis?.recommendedOutreachAngle ||
                "Highlight cost savings and all-in-one simplicity";

              return (
                <div
                  key={prospect.id}
                  className="p-5 rounded-2xl bg-white dark:bg-slate-900 border border-emerald-200 dark:border-emerald-900/40 hover:border-emerald-400 dark:hover:border-emerald-700 shadow-sm hover:shadow-md transition-all flex flex-col justify-between"
                >
                  <div>
                    {/* Header: Score & Classification */}
                    <div className="flex items-center justify-between gap-2 mb-3">
                      <span className="px-2.5 py-1 rounded-xl text-xs font-black bg-emerald-50 dark:bg-emerald-950/70 text-emerald-700 dark:text-emerald-300 border border-emerald-300/60 flex items-center gap-1.5">
                        <Sparkles className="w-3.5 h-3.5 text-emerald-600 dark:text-emerald-400" />
                        <span>Fit Score: {score}/100</span>
                      </span>

                      <span className="text-[11px] font-bold px-2 py-0.5 rounded-full bg-emerald-100 text-emerald-800 dark:bg-emerald-900/60 dark:text-emerald-200">
                        {classification}
                      </span>
                    </div>

                    {/* Business Name & Niche */}
                    <div className="mb-3">
                      <h3
                        onClick={() => onSelectProspect(prospect, "overview")}
                        className="text-base font-bold text-slate-900 dark:text-white hover:text-indigo-600 dark:hover:text-indigo-400 cursor-pointer transition-colors"
                      >
                        {prospect.businessName}
                      </h3>
                      <div className="flex items-center gap-1.5 text-xs text-slate-500 dark:text-slate-400 mt-1">
                        <span className="font-semibold text-slate-700 dark:text-slate-300">{prospect.niche}</span>
                        <span>•</span>
                        <span>{prospect.country}</span>
                      </div>
                    </div>

                    {/* Top Reason Platform Fits */}
                    <div className="p-3 rounded-xl bg-slate-50 dark:bg-slate-800/80 border border-slate-200/80 dark:border-slate-700/60 text-xs mb-3">
                      <span className="font-bold text-slate-700 dark:text-slate-200 block mb-0.5">
                        Key Alignment Reason:
                      </span>
                      <p className="text-slate-600 dark:text-slate-300 line-clamp-2">
                        {topReason}
                      </p>
                    </div>

                    {/* Recommended Outreach Angle */}
                    <div className="p-3 rounded-xl bg-indigo-50/70 dark:bg-indigo-950/40 border border-indigo-100 dark:border-indigo-900/50 text-xs mb-4">
                      <span className="font-bold text-indigo-900 dark:text-indigo-300 block mb-0.5">
                        Recommended Outreach Angle:
                      </span>
                      <p className="text-slate-700 dark:text-slate-300 line-clamp-2 italic">
                        "{angle}"
                      </p>
                    </div>
                  </div>

                  {/* One-Click Action: Open Outreach Generator */}
                  <div className="pt-3 border-t border-slate-100 dark:border-slate-800 flex items-center justify-between gap-2">
                    <button
                      onClick={() => onSelectProspect(prospect, "outreach")}
                      className="w-full flex items-center justify-center gap-2 px-3.5 py-2.5 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white text-xs font-bold shadow-sm shadow-indigo-600/20 transition-all min-h-[40px]"
                    >
                      <Send className="w-3.5 h-3.5" />
                      <span>Generate Outreach</span>
                    </button>

                    <button
                      onClick={() => onSelectProspect(prospect, "analysis")}
                      className="p-2.5 rounded-xl border border-slate-200 dark:border-slate-700 hover:bg-slate-50 dark:hover:bg-slate-800 text-slate-600 dark:text-slate-300 transition-colors"
                      title="View full AI analysis"
                    >
                      <Sparkles className="w-4 h-4 text-indigo-500" />
                    </button>
                  </div>
                </div>
              );
            })}
          </div>
        ) : (
          <div className="p-6 rounded-2xl bg-white dark:bg-slate-900 border border-dashed border-slate-200 dark:border-slate-800 text-center">
            <p className="text-xs text-slate-500 dark:text-slate-400 mb-3">
              No prospects currently scored 80+ or marked as Strong Potential. Run prospect discovery or AI qualification to highlight top candidates.
            </p>
            {onOpenFindProspects && (
              <button
                onClick={onOpenFindProspects}
                className="inline-flex items-center gap-1.5 px-4 py-2 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white text-xs font-bold"
              >
                <Search className="w-3.5 h-3.5" />
                <span>Find High-Fit Prospects</span>
              </button>
            )}
          </div>
        )}
      </div>

      {/* Best Prospects Section */}
      <div id="best-prospects-section" className="space-y-4">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2.5 pb-1 border-b border-slate-200 dark:border-slate-800">
          <div>
            <div className="flex items-center gap-2">
              <div className="p-1.5 rounded-xl bg-amber-500/10 text-amber-600 dark:text-amber-400 border border-amber-500/20">
                <Trophy className="w-5 h-5" />
              </div>
              <h2 className="text-lg sm:text-xl font-extrabold text-slate-900 dark:text-white tracking-tight">
                Best Prospects
              </h2>
              {allScoredProspects.length > 0 && (
                <span className="px-2.5 py-0.5 rounded-full text-xs font-bold bg-amber-100 dark:bg-amber-950/70 text-amber-800 dark:text-amber-300 border border-amber-300/50">
                  {topTierCount > 0 ? `${topTierCount} High Fit (80+)` : `${allScoredProspects.length} Scored`}
                </span>
              )}
            </div>
            <p className="text-xs text-slate-500 dark:text-slate-400 mt-1">
              Highest-scoring prospects ranked by Fit & Opportunity Score (0–100)
            </p>
          </div>

          <div className="flex items-center gap-2">
            {allScoredProspects.length > 0 && (
              <div className="flex items-center p-1 rounded-xl bg-slate-100 dark:bg-slate-800/80 border border-slate-200 dark:border-slate-700/60 text-xs">
                <button
                  type="button"
                  onClick={() => setBestFilter("all")}
                  className={`px-2.5 py-1 rounded-lg font-bold transition-colors ${
                    bestFilter === "all"
                      ? "bg-white dark:bg-slate-900 text-slate-900 dark:text-white shadow-xs"
                      : "text-slate-500 hover:text-slate-800 dark:hover:text-slate-200"
                  }`}
                >
                  All ({allScoredProspects.length})
                </button>
                <button
                  type="button"
                  onClick={() => setBestFilter("high")}
                  className={`px-2.5 py-1 rounded-lg font-bold transition-colors ${
                    bestFilter === "high"
                      ? "bg-white dark:bg-slate-900 text-emerald-600 dark:text-emerald-400 shadow-xs"
                      : "text-slate-500 hover:text-slate-800 dark:hover:text-slate-200"
                  }`}
                >
                  Score 80+ ({topTierCount})
                </button>
                <button
                  type="button"
                  onClick={() => setBestFilter("uncontacted")}
                  className={`px-2.5 py-1 rounded-lg font-bold transition-colors ${
                    bestFilter === "uncontacted"
                      ? "bg-white dark:bg-slate-900 text-indigo-600 dark:text-indigo-400 shadow-xs"
                      : "text-slate-500 hover:text-slate-800 dark:hover:text-slate-200"
                  }`}
                >
                  Uncontacted
                </button>
              </div>
            )}

            <button
              onClick={() => setActiveTab("prospects")}
              className="text-xs font-bold text-indigo-600 dark:text-indigo-400 hover:underline min-h-[36px] px-2 flex items-center gap-1"
            >
              <span>View all</span>
              <ArrowRight className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>

        {bestProspects.length > 0 ? (
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
            {bestProspects.map((prospect, idx) => {
              const score = prospect.analysis?.fitScore ?? prospect.analysis?.opportunityScore ?? 0;
              const confidence = prospect.analysis?.confidenceLevel || "High";
              const angle = prospect.analysis?.recommendedSalesAngle || prospect.analysis?.recommendedOutreachAngle;
              const observations = prospect.analysis?.businessObservations || prospect.analysis?.potentialProblems;

              return (
                <div
                  key={prospect.id}
                  className="p-5 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 hover:border-indigo-300 dark:hover:border-indigo-700/60 shadow-sm hover:shadow-md transition-all flex flex-col justify-between"
                >
                  <div>
                    {/* Card Top: Rank + Score + Confidence */}
                    <div className="flex items-center justify-between gap-2 mb-3">
                      <div className="flex items-center gap-2">
                        {idx === 0 ? (
                          <span className="px-2.5 py-0.5 rounded-full text-xs font-black bg-gradient-to-r from-amber-400 to-yellow-400 text-slate-950 shadow-xs flex items-center gap-1">
                            <Star className="w-3 h-3 fill-slate-950" />
                            <span>#1 Top Fit</span>
                          </span>
                        ) : idx === 1 ? (
                          <span className="px-2.5 py-0.5 rounded-full text-xs font-bold bg-slate-200 dark:bg-slate-700 text-slate-800 dark:text-slate-200 flex items-center gap-1">
                            <span>#2 Fit</span>
                          </span>
                        ) : idx === 2 ? (
                          <span className="px-2.5 py-0.5 rounded-full text-xs font-bold bg-amber-100 dark:bg-amber-950 text-amber-800 dark:text-amber-300 flex items-center gap-1">
                            <span>#3 Fit</span>
                          </span>
                        ) : (
                          <span className="px-2 py-0.5 rounded-full text-xs font-semibold bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-400">
                            #{idx + 1}
                          </span>
                        )}

                        <span className="text-xs text-slate-500 dark:text-slate-400">
                          {prospect.status}
                        </span>
                      </div>

                      {/* Score Badge */}
                      <div className="flex items-center gap-2">
                        <span
                          className={`text-xs font-bold px-2.5 py-1 rounded-xl flex items-center gap-1.5 ${
                            score >= 80
                              ? "bg-emerald-50 dark:bg-emerald-950/60 text-emerald-700 dark:text-emerald-300 border border-emerald-300/40"
                              : score >= 60
                              ? "bg-amber-50 dark:bg-amber-950/60 text-amber-700 dark:text-amber-300 border border-amber-300/40"
                              : "bg-slate-100 text-slate-700 dark:bg-slate-800 dark:text-slate-300"
                          }`}
                        >
                          <Sparkles className="w-3.5 h-3.5 text-emerald-500" />
                          <span className="font-extrabold text-sm">{score}</span>
                          <span className="text-[10px] text-slate-400">/100</span>
                        </span>

                        <span
                          className={`text-[10px] font-bold px-2 py-0.5 rounded-md ${
                            confidence === "High"
                              ? "bg-emerald-100/70 text-emerald-800 dark:bg-emerald-950/60 dark:text-emerald-400"
                              : confidence === "Medium"
                              ? "bg-blue-100/70 text-blue-800 dark:bg-blue-950/60 dark:text-blue-400"
                              : "bg-slate-100 text-slate-700 dark:bg-slate-800 dark:text-slate-300"
                          }`}
                        >
                          {confidence} Conf.
                        </span>
                      </div>
                    </div>

                    {/* Business Name and Metadata */}
                    <div className="mb-3">
                      <h3
                        onClick={() => onSelectProspect(prospect, "overview")}
                        className="text-base font-bold text-slate-900 dark:text-white hover:text-indigo-600 dark:hover:text-indigo-400 cursor-pointer transition-colors"
                      >
                        {prospect.businessName}
                      </h3>
                      <div className="flex flex-wrap items-center gap-2 text-xs text-slate-500 dark:text-slate-400 mt-1">
                        <span className="font-medium text-slate-700 dark:text-slate-300">
                          {prospect.contactName}
                        </span>
                        <span>•</span>
                        <span>{prospect.niche}</span>
                        <span>•</span>
                        <span>{prospect.country}</span>
                        {prospect.websiteUrl && (
                          <>
                            <span>•</span>
                            <a
                              href={prospect.websiteUrl.startsWith("http") ? prospect.websiteUrl : `https://${prospect.websiteUrl}`}
                              target="_blank"
                              rel="noopener noreferrer"
                              className="text-indigo-600 dark:text-indigo-400 hover:underline flex items-center gap-1"
                            >
                              <span>Website</span>
                              <ExternalLink className="w-2.5 h-2.5" />
                            </a>
                          </>
                        )}
                      </div>
                    </div>

                    {/* Sales Angle / Insight Box */}
                    {angle && (
                      <div className="p-3 rounded-xl bg-indigo-50/60 dark:bg-indigo-950/30 border border-indigo-100 dark:border-indigo-900/40 text-xs mb-3.5">
                        <span className="font-bold text-indigo-900 dark:text-indigo-300 block mb-0.5">
                          Recommended Angle:
                        </span>
                        <p className="text-slate-700 dark:text-slate-300 line-clamp-2 italic">
                          "{angle}"
                        </p>
                      </div>
                    )}
                  </div>

                  {/* 3 Core Quick Action Buttons */}
                  <div className="pt-3 border-t border-slate-100 dark:border-slate-800 flex flex-wrap items-center justify-between gap-2">
                    <div className="flex items-center gap-2">
                      <button
                        onClick={() => onSelectProspect(prospect, "analysis")}
                        className="px-3 py-1.5 rounded-xl bg-emerald-50 dark:bg-emerald-950/40 hover:bg-emerald-100 text-emerald-700 dark:text-emerald-300 text-xs font-bold border border-emerald-200 dark:border-emerald-800 flex items-center gap-1.5 transition-colors min-h-[38px]"
                      >
                        <Sparkles className="w-3.5 h-3.5" />
                        <span>View Analysis</span>
                      </button>

                      <button
                        onClick={() => onSelectProspect(prospect, "outreach")}
                        className="px-3 py-1.5 rounded-xl bg-indigo-50 dark:bg-indigo-950/40 hover:bg-indigo-100 text-indigo-700 dark:text-indigo-300 text-xs font-bold border border-indigo-200 dark:border-indigo-800 flex items-center gap-1.5 transition-colors min-h-[38px]"
                      >
                        <Send className="w-3.5 h-3.5" />
                        <span>Generate Outreach</span>
                      </button>
                    </div>

                    <button
                      onClick={() => onSelectProspect(prospect, "overview")}
                      className="text-xs font-semibold text-slate-500 hover:text-slate-800 dark:hover:text-slate-200 flex items-center gap-1 px-2 py-1 min-h-[38px]"
                    >
                      <span>Details</span>
                      <ChevronRight className="w-3.5 h-3.5" />
                    </button>
                  </div>
                </div>
              );
            })}
          </div>
        ) : (
          <div className="p-6 sm:p-8 rounded-2xl bg-white dark:bg-slate-900 border border-dashed border-slate-300 dark:border-slate-800 text-center">
            <div className="w-12 h-12 rounded-2xl bg-amber-100 dark:bg-amber-950/60 text-amber-600 dark:text-amber-400 flex items-center justify-center mx-auto mb-3">
              <Trophy className="w-6 h-6" />
            </div>
            <h3 className="text-base font-bold text-slate-900 dark:text-white mb-1">
              No Analyzed Prospects Yet
            </h3>
            <p className="text-xs text-slate-500 dark:text-slate-400 max-w-md mx-auto mb-4">
              Click any prospect and press <strong>ANALYZE PROSPECT</strong> to diagnose funnel pain points, calculate their 0–100 Fit Score, and rank your best sales opportunities here.
            </p>
            <button
              onClick={() => setActiveTab("prospects")}
              className="px-4 py-2.5 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white text-xs font-bold transition-all min-h-[44px] shadow-sm inline-flex items-center gap-2"
            >
              <span>View Prospects to Analyze</span>
              <ArrowRight className="w-4 h-4" />
            </button>
          </div>
        )}
      </div>

      {/* Ethical Direct Outreach Code of Conduct */}
      <div className="p-5 rounded-2xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-800 text-xs text-slate-600 dark:text-slate-400">
        <div className="flex items-start gap-3">
          <div className="p-2 rounded-xl bg-emerald-100 text-emerald-800 dark:bg-emerald-950/60 dark:text-emerald-300 shrink-0">
            <ShieldCheck className="w-5 h-5" />
          </div>
          <div>
            <h4 className="font-bold text-slate-900 dark:text-white text-sm mb-1">
              Ethical Outreach Principles & Best Practices
            </h4>
            <ul className="list-disc pl-4 space-y-1 leading-relaxed">
              <li>
                <strong>Solve real problems:</strong> Only recommend an all-in-one platform when it genuinely saves money, replaces broken plugins, or removes tech complexity for the creator.
              </li>
              <li>
                <strong>Zero spam:</strong> Never send unsolicited mass blasts. Every outreach should be 1-on-1, manual, and based on public facts.
              </li>
              <li>
                <strong>No deceptive claims:</strong> Never promise guaranteed earnings or claim you run the platform officially.
              </li>
              <li>
                <strong>Respect boundaries:</strong> If a prospect says no or does not reply after follow-ups, gracefully close the loop without pressure.
              </li>
            </ul>
          </div>
        </div>
      </div>
    </div>
  );
};
