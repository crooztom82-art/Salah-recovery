import React from "react";
import { ViewTab } from "../types";
import {
  LayoutDashboard,
  GitPullRequest,
  Users,
  Settings,
  Plus
} from "lucide-react";

interface BottomNavProps {
  activeTab: ViewTab;
  setActiveTab: (tab: ViewTab) => void;
  onOpenAddProspect: () => void;
  totalProspectsCount: number;
}

export const BottomNav: React.FC<BottomNavProps> = ({
  activeTab,
  setActiveTab,
  onOpenAddProspect,
  totalProspectsCount
}) => {
  return (
    <div
      id="mobile-bottom-nav"
      className="md:hidden fixed bottom-0 left-0 right-0 z-40 bg-white/95 dark:bg-slate-900/95 backdrop-blur-lg border-t border-slate-200 dark:border-slate-800 pb-safe transition-colors"
    >
      <div className="grid grid-cols-5 items-center h-16 px-1">
        {/* Dashboard */}
        <button
          id="mobile-nav-dashboard"
          onClick={() => setActiveTab("dashboard")}
          className={`flex flex-col items-center justify-center h-full min-h-[48px] py-1 transition-colors ${
            activeTab === "dashboard"
              ? "text-indigo-600 dark:text-indigo-400 font-bold"
              : "text-slate-500 dark:text-slate-400"
          }`}
        >
          <LayoutDashboard className="w-5 h-5 mb-0.5" />
          <span className="text-[11px] leading-tight">Home</span>
        </button>

        {/* Pipeline */}
        <button
          id="mobile-nav-pipeline"
          onClick={() => setActiveTab("pipeline")}
          className={`flex flex-col items-center justify-center h-full min-h-[48px] py-1 transition-colors ${
            activeTab === "pipeline"
              ? "text-indigo-600 dark:text-indigo-400 font-bold"
              : "text-slate-500 dark:text-slate-400"
          }`}
        >
          <GitPullRequest className="w-5 h-5 mb-0.5" />
          <span className="text-[11px] leading-tight">Pipeline</span>
        </button>

        {/* Big Central Add Button */}
        <div className="flex items-center justify-center">
          <button
            id="mobile-nav-add"
            onClick={onOpenAddProspect}
            aria-label="Add Prospect"
            className="w-12 h-12 rounded-full bg-indigo-600 text-white flex items-center justify-center shadow-lg shadow-indigo-600/40 active:scale-95 transition-transform"
          >
            <Plus className="w-6 h-6 stroke-[2.5]" />
          </button>
        </div>

        {/* Prospects List */}
        <button
          id="mobile-nav-prospects"
          onClick={() => setActiveTab("prospects")}
          className={`relative flex flex-col items-center justify-center h-full min-h-[48px] py-1 transition-colors ${
            activeTab === "prospects"
              ? "text-indigo-600 dark:text-indigo-400 font-bold"
              : "text-slate-500 dark:text-slate-400"
          }`}
        >
          <Users className="w-5 h-5 mb-0.5" />
          <span className="text-[11px] leading-tight">Prospects</span>
          {totalProspectsCount > 0 && (
            <span className="absolute top-2 right-4 w-4 h-4 bg-slate-200 dark:bg-slate-700 text-slate-800 dark:text-slate-200 text-[9px] font-bold rounded-full flex items-center justify-center">
              {totalProspectsCount > 99 ? "99+" : totalProspectsCount}
            </span>
          )}
        </button>

        {/* Settings */}
        <button
          id="mobile-nav-settings"
          onClick={() => setActiveTab("settings")}
          className={`flex flex-col items-center justify-center h-full min-h-[48px] py-1 transition-colors ${
            activeTab === "settings"
              ? "text-indigo-600 dark:text-indigo-400 font-bold"
              : "text-slate-500 dark:text-slate-400"
          }`}
        >
          <Settings className="w-5 h-5 mb-0.5" />
          <span className="text-[11px] leading-tight">Settings</span>
        </button>
      </div>
    </div>
  );
};
