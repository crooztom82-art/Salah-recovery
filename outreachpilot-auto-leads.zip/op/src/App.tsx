import React, { useState, useEffect } from "react";
import {
  Prospect,
  ProspectStatus,
  AppSettings,
  ViewTab,
  ToastMessage
} from "./types";
import { SAMPLE_PROSPECTS } from "./data/sampleProspects";
import { Navbar } from "./components/Navbar";
import { BottomNav } from "./components/BottomNav";
import { DashboardView } from "./components/DashboardView";
import { ProspectsView } from "./components/ProspectsView";
import { PipelineView } from "./components/PipelineView";
import { SettingsView } from "./components/SettingsView";
import { ProspectDetailModal } from "./components/ProspectDetailModal";
import { AddProspectModal } from "./components/AddProspectModal";
import { ImportCSVModal } from "./components/ImportCSVModal";
import { FindProspectsModal } from "./components/FindProspectsModal";
import { BulkAnalysisModal } from "./components/BulkAnalysisModal";
import { ToastContainer } from "./components/Toast";

const PROSPECTS_STORAGE_KEY = "outreachpilot_prospects_v1";
const SETTINGS_STORAGE_KEY = "outreachpilot_settings_v1";
const THEME_STORAGE_KEY = "outreachpilot_theme_v1";

const DEFAULT_SETTINGS: AppSettings = {
  affiliateLink: "",
  userName: "Alex Rivera",
  userEmail: "",
  defaultOutreachTone: "Helpful & Professional",
  autoAnalyzeNewProspects: true
};

export function App() {
  // Navigation
  const [activeTab, setActiveTab] = useState<ViewTab>("dashboard");

  // Prospects State initialized with localStorage
  const [prospects, setProspects] = useState<Prospect[]>(() => {
    try {
      const saved = localStorage.getItem(PROSPECTS_STORAGE_KEY);
      if (saved) {
        const parsed = JSON.parse(saved);
        if (Array.isArray(parsed) && parsed.length > 0) {
          return parsed;
        }
      }
    } catch (e) {
      console.warn("Failed to read prospects from localStorage", e);
    }
    return SAMPLE_PROSPECTS;
  });

  // Settings State initialized with localStorage
  const [settings, setSettings] = useState<AppSettings>(() => {
    try {
      const saved = localStorage.getItem(SETTINGS_STORAGE_KEY);
      if (saved) {
        return { ...DEFAULT_SETTINGS, ...JSON.parse(saved) };
      }
    } catch (e) {
      console.warn("Failed to read settings from localStorage", e);
    }
    return DEFAULT_SETTINGS;
  });

  // Dark Mode State
  const [darkMode, setDarkMode] = useState<boolean>(() => {
    try {
      const saved = localStorage.getItem(THEME_STORAGE_KEY);
      if (saved !== null) {
        return saved === "true";
      }
    } catch (e) {}
    return false;
  });

  // Modals state
  const [selectedProspect, setSelectedProspect] = useState<Prospect | null>(null);
  const [selectedProspectTab, setSelectedProspectTab] = useState<
    "overview" | "analysis" | "outreach" | "followups"
  >("overview");
  const [isAddModalOpen, setIsAddModalOpen] = useState(false);
  const [isImportModalOpen, setIsImportModalOpen] = useState(false);
  const [isFindProspectsOpen, setIsFindProspectsOpen] = useState(false);
  const [isBulkAnalysisOpen, setIsBulkAnalysisOpen] = useState(false);
  const [bulkAnalysisQueue, setBulkAnalysisQueue] = useState<Prospect[]>([]);

  // Toast feedback
  const [toasts, setToasts] = useState<ToastMessage[]>([]);

  const addToast = (text: string, type: "success" | "error" | "info" = "info") => {
    const newToast: ToastMessage = {
      id: `toast-${Date.now()}-${Math.random()}`,
      text,
      type
    };
    setToasts((prev) => [...prev, newToast]);
  };

  const removeToast = (id: string) => {
    setToasts((prev) => prev.filter((t) => t.id !== id));
  };

  // Sync Prospects to localStorage
  useEffect(() => {
    try {
      localStorage.setItem(PROSPECTS_STORAGE_KEY, JSON.stringify(prospects));
    } catch (e) {
      console.warn("Failed to write prospects to localStorage", e);
    }
  }, [prospects]);

  // Sync Settings to localStorage
  useEffect(() => {
    try {
      localStorage.setItem(SETTINGS_STORAGE_KEY, JSON.stringify(settings));
    } catch (e) {
      console.warn("Failed to write settings to localStorage", e);
    }
  }, [settings]);

  // Sync Dark mode to document class
  useEffect(() => {
    try {
      localStorage.setItem(THEME_STORAGE_KEY, String(darkMode));
    } catch (e) {}
    if (darkMode) {
      document.documentElement.classList.add("dark");
    } else {
      document.documentElement.classList.remove("dark");
    }
  }, [darkMode]);

  // Status Change Handler
  const handleStatusChange = (id: string, newStatus: ProspectStatus) => {
    setProspects((prev) =>
      prev.map((p) => {
        if (p.id === id) {
          const prevStatus = p.status;
          return {
            ...p,
            status: newStatus,
            updatedAt: new Date().toISOString(),
            lastContactedAt:
              newStatus === "Contacted" || newStatus === "Affiliate Link Sent"
                ? new Date().toISOString()
                : p.lastContactedAt,
            history: [
              ...(p.history || []),
              {
                date: new Date().toISOString(),
                action: `Pipeline stage updated from "${prevStatus}" to "${newStatus}"`,
                previousStatus: prevStatus,
                newStatus
              }
            ]
          };
        }
        return p;
      })
    );

    // Also update selectedProspect if currently open
    if (selectedProspect && selectedProspect.id === id) {
      setSelectedProspect((prev) => (prev ? { ...prev, status: newStatus } : null));
    }

    addToast(`Updated status to "${newStatus}"`, "success");
  };

  // Add Prospect Handler
  const handleAddProspect = async (newProspect: Prospect, runAnalysisImmediate?: boolean) => {
    setIsAddModalOpen(false);
    setProspects((prev) => [newProspect, ...prev]);
    addToast(`Added "${newProspect.businessName}" to pipeline!`, "success");

    // Open detail modal directly for the newly added prospect
    if (runAnalysisImmediate) {
      setSelectedProspect(newProspect);
      setSelectedProspectTab("analysis");

      // Trigger server-side analysis
      try {
        const res = await fetch("/api/analyze-prospect", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({
            businessName: newProspect.businessName,
            websiteUrl: newProspect.websiteUrl,
            contactName: newProspect.contactName,
            niche: newProspect.niche,
            country: newProspect.country,
            notes: newProspect.notes,
            publicBusinessInfo: newProspect.publicBusinessInfo
          })
        });
        const data = await res.json();
        if (data.success && data.analysis) {
          const updated: Prospect = {
            ...newProspect,
            analysis: {
              ...data.analysis,
              lastAnalyzedAt: new Date().toISOString()
            },
            history: [
              ...(newProspect.history || []),
              {
                date: new Date().toISOString(),
                action: `AI Opportunity analysis completed (Score: ${data.analysis.opportunityScore})`
              }
            ]
          };
          setProspects((prev) => prev.map((p) => (p.id === newProspect.id ? updated : p)));
          setSelectedProspect(updated);
          addToast(`Analysis ready! Fit score: ${data.analysis.opportunityScore}/100`, "success");
        }
      } catch (err) {
        console.error("Auto analysis failed", err);
      }
    } else {
      setSelectedProspect(newProspect);
      setSelectedProspectTab("overview");
    }
  };

  // Update Prospect
  const handleUpdateProspect = (updated: Prospect) => {
    setProspects((prev) => prev.map((p) => (p.id === updated.id ? updated : p)));
    if (selectedProspect && selectedProspect.id === updated.id) {
      setSelectedProspect(updated);
    }
  };

  // Delete Prospect
  const handleDeleteProspect = (id: string) => {
    setProspects((prev) => prev.filter((p) => p.id !== id));
    if (selectedProspect?.id === id) {
      setSelectedProspect(null);
    }
    addToast("Prospect removed from pipeline.", "info");
  };

  // Import CSV Handler
  const handleImportProspects = (imported: Prospect[]) => {
    setProspects((prev) => [...imported, ...prev]);
    addToast(`Successfully imported ${imported.length} prospects!`, "success");
  };

  // Bulk Analysis Handlers
  const handleOpenBulkAnalysis = (selected: Prospect[]) => {
    setBulkAnalysisQueue(selected);
    setIsBulkAnalysisOpen(true);
  };

  const handleUpdateBulkProspects = (updatedList: Prospect[]) => {
    setProspects((prev) => {
      const map = new Map(updatedList.map((p) => [p.id, p]));
      return prev.map((p) => map.get(p.id) || p);
    });
  };

  // Add Discovered Prospects Handler
  const handleAddDiscoveredProspects = (newProspects: Prospect[]) => {
    setProspects((prev) => [...newProspects, ...prev]);
    addToast(`Added ${newProspects.length} discovered prospects to your pipeline!`, "success");
  };

  // Open Prospect Detail Modal
  const handleSelectProspect = (
    prospect: Prospect,
    initialTab: "overview" | "analysis" | "outreach" | "followups" = "overview"
  ) => {
    setSelectedProspect(prospect);
    setSelectedProspectTab(initialTab);
  };

  return (
    <div className="min-h-screen bg-slate-50 dark:bg-slate-950 text-slate-900 dark:text-slate-100 flex flex-col font-sans transition-colors duration-200">
      {/* Top Navigation Bar */}
      <Navbar
        activeTab={activeTab}
        setActiveTab={setActiveTab}
        onOpenAddProspect={() => setIsAddModalOpen(true)}
        darkMode={darkMode}
        onToggleDarkMode={() => setDarkMode(!darkMode)}
        prospectsCount={prospects.length}
      />

      {/* Main Content Area */}
      <main className="flex-1 w-full max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pt-5 pb-24 lg:pb-12">
        {activeTab === "dashboard" && (
          <DashboardView
            prospects={prospects}
            setActiveTab={setActiveTab}
            onOpenAddProspect={() => setIsAddModalOpen(true)}
            onOpenFindProspects={() => setIsFindProspectsOpen(true)}
            onSelectProspect={handleSelectProspect}
            onStatusChange={handleStatusChange}
            affiliateLink={settings.affiliateLink || settings.systemeAffiliateLink || ""}
          />
        )}

        {activeTab === "prospects" && (
          <ProspectsView
            prospects={prospects}
            onSelectProspect={handleSelectProspect}
            onStatusChange={handleStatusChange}
            onOpenAddProspect={() => setIsAddModalOpen(true)}
            onOpenImportModal={() => setIsImportModalOpen(true)}
            onOpenFindProspects={() => setIsFindProspectsOpen(true)}
            onBulkAnalyze={handleOpenBulkAnalysis}
            onShowToast={addToast}
          />
        )}

        {activeTab === "pipeline" && (
          <PipelineView
            prospects={prospects}
            onSelectProspect={handleSelectProspect}
            onStatusChange={handleStatusChange}
            onOpenAddProspect={() => setIsAddModalOpen(true)}
          />
        )}

        {activeTab === "settings" && (
          <SettingsView
            settings={settings}
            onUpdateSettings={setSettings}
            prospects={prospects}
            onResetData={(newList) => {
              setProspects(newList);
            }}
            onShowToast={addToast}
            darkMode={darkMode}
            onToggleDarkMode={() => setDarkMode(!darkMode)}
          />
        )}
      </main>

      {/* Mobile Bottom Navigation */}
      <BottomNav
        activeTab={activeTab}
        setActiveTab={setActiveTab}
        onOpenAddProspect={() => setIsAddModalOpen(true)}
      />

      {/* Prospect Detail Modal */}
      {selectedProspect && (
        <ProspectDetailModal
          prospect={selectedProspect}
          initialTab={selectedProspectTab}
          onClose={() => setSelectedProspect(null)}
          onUpdateProspect={handleUpdateProspect}
          onDeleteProspect={handleDeleteProspect}
          affiliateLink={settings.affiliateLink || settings.systemeAffiliateLink || ""}
          onShowToast={addToast}
        />
      )}

      {/* Add Prospect Modal */}
      {isAddModalOpen && (
        <AddProspectModal
          onClose={() => setIsAddModalOpen(false)}
          onAddProspect={handleAddProspect}
        />
      )}

      {/* Import CSV Modal */}
      {isImportModalOpen && (
        <ImportCSVModal
          onClose={() => setIsImportModalOpen(false)}
          onImport={handleImportProspects}
        />
      )}

      {/* Find Prospects Discovery Modal */}
      <FindProspectsModal
        isOpen={isFindProspectsOpen}
        onClose={() => setIsFindProspectsOpen(false)}
        settings={settings}
        onAddProspects={handleAddDiscoveredProspects}
        onNavigateToSettings={() => {
          setIsFindProspectsOpen(false);
          setActiveTab("settings");
        }}
        onShowToast={addToast}
      />

      {/* Bulk Qualification Analysis Modal */}
      <BulkAnalysisModal
        isOpen={isBulkAnalysisOpen}
        onClose={() => setIsBulkAnalysisOpen(false)}
        selectedProspects={bulkAnalysisQueue}
        onUpdateProspects={handleUpdateBulkProspects}
        onShowToast={addToast}
      />

      {/* Toast notifications */}
      <ToastContainer toasts={toasts} onDismiss={removeToast} />
    </div>
  );
}
export default App;
