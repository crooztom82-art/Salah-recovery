import React, { useState } from "react";
import { Prospect, ProspectStatus } from "../types";
import { PIPELINE_STAGES } from "../data/sampleProspects";
import {
  Sparkles,
  ArrowRight,
  ArrowLeft,
  User,
  Plus,
  Compass,
  Send,
  MessageSquare,
  Link2,
  CheckCircle2,
  XCircle,
  ExternalLink,
  ChevronRight
} from "lucide-react";

interface PipelineViewProps {
  prospects: Prospect[];
  onSelectProspect: (prospect: Prospect, tab?: "overview" | "analysis" | "outreach" | "followups") => void;
  onStatusChange: (id: string, newStatus: ProspectStatus) => void;
  onOpenAddProspect: () => void;
}

export const PipelineView: React.FC<PipelineViewProps> = ({
  prospects,
  onSelectProspect,
  onStatusChange,
  onOpenAddProspect
}) => {
  // Active stage tab for smaller mobile view
  const [activeMobileStage, setActiveMobileStage] = useState<ProspectStatus>("Not Contacted");

  const stageIcons: Record<ProspectStatus, any> = {
    "Not Contacted": Compass,
    Contacted: Send,
    Replied: MessageSquare,
    Interested: Sparkles,
    "Affiliate Link Sent": Link2,
    Converted: CheckCircle2,
    "Not Interested": XCircle
  };

  const stageBadgeColors: Record<ProspectStatus, string> = {
    "Not Contacted": "bg-slate-100 text-slate-700 dark:bg-slate-800 dark:text-slate-300",
    Contacted: "bg-blue-100 text-blue-800 dark:bg-blue-950/60 dark:text-blue-300",
    Replied: "bg-purple-100 text-purple-800 dark:bg-purple-950/60 dark:text-purple-300",
    Interested: "bg-amber-100 text-amber-800 dark:bg-amber-950/60 dark:text-amber-300",
    "Affiliate Link Sent": "bg-cyan-100 text-cyan-800 dark:bg-cyan-950/60 dark:text-cyan-300",
    Converted: "bg-emerald-100 text-emerald-800 dark:bg-emerald-950/60 dark:text-emerald-300 font-bold",
    "Not Interested": "bg-rose-100 text-rose-800 dark:bg-rose-950/60 dark:text-rose-300"
  };

  // Stage order
  const stageOrder: ProspectStatus[] = [
    "Not Contacted",
    "Contacted",
    "Replied",
    "Interested",
    "Affiliate Link Sent",
    "Converted",
    "Not Interested"
  ];

  const getPreviousStage = (current: ProspectStatus): ProspectStatus | null => {
    const idx = stageOrder.indexOf(current);
    if (idx > 0 && idx < 6) {
      return stageOrder[idx - 1];
    }
    return null;
  };

  const getNextStage = (current: ProspectStatus): ProspectStatus | null => {
    const idx = stageOrder.indexOf(current);
    if (idx !== -1 && idx < 5) {
      return stageOrder[idx + 1];
    }
    return null;
  };

  return (
    <div id="pipeline-view" className="space-y-6 pb-12">
      {/* Pipeline Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
        <div>
          <h1 className="text-2xl font-extrabold text-slate-900 dark:text-white tracking-tight">
            CRM Pipeline
          </h1>
          <p className="text-xs sm:text-sm text-slate-500 dark:text-slate-400 mt-0.5">
            Advance prospects through each ethical touchpoint toward conversion
          </p>
        </div>

        <button
          onClick={onOpenAddProspect}
          className="flex items-center justify-center gap-1.5 px-4 py-2.5 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white text-xs font-bold shadow-sm transition-all min-h-[44px]"
        >
          <Plus className="w-4 h-4" />
          <span>Add Prospect</span>
        </button>
      </div>

      {/* Mobile Stage Selector Tabs (Shown on small screens) */}
      <div className="lg:hidden">
        <div className="flex items-center gap-1.5 overflow-x-auto pb-2 scrollbar-none">
          {PIPELINE_STAGES.map((st) => {
            const count = prospects.filter((p) => p.status === st).length;
            const Icon = stageIcons[st];
            const isSelected = activeMobileStage === st;
            return (
              <button
                key={st}
                onClick={() => setActiveMobileStage(st)}
                className={`flex items-center gap-1.5 px-3 py-2 rounded-xl text-xs font-semibold shrink-0 transition-all min-h-[44px] ${
                  isSelected
                    ? "bg-indigo-600 text-white shadow-md shadow-indigo-600/20"
                    : "bg-white dark:bg-slate-800 text-slate-600 dark:text-slate-300 border border-slate-200 dark:border-slate-700"
                }`}
              >
                <Icon className="w-3.5 h-3.5" />
                <span>{st}</span>
                <span
                  className={`text-[10px] px-1.5 py-0.2 rounded-full ${
                    isSelected
                      ? "bg-white/20 text-white"
                      : "bg-slate-100 dark:bg-slate-700 text-slate-700 dark:text-slate-300"
                  }`}
                >
                  {count}
                </span>
              </button>
            );
          })}
        </div>
      </div>

      {/* Mobile Single-Column Active Stage View */}
      <div className="lg:hidden">
        <div className="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200/80 dark:border-slate-800 p-4">
          <div className="flex items-center justify-between mb-4 pb-2 border-b border-slate-100 dark:border-slate-800">
            <div className="flex items-center gap-2">
              <span className={`px-2.5 py-1 rounded-lg text-xs font-bold ${stageBadgeColors[activeMobileStage]}`}>
                {activeMobileStage}
              </span>
              <span className="text-xs text-slate-400 font-medium">
                {prospects.filter((p) => p.status === activeMobileStage).length} prospects
              </span>
            </div>
          </div>

          <div className="space-y-3">
            {prospects
              .filter((p) => p.status === activeMobileStage)
              .map((prospect) => {
                const prev = getPreviousStage(prospect.status);
                const next = getNextStage(prospect.status);
                return (
                  <div
                    key={prospect.id}
                    className="p-4 rounded-xl border border-slate-200/80 dark:border-slate-800 bg-slate-50/50 dark:bg-slate-800/40 hover:bg-slate-50 dark:hover:bg-slate-800/80 transition-all"
                  >
                    <div className="flex items-start justify-between gap-2 mb-2">
                      <div>
                        <h4
                          onClick={() => onSelectProspect(prospect, "overview")}
                          className="font-bold text-sm text-slate-900 dark:text-white cursor-pointer hover:text-indigo-600 dark:hover:text-indigo-400"
                        >
                          {prospect.businessName}
                        </h4>
                        <div className="text-xs text-slate-500 dark:text-slate-400 flex items-center gap-1 mt-0.5">
                          <User className="w-3 h-3" />
                          <span>{prospect.contactName}</span>
                          <span>•</span>
                          <span>{prospect.niche}</span>
                        </div>
                      </div>

                      {prospect.analysis?.opportunityScore !== undefined && (
                        <span className="px-2 py-0.5 rounded text-[11px] font-bold bg-emerald-100 text-emerald-800 dark:bg-emerald-950/60 dark:text-emerald-300">
                          {prospect.analysis.opportunityScore}/100
                        </span>
                      )}
                    </div>

                    {/* Quick Move Buttons */}
                    <div className="flex items-center justify-between pt-2 border-t border-slate-200/60 dark:border-slate-700/60 mt-3">
                      {prev ? (
                        <button
                          onClick={() => onStatusChange(prospect.id, prev)}
                          className="flex items-center gap-1 text-xs font-medium text-slate-500 hover:text-slate-700 dark:text-slate-400 dark:hover:text-slate-200 p-1.5 rounded-lg min-h-[40px]"
                        >
                          <ArrowLeft className="w-3.5 h-3.5" />
                          <span className="truncate max-w-[90px]">{prev}</span>
                        </button>
                      ) : <div />}

                      <button
                        onClick={() => onSelectProspect(prospect, "outreach")}
                        className="px-3 py-1.5 rounded-lg text-xs font-semibold bg-indigo-50 dark:bg-indigo-950/50 text-indigo-700 dark:text-indigo-300 min-h-[40px] flex items-center"
                      >
                        Outreach &rarr;
                      </button>

                      {next ? (
                        <button
                          onClick={() => onStatusChange(prospect.id, next)}
                          className="flex items-center gap-1 text-xs font-bold text-indigo-600 dark:text-indigo-400 hover:text-indigo-800 p-1.5 rounded-lg min-h-[40px]"
                        >
                          <span className="truncate max-w-[90px]">{next}</span>
                          <ArrowRight className="w-3.5 h-3.5" />
                        </button>
                      ) : <div />}
                    </div>
                  </div>
                );
              })}

            {prospects.filter((p) => p.status === activeMobileStage).length === 0 && (
              <div className="text-center py-8 text-xs text-slate-400">
                No prospects in "{activeMobileStage}" currently.
              </div>
            )}
          </div>
        </div>
      </div>

      {/* Desktop / Large Screen Kanban Board (Horizontal Scrolling Columns) */}
      <div className="hidden lg:block overflow-x-auto pb-6 scrollbar-thin">
        <div className="flex gap-4 min-w-[1300px]">
          {PIPELINE_STAGES.map((stage) => {
            const stageProspects = prospects.filter((p) => p.status === stage);
            const Icon = stageIcons[stage];
            return (
              <div
                key={stage}
                id={`pipeline-column-${stage.toLowerCase().replace(/\s+/g, "-")}`}
                className="w-72 shrink-0 bg-slate-50/90 dark:bg-slate-800/40 rounded-2xl border border-slate-200/80 dark:border-slate-800 p-3.5 flex flex-col min-h-[600px]"
              >
                {/* Column Header */}
                <div className="flex items-center justify-between pb-3 mb-3 border-b border-slate-200/80 dark:border-slate-700/80">
                  <div className="flex items-center gap-2">
                    <Icon className="w-4 h-4 text-slate-500 dark:text-slate-400" />
                    <span className="font-bold text-xs text-slate-800 dark:text-slate-200">
                      {stage}
                    </span>
                  </div>
                  <span
                    className={`text-xs px-2 py-0.5 rounded-full font-bold ${
                      stageProspects.length > 0
                        ? "bg-white dark:bg-slate-700 text-slate-800 dark:text-slate-200 shadow-xs"
                        : "text-slate-400"
                    }`}
                  >
                    {stageProspects.length}
                  </span>
                </div>

                {/* Prospects in this column */}
                <div className="space-y-3 flex-1 overflow-y-auto max-h-[700px] pr-1">
                  {stageProspects.map((prospect) => {
                    const prev = getPreviousStage(prospect.status);
                    const next = getNextStage(prospect.status);
                    const score = prospect.analysis?.opportunityScore;

                    return (
                      <div
                        key={prospect.id}
                        className="p-3.5 rounded-xl bg-white dark:bg-slate-900 border border-slate-200/90 dark:border-slate-800/80 shadow-xs hover:shadow-md transition-all group flex flex-col justify-between"
                      >
                        <div>
                          <div className="flex items-start justify-between gap-1.5 mb-1.5">
                            <h4
                              onClick={() => onSelectProspect(prospect, "overview")}
                              className="font-bold text-sm text-slate-900 dark:text-white cursor-pointer hover:text-indigo-600 dark:hover:text-indigo-400 transition-colors line-clamp-1"
                              title={prospect.businessName}
                            >
                              {prospect.businessName}
                            </h4>
                            {score !== undefined && (
                              <span
                                className={`text-[10px] px-1.5 py-0.5 rounded font-bold shrink-0 ${
                                  score >= 80
                                    ? "bg-emerald-100 text-emerald-800 dark:bg-emerald-950/60 dark:text-emerald-300"
                                    : "bg-slate-100 text-slate-700 dark:bg-slate-800 dark:text-slate-300"
                                }`}
                              >
                                {score}
                              </span>
                            )}
                          </div>

                          <div className="text-[11px] text-slate-500 dark:text-slate-400 flex items-center gap-1 mb-2">
                            <User className="w-3 h-3 text-slate-400 shrink-0" />
                            <span className="truncate">{prospect.contactName}</span>
                          </div>

                          <div className="text-[11px] text-slate-500 dark:text-slate-400 bg-slate-50 dark:bg-slate-800/50 px-2 py-1 rounded-md mb-2 line-clamp-2">
                            {prospect.analysis?.recommendedOutreachAngle || prospect.notes || "No notes"}
                          </div>
                        </div>

                        {/* Card bottom stage move controls */}
                        <div className="pt-2 border-t border-slate-100 dark:border-slate-800 flex items-center justify-between">
                          {prev ? (
                            <button
                              onClick={() => onStatusChange(prospect.id, prev)}
                              title={`Move back to ${prev}`}
                              className="p-1 rounded text-slate-400 hover:text-slate-700 dark:hover:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors"
                            >
                              <ArrowLeft className="w-3.5 h-3.5" />
                            </button>
                          ) : (
                            <div className="w-5" />
                          )}

                          <button
                            onClick={() => onSelectProspect(prospect, "outreach")}
                            className="text-[11px] font-semibold text-indigo-600 dark:text-indigo-400 hover:underline px-1.5 py-0.5 rounded"
                          >
                            Outreach &rarr;
                          </button>

                          {next ? (
                            <button
                              onClick={() => onStatusChange(prospect.id, next)}
                              title={`Advance to ${next}`}
                              className="p-1 rounded text-indigo-600 dark:text-indigo-400 hover:bg-indigo-50 dark:hover:bg-indigo-950/50 transition-colors"
                            >
                              <ArrowRight className="w-3.5 h-3.5" />
                            </button>
                          ) : (
                            <div className="w-5" />
                          )}
                        </div>
                      </div>
                    );
                  })}

                  {stageProspects.length === 0 && (
                    <div className="text-center py-10 px-2 text-xs text-slate-400 border border-dashed border-slate-200 dark:border-slate-700/60 rounded-xl">
                      Empty stage
                    </div>
                  )}
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
};
