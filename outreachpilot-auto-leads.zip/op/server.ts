import express from "express";
import path from "path";
import fs from "fs";
import { createServer as createViteServer } from "vite";
import { GoogleGenAI, Type } from "@google/genai";
import dotenv from "dotenv";

dotenv.config();

const app = express();
const PORT = Number(process.env.PORT || 3000);

app.use(express.json({ limit: "10mb" }));

// Lazy initialization of Gemini client
let genAIClient: GoogleGenAI | null = null;
function getGenAI(): GoogleGenAI | null {
  if (!genAIClient && process.env.GEMINI_API_KEY) {
    try {
      genAIClient = new GoogleGenAI({
        apiKey: process.env.GEMINI_API_KEY,
        httpOptions: {
          headers: {
            "User-Agent": "aistudio-build",
          },
        },
      });
    } catch (err) {
      console.error("Failed to initialize GoogleGenAI:", err);
      return null;
    }
  }
  return genAIClient;
}

// Helper: Public Website Inspector for real verifiable signals
interface WebsiteInspection {
  accessible: boolean;
  url: string;
  title?: string;
  description?: string;
  visibleMarketingSignals: {
    leadForms?: boolean | string;
    emailNewsletterCapture?: boolean | string;
    landingPages?: boolean | string;
    funnels?: boolean | string;
    booking?: boolean | string;
    onlineSelling?: boolean | string;
    coursesDigitalProducts?: boolean | string;
  };
  visibleOpportunitySignals: string[];
  evidenceText: string;
  error?: string;
}

async function inspectPublicWebsite(targetUrl?: string): Promise<WebsiteInspection | null> {
  if (!targetUrl || !targetUrl.trim()) return null;
  let normalized = targetUrl.trim();
  if (!/^https?:\/\//i.test(normalized)) {
    normalized = "https://" + normalized;
  }

  try {
    const res = await fetch(normalized, {
      headers: {
        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36",
        "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8"
      },
      signal: AbortSignal.timeout(6000),
      redirect: "follow"
    });

    if (!res.ok) {
      return {
        accessible: false,
        url: normalized,
        visibleMarketingSignals: {},
        visibleOpportunitySignals: [],
        evidenceText: `Website returned HTTP status ${res.status}`,
        error: `HTTP ${res.status}`
      };
    }

    const html = await res.text();
    const titleMatch = html.match(/<title[^>]*>([^<]+)<\/title>/i);
    const title = titleMatch ? titleMatch[1].trim().replace(/\s+/g, " ") : undefined;

    const descMatch = html.match(/<meta\s+name=["']description["']\s+content=["']([^"']+)["']/i) ||
                      html.match(/<meta\s+property=["']og:description["']\s+content=["']([^"']+)["']/i);
    const description = descMatch ? descMatch[1].trim() : undefined;

    const lowerHtml = html.toLowerCase();

    // Check visible marketing signals strictly from public HTML
    const hasForms = lowerHtml.includes("<form") && (lowerHtml.includes('type="email"') || lowerHtml.includes("email") || lowerHtml.includes("newsletter"));
    const hasNewsletter = lowerHtml.includes("newsletter") || lowerHtml.includes("subscribe") || lowerHtml.includes("free guide") || lowerHtml.includes("opt-in") || lowerHtml.includes("lead magnet");
    const hasLandingPages = lowerHtml.includes("landing") || lowerHtml.includes("get started") || lowerHtml.includes("claim your") || lowerHtml.includes("free masterclass");
    const hasFunnels = lowerHtml.includes("funnel") || lowerHtml.includes("upsell") || lowerHtml.includes("order bump");
    const hasBooking = lowerHtml.includes("calendly") || lowerHtml.includes("acuity") || lowerHtml.includes("cal.com") || lowerHtml.includes("schedule") || lowerHtml.includes("book a call") || lowerHtml.includes("book now") || lowerHtml.includes("consultation");
    const hasSelling = lowerHtml.includes("checkout") || lowerHtml.includes("cart") || lowerHtml.includes("shopify") || lowerHtml.includes("woocommerce") || lowerHtml.includes("stripe") || lowerHtml.includes("paypal") || lowerHtml.includes("pricing") || lowerHtml.includes("buy now");
    const hasCourses = lowerHtml.includes("course") || lowerHtml.includes("curriculum") || lowerHtml.includes("membership") || lowerHtml.includes("member login") || lowerHtml.includes("portal") || lowerHtml.includes("teachable") || lowerHtml.includes("kajabi") || lowerHtml.includes("thinkific") || lowerHtml.includes("skool");

    const visibleMarketingSignals = {
      leadForms: hasForms ? "Verified: Active web form elements present" : "Not observed in public HTML",
      emailNewsletterCapture: hasNewsletter ? "Verified: Newsletter or lead magnet capture found" : "No visible email capture opt-in observed",
      landingPages: hasLandingPages ? "Verified: Dedicated landing page or prominent CTA banner" : "Standard static webpage structure",
      funnels: hasFunnels ? "Verified: Multi-stage sales funnel cues observed" : "No visible multi-step sales funnel found",
      booking: hasBooking ? "Verified: Online appointment scheduling or calendar links found" : "No automated calendar booking widget detected",
      onlineSelling: hasSelling ? "Verified: Digital checkout or payment portal found" : "No integrated self-serve checkout observed",
      coursesDigitalProducts: hasCourses ? "Verified: Course curriculum, portal, or member area detected" : "No digital course portal observed"
    };

    const visibleOpportunitySignals: string[] = [];
    if (!hasNewsletter && !hasForms) {
      visibleOpportunitySignals.push("Missing automated lead capture: No prominent newsletter opt-in or lead magnet form visible on homepage.");
    }
    if (hasBooking && !hasSelling) {
      visibleOpportunitySignals.push("High-touch sales flow: Relies on consultation calls without automated self-serve digital checkout funnels.");
    }
    if (hasCourses && !hasFunnels) {
      visibleOpportunitySignals.push("Course offer present without optimized 1-click upsells or automated email nurture sequences.");
    }
    if (hasSelling && !hasFunnels) {
      visibleOpportunitySignals.push("Standard cart checkout could be boosted with 1-page sales funnels, bump offers, and automated abandoned cart recovery.");
    }
    if (visibleOpportunitySignals.length === 0) {
      visibleOpportunitySignals.push("Unified all-in-one platform opportunity: Consolidate landing pages, email marketing, and checkout to eliminate disparate software costs.");
    }

    return {
      accessible: true,
      url: normalized,
      title,
      description,
      visibleMarketingSignals,
      visibleOpportunitySignals,
      evidenceText: `Public site analyzed: "${title || normalized}". Verified signals: ${Object.entries(visibleMarketingSignals).filter(([, v]) => typeof v === "string" && v.startsWith("Verified")).map(([k]) => k).join(", ") || "Standard public web presence"}.`
    };
  } catch (err: any) {
    return {
      accessible: false,
      url: normalized,
      visibleMarketingSignals: {},
      visibleOpportunitySignals: [],
      evidenceText: `Public website could not be accessed (${err.message}).`,
      error: err.message
    };
  }
}

// Helper: Heuristic Analysis fallback when Gemini API key is not present or API fails
function generateFallbackAnalysis(data: any, websiteInspection?: WebsiteInspection | null) {
  const { businessName, websiteUrl, contactName, niche, country, notes, publicBusinessInfo } = data;
  const combined = `${notes || ""} ${publicBusinessInfo || ""}`.toLowerCase();
  
  const observations: string[] = [];
  const observedFacts: string[] = [];
  
  if (businessName) {
    observedFacts.push(`Operates under brand name: ${businessName}`);
  }
  if (niche) {
    observedFacts.push(`Positioned in the ${niche} industry.`);
  }
  if (websiteUrl) {
    observedFacts.push(`Public web address: ${websiteUrl}`);
  }
  if (websiteInspection?.title) {
    observedFacts.push(`Verified homepage title: "${websiteInspection.title}"`);
  }
  if (notes && notes.trim()) {
    observedFacts.push(`User noted: "${notes.trim().slice(0, 120)}"`);
  }
  if (publicBusinessInfo && publicBusinessInfo.trim()) {
    observedFacts.push(`Provided info: "${publicBusinessInfo.trim().slice(0, 120)}"`);
  }
  if (observedFacts.length < 3) {
    observedFacts.push(`Target contact identifier: ${contactName || "Contact not specified"}`);
  }

  // Generate specific business observations
  observations.push(`Operates as a ${niche || "digital business"} offering products or services.`);
  if (websiteInspection?.accessible) {
    observations.push(`Live website accessible with public meta title: "${websiteInspection.title || 'Active site'}"`);
    if (websiteInspection.description) {
      observations.push(`Public site description: "${websiteInspection.description.slice(0, 100)}..."`);
    }
  } else if (websiteUrl) {
    observations.push(`Web address provided (${websiteUrl}), pending manual verification.`);
  } else {
    observations.push(`No public website URL provided.`);
  }
  if (notes || publicBusinessInfo) {
    observations.push(`Input notes highlight: ${(notes || publicBusinessInfo).slice(0, 100)}`);
  }

  let gaps: string[] = [];
  let solvingFeatures: string[] = [];
  let score = 75;
  let angle = "All-in-one software consolidation & reducing monthly overhead";
  let whyGood: string[] = [];
  let whyNotGoodOrLimitations: string[] = [];
  let confidence: "High" | "Medium" | "Low" = "Medium";
  let confidenceReasoning = "Moderate input detail provided. Basic business model known, but deeper tech stack requires verification.";

  // If no website accessible and no notes provided, mark as Insufficient Information
  if (!websiteInspection?.accessible && !notes && !publicBusinessInfo) {
    score = 30;
    confidence = "Low";
    confidenceReasoning = "Could not access or verify public website, and no business notes were supplied. Insufficient verifiable data to confirm tech fit.";
    gaps.push("Unverified digital infrastructure: Unable to inspect active lead capture or sales mechanisms.");
    solvingFeatures.push("An all-in-one platform provides a turnkey website builder, email marketing, and checkout setup from scratch.");
    whyGood.push("If launching or rebuilding online, an all-in-one platform with a generous current plan options removes all upfront software barriers.");
    whyNotGoodOrLimitations.push("Insufficient public information available to verify current tools or determine if an all-in-one platform is suitable.");
  } else if (combined.includes("wordpress") || combined.includes("plugins") || combined.includes("slow") || combined.includes("woocommerce")) {
    confidence = "High";
    confidenceReasoning = "High confidence due to explicit mention of WordPress/plugin maintenance pain points in provided notes.";
    gaps.push("Fragile plugin ecosystem: multiple WordPress plugins for forms, checkout, and newsletters require continuous updates.");
    gaps.push("Risk of checkout breakage and plugin conflicts leading to lost customer transactions.");
    gaps.push("Fragmented contact data across isolated plugins without native automated triggers.");
    
    solvingFeatures.push("Integrated Sales Funnel Builder replaces complex WordPress page and checkout plugins with one reliable hosted solution.");
    solvingFeatures.push("Native Email Marketing automatically triggers tag-based follow-ups immediately upon payment with zero integration latency.");
    solvingFeatures.push("Hosted Course & Digital Product portal grants instant access without separate LMS plugin licenses.");

    score = 88;
    angle = "Eliminating WordPress plugin maintenance headaches, security vulnerabilities, and checkout breakage.";
    whyGood.push("Directly solves the plugin fatigue and technical maintenance described in the user's notes.");
    whyGood.push("Provides a free or paid plan up to 2,000 contacts, allowing them to test alongside WordPress with zero financial risk.");
    whyNotGoodOrLimitations.push("If they rely heavily on custom PHP plugins or deep WooCommerce physical inventory extensions, migration requires workflow adaptation.");
  } else if (combined.includes("kajabi") || combined.includes("clickfunnels") || combined.includes("teachable") || combined.includes("expensive")) {
    confidence = "High";
    confidenceReasoning = "High confidence based on explicit mention of high-cost platform overhead in notes.";
    gaps.push("High recurring SaaS software overhead ($149 to $299+/month) creating cash flow drag.");
    gaps.push("Subscribers-based or tier-based price penalization as audience grows.");
    
    solvingFeatures.push("Full course and membership hosting with unlimited video storage on all plans, starting free.");
    solvingFeatures.push("Full sales funnels, email sequences, and affiliate program tracking in one monthly plan (saving up to $2,000+/year).");
    solvingFeatures.push("Zero platform transaction fees beyond standard Stripe/PayPal payment processor rates.");

    score = 92;
    angle = "Slashing monthly software subscription costs while retaining full course and email automation features.";
    whyGood.push("Immediate cost savings: replacing $150-$300/mo toolstack with an all-in-one current plan options or affordable startup plan.");
    whyGood.push("Feature equivalence for digital course hosting, lead magnets, and email newsletters.");
    whyNotGoodOrLimitations.push("Migrating existing courses and email lists requires an initial setup effort of a few hours.");
  } else {
    if (websiteInspection?.accessible) {
      confidence = "Medium";
      confidenceReasoning = "Public website successfully analyzed. Observed marketing cues indicate good digital readiness.";
    } else {
      confidence = "Low";
      confidenceReasoning = "Moderate information available. General niche characteristics used to assess opportunity.";
    }
    gaps.push("Potential leakage between lead generation and sales conversion due to disconnected tools.");
    gaps.push("Manual follow-up workload without unified email trigger sequences.");
    
    solvingFeatures.push("All-in-one lead capture, sales funnels, and automated email follow-up workflows under a single dashboard.");
    solvingFeatures.push("Generous current plan options with 2,000 contacts, unlimited email sending, and 3 full sales funnels.");

    score = 72;
    angle = "Simplifying your digital marketing and sales tech stack into one cost-effective system.";
    whyGood.push("Enables modern sales funnels and automated email follow-up without recurring software expenses.");
    whyGood.push("Risk-free evaluation due to the robust current plan options with no trial expiration.");
    whyNotGoodOrLimitations.push("If the business is strictly local/brick-and-mortar with no digital products or lead capture needs, funnels may not be their primary growth priority.");
  }

  const classification =
    score >= 80 ? "Strong Potential" :
    score >= 65 ? "Good Potential" :
    score >= 50 ? "Possible" :
    score >= 25 ? "Low Potential" : "Insufficient Information";

  return {
    opportunityScore: score,
    fitScore: score,
    fitClassification: classification,
    confidenceLevel: confidence,
    confidenceReasoning,
    website: websiteUrl || undefined,
    businessType: niche || "Digital Business",
    services: [niche || "Professional Services"],
    visibleMarketingSignals: websiteInspection?.visibleMarketingSignals || {},
    visibleOpportunitySignals: websiteInspection?.visibleOpportunitySignals || [
      "Consolidate separate tools for lead capture, email sequences, and customer checkout"
    ],
    evidenceSources: [
      {
        sourceUrl: websiteUrl || "User Input Data",
        pageSection: websiteInspection?.accessible ? "Public Homepage & Meta Tags" : "Manual Lead Entry",
        observation: websiteInspection?.evidenceText || `Input notes recorded for ${businessName || "prospect"}.`,
        timestamp: new Date().toISOString()
      }
    ],
    analysisTimestamp: new Date().toISOString(),
    businessObservations: observations.slice(0, 5),
    observedFacts,
    funnelGaps: gaps,
    potentialProblems: gaps,
    systemeSolvingFeatures: solvingFeatures,
    platformSolvingFeatures: solvingFeatures,
    systemeFitReasoning: `An all-in-one platform is a ${classification.toLowerCase()} match (${score}/100) because it unifies sales funnels, email marketing, digital courses, and checkout into one reliable platform with a plan that matches their needs.`,
    fitReasons: solvingFeatures,
    recommendedSalesAngle: angle,
    recommendedOutreachAngle: angle,
    whyGoodOrNot: {
      summary: `An all-in-one platform is a ${score >= 80 ? "high" : "moderate"} potential match based on the observed data.`,
      whyGood: whyGood.length > 0 ? whyGood : ["Generous current plan options allows testing with zero financial risk", "Replaces multiple software subscriptions"],
      whyNotGoodOrLimitations: whyNotGoodOrLimitations.length > 0 ? whyNotGoodOrLimitations : ["Needs verification of their exact current software stack during initial outreach"]
    },
    assumptions: [
      `Assumes ${businessName || "the business"} sells digital products, services, courses, or coaching online.`,
      `Assumes they want to reduce software complexity or recurring monthly SaaS overhead.`,
      "Must verify current platform satisfaction and email list size during personal dialogue."
    ]
  };
}

// API: Prospect Analysis with Real Public Website Inspection
app.post("/api/analyze-prospect", async (req, res) => {
  try {
    const { businessName, websiteUrl, contactName, niche, country, notes, publicBusinessInfo } = req.body;
    
    // Step 1: Perform automated real public website inspection if URL is present
    let websiteInspection: WebsiteInspection | null = null;
    if (websiteUrl && websiteUrl.trim()) {
      websiteInspection = await inspectPublicWebsite(websiteUrl);
    }

    const ai = getGenAI();

    if (!ai) {
      const fallback = generateFallbackAnalysis(req.body, websiteInspection);
      return res.json({ success: true, analysis: fallback, source: "rules_engine" });
    }

    const prompt = `You are an expert, ethical sales analyst evaluating a prospective customer for an all-in-one platform (providing funnel builder, email marketing, online courses/memberships, checkout, and automation with a 100% current plan options up to 2,000 contacts).
DO NOT mention any proprietary brand names (such as Systeme.io). Refer to the solution generically as "an all-in-one platform", "unified sales funnel and email platform", or "all-in-one marketing platform".

PROSPECT INFORMATION (STRICT FACTS):
- Business Name: ${businessName || "Not provided"}
- Website URL: ${websiteUrl || "Not provided"}
- Contact Name: ${contactName || "Decision Maker"}
- Niche/Industry: ${niche || "Digital Business"}
- Country: ${country || "Global"}
- User Notes: "${notes || "No notes provided"}"
- Public Business Info: "${publicBusinessInfo || "No public info provided"}"
- Live Public Website Analysis: ${
  websiteInspection?.accessible
    ? `Title: "${websiteInspection.title || "None"}", Description: "${websiteInspection.description || "None"}", Verified signals: ${JSON.stringify(websiteInspection.visibleMarketingSignals)}, Opportunity signals: ${JSON.stringify(websiteInspection.visibleOpportunitySignals)}`
    : websiteUrl
    ? `Website could not be accessed (${websiteInspection?.error || "unreachable"}).`
    : "No website URL was provided."
}

CRITICAL ANTI-HALLUCINATION & ETHICAL RULES:
1. Never invent website facts, monthly traffic numbers, revenue figures, specific technology usage, or customer complaints that were NOT provided or verified in the text above.
2. If the website could not be reached AND no user notes were provided, assign fitScore below 40, set confidenceLevel to "Low", and classification to "Insufficient Information".
3. Clearly separate OBSERVED FACTS from ASSUMPTIONS.
4. Provide:
   - fitScore: integer between 0 and 100
   - fitClassification: "Strong Potential" (80-100) | "Good Potential" (65-79) | "Possible" (50-64) | "Low Potential" (25-49) | "Insufficient Information" (below 25 or unverified)
   - confidenceLevel: "High" | "Medium" | "Low"
   - confidenceReasoning: 1-2 concise sentences explaining why confidence is High, Medium, or Low
   - businessObservations: 3 to 5 specific business observations based ONLY on verified information
   - observedFacts: 2 to 4 bullet points listing the literal facts provided
   - funnelGaps: 2 to 3 possible funnel or marketing gaps (cautious deductions from provided data)
   - platformSolvingFeatures: 2 to 3 specific all-in-one platform features that could potentially solve those gaps
   - recommendedSalesAngle: concise, value-focused outreach angle (e.g. saving money, stopping plugin breaks, current plan options)
   - whyGoodOrNot: an object with:
       * summary: concise 1-sentence verdict
       * whyGood: 2 to 3 specific reasons why this prospect may be a good prospect
       * whyNotGoodOrLimitations: 1 to 2 candid reasons why they may NOT be a good fit or potential limitations
   - assumptions: 2 to 3 clearly labeled assumptions that MUST be verified during 1-on-1 contact.`;

    const response = await ai.models.generateContent({
      model: "gemini-3.8-flash",
      contents: prompt,
      config: {
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            fitScore: { type: Type.INTEGER, description: "Fit Score: 0-100" },
            fitClassification: {
              type: Type.STRING,
              enum: ["Strong Potential", "Good Potential", "Possible", "Low Potential", "Insufficient Information"],
              description: "Standard fit classification"
            },
            confidenceLevel: { type: Type.STRING, enum: ["High", "Medium", "Low"], description: "Confidence level in assessment" },
            confidenceReasoning: { type: Type.STRING, description: "Reason for the assigned confidence level" },
            businessObservations: {
              type: Type.ARRAY,
              items: { type: Type.STRING },
              description: "3-5 specific business observations based ONLY on verified information"
            },
            observedFacts: {
              type: Type.ARRAY,
              items: { type: Type.STRING },
              description: "Literal facts extracted directly from user input or verified website"
            },
            funnelGaps: {
              type: Type.ARRAY,
              items: { type: Type.STRING },
              description: "Possible funnel/marketing gaps deduced strictly from verified info"
            },
            platformSolvingFeatures: {
              type: Type.ARRAY,
              items: { type: Type.STRING },
              description: "Specific all-in-one platform features that solve those gaps (without brand names)"
            },
            recommendedSalesAngle: {
              type: Type.STRING,
              description: "Recommended ethical sales angle"
            },
            whyGoodOrNot: {
              type: Type.OBJECT,
              properties: {
                summary: { type: Type.STRING },
                whyGood: { type: Type.ARRAY, items: { type: Type.STRING } },
                whyNotGoodOrLimitations: { type: Type.ARRAY, items: { type: Type.STRING } }
              },
              required: ["summary", "whyGood", "whyNotGoodOrLimitations"]
            },
            assumptions: {
              type: Type.ARRAY,
              items: { type: Type.STRING },
              description: "Clearly labeled assumptions to verify before outreach"
            }
          },
          required: [
            "fitScore",
            "fitClassification",
            "confidenceLevel",
            "confidenceReasoning",
            "businessObservations",
            "observedFacts",
            "funnelGaps",
            "platformSolvingFeatures",
            "recommendedSalesAngle",
            "whyGoodOrNot",
            "assumptions"
          ]
        }
      }
    });

    const parsed = JSON.parse(response.text || "{}");
    
    // Normalize and assemble comprehensive analysis result
    const analysisResult = {
      ...parsed,
      opportunityScore: parsed.fitScore ?? 75,
      fitScore: parsed.fitScore ?? 75,
      fitClassification: parsed.fitClassification || (parsed.fitScore >= 80 ? "Strong Potential" : parsed.fitScore >= 65 ? "Good Potential" : "Possible"),
      potentialProblems: parsed.funnelGaps || [],
      systemeSolvingFeatures: parsed.platformSolvingFeatures || [],
      platformSolvingFeatures: parsed.platformSolvingFeatures || [],
      systemeFitReasoning: parsed.whyGoodOrNot?.summary || "An all-in-one platform unifies sales funnels, email marketing, and course hosting with a generous current plan options.",
      fitReasons: parsed.platformSolvingFeatures || [],
      recommendedOutreachAngle: parsed.recommendedSalesAngle || "All-in-one software simplicity and reducing overhead",
      website: websiteUrl || undefined,
      businessType: niche || "Digital Business",
      services: [niche || "Services"],
      visibleMarketingSignals: websiteInspection?.visibleMarketingSignals || {},
      visibleOpportunitySignals: websiteInspection?.visibleOpportunitySignals || [],
      evidenceSources: [
        {
          sourceUrl: websiteUrl || "Manual Input",
          pageSection: websiteInspection?.accessible ? "Public Homepage & Meta Tags" : "Prospect Profile",
          observation: websiteInspection?.evidenceText || `Observations based on verified profile for ${businessName || "prospect"}.`,
          timestamp: new Date().toISOString()
        }
      ],
      analysisTimestamp: new Date().toISOString(),
      lastAnalyzedAt: new Date().toISOString()
    };

    return res.json({ success: true, analysis: analysisResult, source: "gemini" });
  } catch (error: any) {
    console.warn("Gemini analysis error, falling back to rule engine:", error.message);
    const fallback = generateFallbackAnalysis(req.body);
    return res.json({ success: true, analysis: fallback, source: "fallback_engine" });
  }
});

// API: Personalized Outreach Generator (Generic All-in-One Platform, No Brand Names)
app.post("/api/generate-outreach", async (req, res) => {
  try {
    const { prospect, affiliateLink, customAngle } = req.body;
    const ai = getGenAI();

    const firstName = prospect.contactName ? prospect.contactName.split(" ")[0] : "there";
    const biz = prospect.businessName || "your business";
    const linkStr = affiliateLink && affiliateLink.trim() ? affiliateLink.trim() : "[Partner Referral Link]";

    if (!ai) {
      const coldEmail = {
        subject: `Quick question regarding ${biz}'s online sales setup`,
        body: `Hi ${firstName},\n\nI was reviewing ${biz} and noticed your focus in the ${prospect.niche || "online"} space.\n\nI'm reaching out because many creators and business owners in your field find themselves managing separate, costly tools for email marketing, sales funnels, and courses—or dealing with plugins breaking during updates.\n\nThere is an all-in-one platform that unifies sales funnels, automated email marketing, and course hosting in a single intuitive dashboard with a 100% current plan options up to 2,000 subscribers and no transaction fees.\n\nIf you're completely satisfied with your current tech stack, no worries at all! But if you ever want to simplify or reduce monthly software overhead, you can take a look here: ${linkStr}\n\nBest regards,\n[Your Name]`
      };

      const linkedIn = {
        body: `Hi ${firstName}, saw what you're building with ${biz} in the ${prospect.niche || "industry"} space. I often share tech cost-saving tips with online business owners—many have recently consolidated separate funnel, email, and course subscriptions into an all-in-one platform (which has a generous permanent current plan options). Thought it might be worth having on your radar: ${linkStr}. Wishing you and ${biz} continued growth!`
      };

      const shortDmOrContactForm = {
        body: `Hi ${firstName},\n\nReaching out with a quick, honest resource for ${biz}. If you're ever looking to simplify your sales funnels, course delivery, or email automation without high monthly software bills, take a look at this all-in-one platform (${linkStr}). It has a current plan options for up to 2,000 contacts that replaces multiple subscriptions. No pressure at all—hope this helps!`
      };

      return res.json({
        success: true,
        messages: {
          coldEmail,
          linkedIn,
          shortDmOrContactForm,
          email: coldEmail,
          contactForm: shortDmOrContactForm,
          shortDm: {
            body: `Hey ${firstName}! Reaching out quickly from ${biz}'s page. If you're looking to cut software overhead for your funnels and email list, this all-in-one platform has a free or paid plan worth checking out: ${linkStr}. Hope it helps!`
          }
        },
        source: "rules_engine"
      });
    }

    const prompt = `You are crafting ethical, personalized direct outreach messages recommending an all-in-one platform (sales funnels, automated email marketing, courses, and checkout) with a 100% current plan options up to 2,000 contacts.
DO NOT mention any proprietary brand names (such as Systeme.io). Describe the service generically (e.g. "an all-in-one sales funnels and email automation platform", "an all-in-one platform").

STRICT ETHICAL & QUALITY MANDATES:
- Be personalized using ONLY provided prospect information.
- Be concise, natural, and conversational.
- Focus on the prospect's possible business problem (e.g. software cost, plugin maintenance, fragmented tools).
- Explain a relevant benefit (e.g. all-in-one platform, generous current plan options up to 2,000 contacts, course hosting, zero transaction fees).
- Have a soft, respectful call-to-action (no pushy pressure).
- Avoid fake personalization (do NOT claim you have followed them for years or know them personally).
- Avoid deceptive claims or guaranteed revenue promises.
- Never pretend that you personally know the prospect.
- Integrate the partner link naturally: ${linkStr}

Prospect details:
- Business Name: ${prospect.businessName || "their business"}
- Contact Name: ${prospect.contactName || "Decision Maker"}
- Website: ${prospect.websiteUrl || "Not specified"}
- Niche: ${prospect.niche || "Online Business"}
- Country: ${prospect.country || "Global"}
- Provided Notes: ${prospect.notes || "None"}
- Recommended Angle: ${customAngle || prospect.analysis?.recommendedSalesAngle || prospect.analysis?.recommendedOutreachAngle || "Simplifying sales funnels and reducing software overhead"}
- Identified Gaps: ${JSON.stringify(prospect.analysis?.funnelGaps || prospect.analysis?.potentialProblems || [])}
- Platform Features: ${JSON.stringify(prospect.analysis?.platformSolvingFeatures || prospect.analysis?.systemeSolvingFeatures || [])}

Generate exactly 3 messages:
1. Cold Email: Realistic, non-spammy subject line + concise 3-4 paragraph body with soft CTA.
2. LinkedIn message: Professional, crisp, friendly, natural networking tone under 400 characters.
3. Short DM / contact-form message: Concise, direct, courteous message suitable for website contact form or social DM.`;

    const response = await ai.models.generateContent({
      model: "gemini-3.8-flash",
      contents: prompt,
      config: {
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            coldEmail: {
              type: Type.OBJECT,
              properties: {
                subject: { type: Type.STRING, description: "Personalized, concise subject line" },
                body: { type: Type.STRING, description: "Structured body text with greeting, problem observation, platform value, link, and soft CTA" }
              },
              required: ["subject", "body"]
            },
            linkedIn: {
              type: Type.OBJECT,
              properties: {
                body: { type: Type.STRING, description: "Professional LinkedIn message with partner link" }
              },
              required: ["body"]
            },
            shortDmOrContactForm: {
              type: Type.OBJECT,
              properties: {
                body: { type: Type.STRING, description: "Short DM or website contact form message with partner link" }
              },
              required: ["body"]
            }
          },
          required: ["coldEmail", "linkedIn", "shortDmOrContactForm"]
        }
      }
    });

    const parsed = JSON.parse(response.text || "{}");
    const normalizedMessages = {
      ...parsed,
      email: parsed.coldEmail,
      contactForm: parsed.shortDmOrContactForm,
      shortDm: {
        body: parsed.shortDmOrContactForm?.body?.slice(0, 280) || parsed.linkedIn?.body || ""
      }
    };

    return res.json({ success: true, messages: normalizedMessages, source: "gemini" });
  } catch (error: any) {
    console.warn("Gemini outreach error, falling back:", error.message);
    const firstName = req.body?.prospect?.contactName ? req.body.prospect.contactName.split(" ")[0] : "there";
    const biz = req.body?.prospect?.businessName || "your business";
    const linkStr = req.body?.affiliateLink && req.body.affiliateLink.trim() ? req.body.affiliateLink.trim() : "[Partner Referral Link]";
    
    const fallbackCold = {
      subject: `Quick thought regarding ${biz}'s sales funnel setup`,
      body: `Hi ${firstName},\n\nHope your week is going well. I was reviewing ${biz} and wanted to reach out regarding your digital setup in the ${req.body?.prospect?.niche || "online"} space.\n\nMany entrepreneurs in this space are paying $150+/mo across disparate platforms for email, funnels, and checkout pages. An all-in-one platform lets you run all of that from one place—and includes a current plan options up to 2,000 contacts with zero transaction fees.\n\nIf you're ever curious to explore an all-in-one alternative, here is where you can check it out: ${linkStr}\n\nEither way, keep up the impressive work with ${biz}!\n\nBest regards,\n[Your Name]`
    };
    const fallbackLinkedIn = {
      body: `Hi ${firstName}, saw the great work you're doing with ${biz}. Just wanted to share a tool that's been saving founders a ton of overhead: an all-in-one funnel and email platform with a generous current plan options (${linkStr}). No worries if your current stack is locked in, but wanted to pass it along in case it's helpful!`
    };
    const fallbackShort = {
      body: `Hi ${firstName},\n\nReaching out with a quick resource for ${biz}. If you're looking for an easier or more cost-effective way to manage your funnels, email automation, or course delivery, check out this all-in-one platform (${linkStr}). It has a current plan options that replaces multiple expensive subscriptions. Hope this is valuable to your team!`
    };

    return res.json({
      success: true,
      messages: {
        coldEmail: fallbackCold,
        linkedIn: fallbackLinkedIn,
        shortDmOrContactForm: fallbackShort,
        email: fallbackCold,
        contactForm: fallbackShort,
        shortDm: {
          body: `Hey ${firstName}! Reaching out quickly from ${biz}'s page. If you're looking to cut software costs for your funnel and email list, this all-in-one platform has a free or paid plan worth checking out: ${linkStr}. Hope it helps!`
        }
      },
      source: "fallback_engine"
    });
  }
});

// API: Follow-up Generator (Generic All-in-One Platform, No Brand Names)
app.post("/api/generate-followups", async (req, res) => {
  try {
    const { prospect, affiliateLink, channel } = req.body;
    const ai = getGenAI();
    const firstName = prospect.contactName ? prospect.contactName.split(" ")[0] : "there";
    const biz = prospect.businessName || "your business";
    const linkStr = affiliateLink && affiliateLink.trim() ? affiliateLink.trim() : "[Partner Referral Link]";

    if (!ai) {
      return res.json({
        success: true,
        followUps: [
          {
            step: 1,
            label: "Gentle Value Check (3-4 days later)",
            timing: "Send 3-4 days after initial message",
            subject: `Re: Quick thought for ${biz}`,
            body: `Hi ${firstName},\n\nJust floating this to the top of your inbox in case it got buried. I know how busy running ${biz} can be!\n\nOne specific thing founders love about this all-in-one platform is that you can build full email automations and sales funnels without needing any third-party connectors like Zapier. The current plan options has no expiration date: ${linkStr}.\n\nNo pressure at all—hope you have a productive week!`
          },
          {
            step: 2,
            label: "Helpful Case / Comparison (7-10 days later)",
            timing: "Send 1 week after first follow-up",
            subject: `Quick comparison for ${biz}`,
            body: `Hi ${firstName},\n\nWanted to share a quick insight—a lot of creators in ${prospect.niche || "your niche"} switch over primarily because platforms like Kajabi or ClickFunnels cost $150–$300/mo, whereas this all-in-one platform offers identical course hosting, email broadcasting, and funnel features starting at $0.\n\nIf you ever review your software budget this quarter, here is the link to test it out: ${linkStr}.\n\nAlways happy to answer any questions if you decide to take a look.`
          },
          {
            step: 3,
            label: "Polite Closure / Respectful Breakup (14-21 days later)",
            timing: "Send 2 weeks after second follow-up",
            subject: `Closing the loop / Best of luck with ${biz}`,
            body: `Hi ${firstName},\n\nI don't want to clutter your inbox, so this will be my last note! I assume you're completely happy with your current tech setup for ${biz}, which is great.\n\nIf your needs change down the road or you want to migrate to an all-in-one system with the applicable current plan cost, the free account is always open at ${linkStr}.\n\nWishing you and ${biz} all the best!`
          }
        ],
        source: "rules_engine"
      });
    }

    const prompt = `You are generating 3 progressive, polite, ethical follow-up messages for a prospect who has not responded to an initial outreach about an all-in-one sales funnel, email marketing, and course platform.
DO NOT mention any proprietary brand names (such as Systeme.io). Refer to the solution generically as "the all-in-one platform", "an all-in-one sales funnel and email platform", etc.

STRICT ETHICAL GUIDELINES:
- No guilt-tripping ("Did you get eaten by an alligator?", "I guess my email wasn't important").
- Respect their time and boundaries.
- Provide genuine value or perspective in each message.
- Step 1: Gentle value-add & check-in (3-4 days after first outreach).
- Step 2: Practical comparison or feature benefit (7-10 days after).
- Step 3: Graceful, respectful closure / breakup note that closes the loop politely with zero pressure.
- Incorporate partner referral link naturally: ${linkStr}

Prospect:
- Business Name: ${prospect.businessName || "their business"}
- Contact Name: ${prospect.contactName || "there"}
- Niche: ${prospect.niche || "general"}
- Channel context: ${channel || "Email"}`;

    const response = await ai.models.generateContent({
      model: "gemini-3.8-flash",
      contents: prompt,
      config: {
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            followUps: {
              type: Type.ARRAY,
              items: {
                type: Type.OBJECT,
                properties: {
                  step: { type: Type.INTEGER },
                  label: { type: Type.STRING, description: "e.g. Gentle Value Check, Helpful Comparison, Respectful Closure" },
                  timing: { type: Type.STRING, description: "e.g. 3-4 days later" },
                  subject: { type: Type.STRING, description: "Optional subject line if email" },
                  body: { type: Type.STRING, description: "Full follow-up text" }
                },
                required: ["step", "label", "timing", "subject", "body"]
              }
            }
          },
          required: ["followUps"]
        }
      }
    });

    const parsed = JSON.parse(response.text || "{}");
    return res.json({ success: true, followUps: parsed.followUps || [], source: "gemini" });
  } catch (error: any) {
    console.warn("Gemini follow-up error, falling back:", error.message);
    const firstName = req.body?.prospect?.contactName ? req.body.prospect.contactName.split(" ")[0] : "there";
    const biz = req.body?.prospect?.businessName || "your business";
    const linkStr = req.body?.affiliateLink && req.body.affiliateLink.trim() ? req.body.affiliateLink.trim() : "[Partner Referral Link]";
    return res.json({
      success: true,
      followUps: [
        {
          step: 1,
          label: "Gentle Value Check",
          timing: "3-4 days later",
          subject: `Re: Quick thought for ${biz}`,
          body: `Hi ${firstName},\n\nJust bumping this quickly in case it slipped past you. Did you get a chance to see my earlier note regarding ${biz}'s funnel?\n\nThis all-in-one platform includes automated email sequences, landing pages, and course access in one place, completely free for up to 2,000 subscribers: ${linkStr}.\n\nNo rush at all—hope you're having a great week!`
        },
        {
          step: 2,
          label: "Cost & Complexity Comparison",
          timing: "7-10 days later",
          subject: `Cutting software overhead for ${biz}`,
          body: `Hi ${firstName},\n\nFollowing up with a brief thought—many businesses in ${req.body?.prospect?.niche || "your space"} find that consolidating Mailchimp, WordPress hosting, and checkout plugins into an all-in-one platform saves $50–$150/mo right away without losing automation features.\n\nHere is the current plan options overview if you'd like to benchmark your current costs: ${linkStr}.\n\nBest regards!`
        },
        {
          step: 3,
          label: "Respectful Breakup / Closing Loop",
          timing: "14-21 days later",
          subject: `Closing the loop on ${biz}`,
          body: `Hi ${firstName},\n\nI want to respect your inbox space, so I won't follow up further! If you're happy with your current funnel and marketing tools, that's completely understandable.\n\nShould you ever look to test an all-in-one alternative with a low-risk evaluation down the line, here's the link to keep on file: ${linkStr}.\n\nWishing you all the best with ${biz}!`
        }
      ],
      source: "fallback_engine"
    });
  }
});

// API: Prospect Discovery (Legitimate public search integration)
app.post("/api/discover-prospects", async (req, res) => {
  try {
    const {
      country = "Global",
      stateRegion = "",
      city = "",
      niche = "Digital Business",
      desiredCount = 5,
      minFitScore = 50,
      keywords = "",
      searchProviderConfig
    } = req.body;

    const cx =
      searchProviderConfig?.searchEngineId ||
      process.env.GOOGLE_SEARCH_CX;
    const provider = searchProviderConfig?.provider || (process.env.GEMINI_API_KEY ? "gemini_google_search" : (cx ? "google_custom_search" : "direct_search"));
    const apiKey =
      searchProviderConfig?.apiKey ||
      process.env.GOOGLE_SEARCH_API_KEY ||
      process.env.SERPAPI_API_KEY ||
      process.env.GOOGLE_PLACES_API_KEY;

    const queryParts = [niche];
    if (city) queryParts.push(city);
    if (stateRegion) queryParts.push(stateRegion);
    if (country && country !== "Global") queryParts.push(country);
    if (keywords) queryParts.push(keywords);
    queryParts.push('("coaching" OR "course" OR "services" OR "work with me")');
    const fullQuery = queryParts.join(" ");

    const locationStr = [city, stateRegion, country !== "Global" ? country : ""].filter(Boolean).join(" ");

    // Built-in Gemini Google Search needs only the app's server-side Gemini key.
    // It performs real-time public web search and returns citations; no separate search API key is required.
    if (provider === "gemini_google_search") {
      const geminiKey = process.env.GEMINI_API_KEY;
      if (!geminiKey) {
        return res.json({
          success: true,
          configured: false,
          provider,
          candidates: [],
          message: "Built-in live web search requires the app's GEMINI_API_KEY on the server. No separate search API key is needed."
        });
      }

      const requested = Math.min(Math.max(Number(desiredCount) || 5, 1), 20);
      const searchPrompt = `Find exactly up to ${requested} REAL businesses that match these prospecting criteria: niche=${niche}; country=${country}; region=${stateRegion || "any"}; city=${city || "any"}; extra keywords=${keywords || "none"}.

Use Google Search to find current public business websites. Only include a business when you can identify a real public website URL from the search results. Prefer the business's own official website over directory/social URLs. Do NOT invent a business, URL, email, phone number, contact person, or business fact. Do not include duplicates.

Return ONLY valid JSON in this exact shape:
{"candidates":[{"businessName":"...","websiteUrl":"https://...","sourceUrl":"https://...","publicBusinessInfo":"brief facts supported by the search result","evidence":["https://..."],"niche":"...","country":"...","city":"...","stateRegion":"..."}]}

The evidence URLs must be URLs that actually appeared in the search results. If fewer real businesses can be verified, return fewer. Never fill missing results with guesses.`;

      try {
        const geminiRes = await fetch(`https://generativelanguage.googleapis.com/v1beta/models/gemini-3.8-flash:generateContent?key=${encodeURIComponent(geminiKey)}`, {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({
            contents: [{ role: "user", parts: [{ text: searchPrompt }] }],
            tools: [{ google_search: {} }],
            generationConfig: { responseMimeType: "application/json" }
          }),
          signal: AbortSignal.timeout(45000)
        });

        if (!geminiRes.ok) {
          const errorText = await geminiRes.text();
          return res.status(400).json({ success: false, configured: true, provider, error: `Built-in Google Search failed (${geminiRes.status}): ${errorText.slice(0, 300)}` });
        }

        const geminiData: any = await geminiRes.json();
        const text = geminiData?.candidates?.[0]?.content?.parts?.map((p: any) => p.text || "").join("") || "";
        let parsed: any = {};
        try { parsed = JSON.parse(text); } catch {
          const match = text.match(/\{[\s\S]*\}/);
          if (match) parsed = JSON.parse(match[0]);
        }

        const rawCandidates = Array.isArray(parsed.candidates) ? parsed.candidates : [];
        const seenDomains = new Set<string>();

        for (const item of rawCandidates) {
          try {
            if (!item?.businessName || !item?.websiteUrl) continue;
            const websiteUrl = new URL(item.websiteUrl).toString();
            const domain = new URL(websiteUrl).hostname.replace(/^www\./, "").toLowerCase();
            if (!domain || seenDomains.has(domain)) continue;
            seenDomains.add(domain);
            const sourceUrl = item.sourceUrl || item.evidence?.[0] || websiteUrl;
            candidates.push({
              businessName: String(item.businessName).slice(0, 120),
              websiteUrl,
              contactName: undefined,
              niche: item.niche || niche,
              country: item.country || country,
              stateRegion: item.stateRegion || stateRegion || undefined,
              city: item.city || city || undefined,
              sourceUrl,
              notes: item.publicBusinessInfo || "Discovered through live public web search.",
              publicBusinessInfo: item.publicBusinessInfo || "Verified public business information was found in live search results.",
              evidence: Array.isArray(item.evidence) ? item.evidence : [sourceUrl],
              discoveryProvider: "gemini_google_search",
              initialFitScore: undefined,
              estimatedFitScore: undefined,
              fitClassification: "Insufficient Information"
            });
          } catch { /* skip invalid/fabricated URLs */ }
        }

        return res.json({
          success: true,
          configured: true,
          provider,
          candidates: candidates.slice(0, requested),
          searchedAt: new Date().toISOString(),
          message: candidates.length ? `Found ${Math.min(candidates.length, requested)} real public businesses via live web search.` : "No real businesses could be verified for these criteria."
        });
      } catch (error: any) {
        return res.status(500).json({ success: false, configured: true, provider, error: `Live web search error: ${error?.message || "Unknown error"}` });
      }
    }

    // If search provider is not configured or lacks credentials, cleanly return configuration status
    if (!apiKey || (provider === "google_custom_search" && !cx)) {
      return res.json({
        success: true,
        configured: false,
        provider,
        candidates: [],
        message: "No search provider API key configured. Please configure your API key in Settings, or use our instant Public Search query helper to find real businesses.",
        suggestedQueries: [
          `${niche} ${locationStr} "work with me" OR "contact"`,
          `${niche} ${locationStr} "courses" OR "programs"`,
          `${niche} ${locationStr} site:*.com "book a call"`
        ]
      });
    }

    const candidates: any[] = [];

    // Google Custom Search API
    if (provider === "google_custom_search" && apiKey && cx) {
      const numToFetch = Math.min(Math.max(desiredCount, 1), 10);
      const url = `https://www.googleapis.com/customsearch/v1?key=${encodeURIComponent(
        apiKey
      )}&cx=${encodeURIComponent(cx)}&q=${encodeURIComponent(fullQuery)}&num=${numToFetch}`;

      const apiRes = await fetch(url);
      if (!apiRes.ok) {
        const errorText = await apiRes.text();
        return res.status(400).json({
          success: false,
          configured: true,
          error: `Google Search API returned status ${apiRes.status}: ${errorText.slice(0, 200)}`
        });
      }

      const data: any = await apiRes.json();
      const items = data.items || [];

      for (const item of items) {
        try {
          const urlObj = new URL(item.link);
          const domain = urlObj.hostname.replace(/^www\./, "");
          // Derive realistic business name from title or site name
          let name = item.pagemap?.metatags?.[0]?.["og:site_name"] || item.title?.split(/[-–|]/)[0]?.trim() || domain;
          if (name.length > 50) name = name.slice(0, 50).trim();

          const snippet = item.snippet || "";
          const snippetLower = snippet.toLowerCase();

          // Estimate initial fit score based on visible public keywords
          let estScore = 65;
          if (snippetLower.includes("coach") || snippetLower.includes("course") || snippetLower.includes("consult")) estScore += 10;
          if (snippetLower.includes("wordpress") || snippetLower.includes("kajabi") || snippetLower.includes("expensive")) estScore += 10;
          if (snippetLower.includes("book") || snippetLower.includes("membership") || snippetLower.includes("client")) estScore += 5;

          if (estScore >= minFitScore) {
            candidates.push({
              businessName: name,
              websiteUrl: item.link,
              contactName: "Founder / Team",
              niche,
              country,
              stateRegion: stateRegion || undefined,
              city: city || undefined,
              sourceUrl: item.link,
              notes: snippet,
              publicBusinessInfo: `Discovered via public search query: "${fullQuery}". Description: ${snippet}`,
              estimatedFitScore: estScore,
              fitClassification: estScore >= 80 ? "Strong Potential" : estScore >= 65 ? "Good Potential" : "Possible"
            });
          }
        } catch {
          // Skip invalid URLs
        }
      }
    } else if (provider === "google_places" && apiKey) {
      // Google Places API (New) Text Search: returns real public business/place records.
      const numToFetch = Math.min(Math.max(desiredCount, 1), 20);
      const placesQuery = [niche, city, stateRegion, country !== "Global" ? country : "", keywords]
        .filter(Boolean)
        .join(", ");
      const placesUrl = "https://places.googleapis.com/v1/places:searchText";
      const placesRes = await fetch(placesUrl, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          "X-Goog-Api-Key": apiKey,
          "X-Goog-FieldMask": "places.id,places.displayName,places.formattedAddress,places.websiteUri,places.nationalPhoneNumber,places.location"
        },
        body: JSON.stringify({
          textQuery: placesQuery,
          pageSize: numToFetch,
          languageCode: "en"
        }),
        signal: AbortSignal.timeout(12000)
      });

      if (!placesRes.ok) {
        const errorText = await placesRes.text();
        return res.status(400).json({
          success: false,
          configured: true,
          provider,
          error: `Google Places API returned status ${placesRes.status}: ${errorText.slice(0, 300)}`
        });
      }

      const placesData: any = await placesRes.json();
      const places = placesData.places || [];

      for (const place of places) {
        const website = place.websiteUri;
        if (!website) continue;
        try {
          const urlObj = new URL(website);
          const domain = urlObj.hostname.replace(/^www\./, "");
          const name = place.displayName?.text?.trim() || domain;
          const address = place.formattedAddress || "";
          candidates.push({
            businessName: name,
            websiteUrl: website,
            niche,
            country,
            stateRegion: stateRegion || undefined,
            city: city || undefined,
            publicContactInfo: place.nationalPhoneNumber || undefined,
            sourceUrl: website,
            notes: `Found via Google Places Text Search. Public address: ${address || "Not returned"}.`,
            publicBusinessInfo: `Google Places public business record for ${name}. Address: ${address || "Not returned"}.`,
            evidence: [{ sourceUrl: website, label: "Business website", timestamp: new Date().toISOString() }],
            discoveryProvider: "google_places",
            providerPlaceId: place.id,
            initialFitScore: undefined,
            fitClassification: "Insufficient Information"
          });
        } catch {
          // Skip malformed website URLs.
        }
      }

      // Deduplicate by normalized domain before returning.
      const seen = new Set<string>();
      const uniqueCandidates = candidates.filter((candidate) => {
        try {
          const domain = new URL(candidate.websiteUrl).hostname.replace(/^www\./, "").toLowerCase();
          if (seen.has(domain)) return false;
          seen.add(domain);
          return true;
        } catch {
          return false;
        }
      });

      return res.json({
        success: true,
        configured: true,
        provider,
        candidates: uniqueCandidates.slice(0, desiredCount),
        count: uniqueCandidates.length,
        queryUsed: placesQuery,
        message: "Real public business records returned by Google Places. Fit scoring requires website analysis; no score was invented during discovery."
      });
    } else if (provider === "serpapi" && apiKey) {
      // SerpApi integration
      const numToFetch = Math.min(Math.max(desiredCount, 1), 10);
      const url = `https://serpapi.com/search.json?q=${encodeURIComponent(
        fullQuery
      )}&api_key=${encodeURIComponent(apiKey)}&num=${numToFetch}&engine=google`;

      const apiRes = await fetch(url);
      if (!apiRes.ok) {
        return res.status(400).json({
          success: false,
          configured: true,
          error: `SerpApi returned status ${apiRes.status}`
        });
      }

      const data: any = await apiRes.json();
      const organic = data.organic_results || [];

      for (const item of organic) {
        try {
          const urlObj = new URL(item.link);
          const domain = urlObj.hostname.replace(/^www\./, "");
          let name = item.title?.split(/[-–|]/)[0]?.trim() || domain;
          const snippet = item.snippet || "";
          let estScore = 65;
          if (snippet.toLowerCase().includes("coach") || snippet.toLowerCase().includes("course")) estScore += 12;

          if (estScore >= minFitScore) {
            candidates.push({
              businessName: name,
              websiteUrl: item.link,
              contactName: "Founder / Team",
              niche,
              country,
              stateRegion: stateRegion || undefined,
              city: city || undefined,
              sourceUrl: item.link,
              notes: snippet,
              publicBusinessInfo: snippet,
              estimatedFitScore: estScore,
              fitClassification: estScore >= 80 ? "Strong Potential" : estScore >= 65 ? "Good Potential" : "Possible"
            });
          }
        } catch {
          // Skip
        }
      }
    }

    return res.json({
      success: true,
      configured: true,
      provider,
      candidates: candidates.slice(0, desiredCount),
      count: candidates.length,
      queryUsed: fullQuery
    });
  } catch (error: any) {
    console.error("Prospect discovery error:", error);
    return res.status(500).json({ success: false, error: error.message });
  }
});

// Health API
app.get("/api/health", (req, res) => {
  res.json({
    status: "ok",
    hasGeminiKey: !!process.env.GEMINI_API_KEY,
    time: new Date().toISOString()
  });
});

// Server boot & Vite middleware
async function startServer() {
  const isProduction =
    process.env.NODE_ENV === "production" ||
    (typeof __filename !== "undefined" && (__filename.endsWith(".cjs") || __filename.includes("dist")));

  if (!isProduction) {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const candidateDirs = [
      path.join(process.cwd(), "dist"),
      typeof __dirname !== "undefined" ? __dirname : "",
      typeof __dirname !== "undefined" ? path.join(__dirname, "dist") : "",
      typeof __dirname !== "undefined" ? path.join(__dirname, "..", "dist") : "",
      process.cwd()
    ].filter(Boolean);

    const distPath = candidateDirs.find((dir) => fs.existsSync(path.join(dir, "index.html"))) || path.join(process.cwd(), "dist");

    app.use(express.static(distPath));
    app.get("*", (req, res) => {
      const indexPath = path.join(distPath, "index.html");
      if (fs.existsSync(indexPath)) {
        res.sendFile(indexPath);
      } else {
        res.status(404).send("Application build not found. Please run npm run build.");
      }
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`OutreachPilot server running on http://localhost:${PORT}`);
  });
}

startServer();
