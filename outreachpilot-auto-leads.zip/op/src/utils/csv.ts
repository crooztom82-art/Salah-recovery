import { Prospect, ProspectStatus } from "../types";

export function exportProspectsToCSV(prospects: Prospect[]): string {
  const headers = [
    "Business Name",
    "Website URL",
    "Contact Name",
    "Public Email",
    "Niche",
    "Country",
    "State / Province / Region",
    "City",
    "Status",
    "Fit Score",
    "Fit Classification",
    "Business Model",
    "Notes",
    "Public Contact Info",
    "Public Business Info",
    "Fit Reasoning",
    "Recommended Angle",
    "Created Date"
  ];

  const escapeCSV = (value: any) => {
    if (value === null || value === undefined) return '""';
    const str = String(value).replace(/"/g, '""');
    return `"${str}"`;
  };

  const rows = prospects.map((p) => [
    escapeCSV(p.businessName),
    escapeCSV(p.websiteUrl),
    escapeCSV(p.contactName),
    escapeCSV(p.publicBusinessEmail || ""),
    escapeCSV(p.niche),
    escapeCSV(p.country),
    escapeCSV(p.stateRegion || ""),
    escapeCSV(p.city || ""),
    escapeCSV(p.status),
    escapeCSV(p.analysis?.opportunityScore ?? ""),
    escapeCSV(p.fitClassification || p.analysis?.fitClassification || ""),
    escapeCSV(p.businessModel || ""),
    escapeCSV(p.notes),
    escapeCSV(p.publicContactInfo || ""),
    escapeCSV(p.publicBusinessInfo || ""),
    escapeCSV(p.analysis?.systemeFitReasoning || ""),
    escapeCSV(p.analysis?.recommendedOutreachAngle || ""),
    escapeCSV(p.createdAt)
  ]);

  return [headers.join(","), ...rows.map((r) => r.join(","))].join("\r\n");
}

export function downloadCSV(csvContent: string, fileName = "outreach-pilot-prospects.csv") {
  const blob = new Blob([csvContent], { type: "text/csv;charset=utf-8;" });
  const url = URL.createObjectURL(blob);
  const link = document.createElement("a");
  link.setAttribute("href", url);
  link.setAttribute("download", fileName);
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
  URL.revokeObjectURL(url);
}

// Robust CSV parser supporting quotes and multiline fields
export function parseCSV(csvText: string): Partial<Prospect>[] {
  const lines: string[] = [];
  let currentLine = "";
  let insideQuotes = false;

  for (let i = 0; i < csvText.length; i++) {
    const char = csvText[i];
    if (char === '"') {
      if (insideQuotes && csvText[i + 1] === '"') {
        currentLine += '"';
        i++; // skip escaped quote
      } else {
        insideQuotes = !insideQuotes;
      }
    } else if ((char === "\n" || char === "\r") && !insideQuotes) {
      if (char === "\r" && csvText[i + 1] === "\n") {
        i++;
      }
      if (currentLine.trim()) {
        lines.push(currentLine);
      }
      currentLine = "";
    } else {
      currentLine += char;
    }
  }
  if (currentLine.trim()) {
    lines.push(currentLine);
  }

  if (lines.length < 2) return [];

  // Parse a single CSV row into columns
  const parseRow = (rowStr: string): string[] => {
    const cols: string[] = [];
    let cur = "";
    let inQuote = false;
    for (let j = 0; j < rowStr.length; j++) {
      const c = rowStr[j];
      if (c === '"') {
        if (inQuote && rowStr[j + 1] === '"') {
          cur += '"';
          j++;
        } else {
          inQuote = !inQuote;
        }
      } else if (c === "," && !inQuote) {
        cols.push(cur.trim());
        cur = "";
      } else {
        cur += c;
      }
    }
    cols.push(cur.trim());
    return cols;
  };

  const headerRow = parseRow(lines[0]).map((h) => h.toLowerCase().replace(/[^a-z0-9]/g, ""));
  const parsedProspects: Partial<Prospect>[] = [];

  for (let i = 1; i < lines.length; i++) {
    const cols = parseRow(lines[i]);
    if (!cols.length || cols.every((c) => !c)) continue;

    const rowObj: Record<string, string> = {};
    headerRow.forEach((h, idx) => {
      rowObj[h] = cols[idx] || "";
    });

    const businessName =
      rowObj["businessname"] ||
      rowObj["company"] ||
      rowObj["business"] ||
      rowObj["name"] ||
      "Untitled Business";

    const websiteUrl = rowObj["websiteurl"] || rowObj["website"] || rowObj["url"] || "";
    const contactName =
      rowObj["contactname"] ||
      rowObj["contact"] ||
      rowObj["person"] ||
      "Founder";
    const publicBusinessEmail =
      rowObj["publicemail"] || rowObj["email"] || rowObj["businessemail"] || "";
    const niche = rowObj["niche"] || rowObj["category"] || rowObj["industry"] || "Other";
    const country = rowObj["country"] || "Global";
    const stateRegion = rowObj["stateprovinceregion"] || rowObj["stateregion"] || rowObj["region"] || rowObj["stateprovince"] || "";
    const city = rowObj["city"] || rowObj["statecity"] || "";
    const businessModel = rowObj["businessmodel"] || rowObj["model"] || "";
    const publicContactInfo = rowObj["publiccontactinfo"] || rowObj["contactinfo"] || rowObj["social"] || "";
    const notes = rowObj["notes"] || rowObj["description"] || "";
    const publicBusinessInfo = rowObj["publicbusinessinfo"] || rowObj["info"] || "";

    const rawStatus = rowObj["status"] || "Not Contacted";
    const validStatuses: ProspectStatus[] = [
      "Not Contacted",
      "Contacted",
      "Replied",
      "Interested",
      "Affiliate Link Sent",
      "Converted",
      "Not Interested"
    ];
    const matchedStatus =
      validStatuses.find((s) => s.toLowerCase() === rawStatus.toLowerCase()) ||
      "Not Contacted";

    const scoreNum = parseInt(rowObj["fitscore"] || rowObj["opportunityscore"] || rowObj["score"] || "", 10);
    const fitClassification = rowObj["fitclassification"] || rowObj["classification"] || undefined;

    parsedProspects.push({
      businessName,
      websiteUrl,
      contactName,
      publicBusinessEmail: publicBusinessEmail || undefined,
      niche,
      country,
      stateRegion: stateRegion || undefined,
      city: city || undefined,
      businessModel: businessModel || undefined,
      publicContactInfo: publicContactInfo || undefined,
      notes,
      publicBusinessInfo: publicBusinessInfo || undefined,
      status: matchedStatus,
      fitClassification: fitClassification as any,
      analysis: isNaN(scoreNum)
        ? undefined
        : {
            opportunityScore: scoreNum,
            fitScore: scoreNum,
            fitClassification: fitClassification as any,
            potentialProblems: [],
            systemeFitReasoning: rowObj["fitreasoning"] || rowObj["systemeiofitreasoning"] || "",
            fitReasons: [],
            recommendedOutreachAngle: rowObj["recommendedangle"] || "",
            assumptions: []
          }
    });
  }

  return parsedProspects;
}

export function parseCSVToProspects(csvText: string): Prospect[] {
  const partials = parseCSV(csvText);
  return partials.map((p, index) => ({
    id: `prospect-imported-${Date.now()}-${index}`,
    businessName: p.businessName || "Imported Business",
    websiteUrl: p.websiteUrl || "",
    contactName: p.contactName || "Contact",
    publicBusinessEmail: p.publicBusinessEmail,
    niche: p.niche || "Other",
    country: p.country || "Global",
    stateRegion: p.stateRegion,
    city: p.city,
    businessModel: p.businessModel,
    publicContactInfo: p.publicContactInfo,
    notes: p.notes || "",
    publicBusinessInfo: p.publicBusinessInfo,
    status: p.status || "Not Contacted",
    fitClassification: p.fitClassification,
    analysis: p.analysis,
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString(),
    history: [
      {
        date: new Date().toISOString(),
        action: "Imported from CSV"
      }
    ]
  }));
}
