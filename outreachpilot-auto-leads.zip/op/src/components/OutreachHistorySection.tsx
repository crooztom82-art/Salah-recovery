import React, { useState } from "react";
import { OutreachHistoryEntry, Prospect } from "../types";
import {
  Calendar,
  Mail,
  Send,
  MessageSquare,
  Plus,
  Trash2,
  Edit2,
  Copy,
  Check,
  CheckCircle2,
  Clock,
  ExternalLink,
  ChevronDown,
  X,
  FileText
} from "lucide-react";

interface OutreachHistorySectionProps {
  prospect: Prospect;
  historyEntries: OutreachHistoryEntry[];
  onAddEntry: (entry: Omit<OutreachHistoryEntry, "id">) => void;
  onUpdateEntry: (entry: OutreachHistoryEntry) => void;
  onDeleteEntry: (id: string) => void;
  onShowToast: (msg: string, type: "success" | "error" | "info") => void;
  isLogModalOpen?: boolean;
  onCloseLogModal?: () => void;
  initialLogData?: {
    channel: "Cold Email" | "LinkedIn" | "Short DM / Contact Form" | "Other";
    message: string;
    subject?: string;
  };
}

const RESPONSE_OPTIONS: OutreachHistoryEntry["response"][] = [
  "No Response / Pending",
  "Opened",
  "Replied Positive",
  "Replied Negative",
  "Requested Link",
  "Converted",
  "Follow-up Needed"
];

const CHANNEL_OPTIONS: OutreachHistoryEntry["channel"][] = [
  "Cold Email",
  "LinkedIn",
  "Short DM / Contact Form",
  "Other"
];

export const OutreachHistorySection: React.FC<OutreachHistorySectionProps> = ({
  prospect,
  historyEntries,
  onAddEntry,
  onUpdateEntry,
  onDeleteEntry,
  onShowToast,
  isLogModalOpen = false,
  onCloseLogModal,
  initialLogData
}) => {
  const [showAddForm, setShowAddForm] = useState(isLogModalOpen);
  const [editingId, setEditingId] = useState<string | null>(null);

  // Form State
  const [date, setDate] = useState(
    new Date().toISOString().split("T")[0]
  );
  const [channel, setChannel] = useState<OutreachHistoryEntry["channel"]>(
    initialLogData?.channel || "Cold Email"
  );
  const [subject, setSubject] = useState(initialLogData?.subject || "");
  const [message, setMessage] = useState(initialLogData?.message || "");
  const [response, setResponse] = useState<OutreachHistoryEntry["response"]>(
    "No Response / Pending"
  );
  const [notes, setNotes] = useState("");

  // Filters
  const [channelFilter, setChannelFilter] = useState<string>("all");
  const [responseFilter, setResponseFilter] = useState<string>("all");

  // Copy helper
  const [copiedId, setCopiedId] = useState<string | null>(null);

  const handleCopy = (text: string, id: string) => {
    navigator.clipboard.writeText(text);
    setCopiedId(id);
    onShowToast("Message copied to clipboard!", "success");
    setTimeout(() => {
      setCopiedId((prev) => (prev === id ? null : prev));
    }, 2000);
  };

  const resetForm = () => {
    setDate(new Date().toISOString().split("T")[0]);
    setChannel("Cold Email");
    setSubject("");
    setMessage("");
    setResponse("No Response / Pending");
    setNotes("");
    setEditingId(null);
    setShowAddForm(false);
    if (onCloseLogModal) onCloseLogModal();
  };

  const handleStartEdit = (entry: OutreachHistoryEntry) => {
    setEditingId(entry.id);
    setDate(entry.date);
    setChannel(entry.channel);
    setSubject(entry.subject || "");
    setMessage(entry.message);
    setResponse(entry.response);
    setNotes(entry.notes || "");
    setShowAddForm(true);
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!message.trim()) {
      onShowToast("Please enter the outreach message sent.", "error");
      return;
    }

    if (editingId) {
      onUpdateEntry({
        id: editingId,
        date,
        channel,
        subject: subject.trim() ? subject.trim() : undefined,
        message: message.trim(),
        response,
        notes: notes.trim() ? notes.trim() : undefined
      });
      onShowToast("Outreach record updated!", "success");
    } else {
      onAddEntry({
        date,
        channel,
        subject: subject.trim() ? subject.trim() : undefined,
        message: message.trim(),
        response,
        notes: notes.trim() ? notes.trim() : undefined
      });
      onShowToast("Outreach message logged successfully!", "success");
    }

    resetForm();
  };

  const filteredEntries = historyEntries.filter((entry) => {
    if (channelFilter !== "all" && entry.channel !== channelFilter) return false;
    if (responseFilter !== "all" && entry.response !== responseFilter) return false;
    return true;
  });

  const getResponseBadgeClass = (res: OutreachHistoryEntry["response"]) => {
    switch (res) {
      case "Converted":
        return "bg-emerald-100 text-emerald-800 dark:bg-emerald-950/70 dark:text-emerald-300 border-emerald-300";
      case "Replied Positive":
      case "Requested Link":
        return "bg-indigo-100 text-indigo-800 dark:bg-indigo-950/70 dark:text-indigo-300 border-indigo-300";
      case "Replied Negative":
        return "bg-rose-100 text-rose-800 dark:bg-rose-950/70 dark:text-rose-300 border-rose-300";
      case "Follow-up Needed":
        return "bg-amber-100 text-amber-800 dark:bg-amber-950/70 dark:text-amber-300 border-amber-300";
      case "Opened":
        return "bg-blue-100 text-blue-800 dark:bg-blue-950/70 dark:text-blue-300 border-blue-300";
      default:
        return "bg-slate-100 text-slate-700 dark:bg-slate-800 dark:text-slate-300 border-slate-300";
    }
  };

  const getChannelIcon = (ch: OutreachHistoryEntry["channel"]) => {
    switch (ch) {
      case "Cold Email":
        return <Mail className="w-4 h-4 text-blue-500" />;
      case "LinkedIn":
        return <MessageSquare className="w-4 h-4 text-sky-600" />;
      case "Short DM / Contact Form":
        return <Send className="w-4 h-4 text-indigo-500" />;
      default:
        return <FileText className="w-4 h-4 text-slate-500" />;
    }
  };

  return (
    <div className="space-y-5">
      {/* Header & Log Action */}
      <div className="p-4 rounded-2xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
        <div>
          <h3 className="text-sm font-bold text-slate-900 dark:text-white flex items-center gap-2">
            <Send className="w-4 h-4 text-indigo-500" />
            <span>Outreach History & Sent Touchpoints</span>
          </h3>
          <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">
            Keep track of the actual messages you sent, channels used, prospect replies, and notes.
          </p>
        </div>

        <button
          type="button"
          onClick={() => {
            resetForm();
            setShowAddForm(true);
          }}
          className="flex items-center justify-center gap-1.5 px-4 py-2.5 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white text-xs font-bold shadow-sm transition-all min-h-[44px]"
        >
          <Plus className="w-4 h-4" />
          <span>Record Sent Message</span>
        </button>
      </div>

      {/* Add / Edit Form Panel */}
      {showAddForm && (
        <form
          onSubmit={handleSubmit}
          className="p-5 rounded-2xl bg-white dark:bg-slate-900 border-2 border-indigo-200 dark:border-indigo-800 shadow-md space-y-4"
        >
          <div className="flex items-center justify-between border-b border-slate-100 dark:border-slate-800 pb-2.5">
            <h4 className="text-sm font-bold text-slate-900 dark:text-white flex items-center gap-2">
              <FileText className="w-4 h-4 text-indigo-600 dark:text-indigo-400" />
              <span>{editingId ? "Edit Outreach Record" : "Log New Outreach Message"}</span>
            </h4>
            <button
              type="button"
              onClick={resetForm}
              className="p-1.5 rounded-lg text-slate-400 hover:text-slate-700 dark:hover:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors"
            >
              <X className="w-5 h-5" />
            </button>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3.5">
            {/* Date */}
            <div>
              <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1">
                Date Sent *
              </label>
              <input
                type="date"
                required
                value={date}
                onChange={(e) => setDate(e.target.value)}
                className="w-full px-3 py-2 text-xs sm:text-sm rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-900 dark:text-white min-h-[40px] focus:ring-2 focus:ring-indigo-500 focus:outline-none"
              />
            </div>

            {/* Channel */}
            <div>
              <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1">
                Channel *
              </label>
              <select
                value={channel}
                onChange={(e) => setChannel(e.target.value as any)}
                className="w-full px-3 py-2 text-xs sm:text-sm rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-900 dark:text-white min-h-[40px] focus:ring-2 focus:ring-indigo-500 focus:outline-none"
              >
                {CHANNEL_OPTIONS.map((ch) => (
                  <option key={ch} value={ch}>
                    {ch}
                  </option>
                ))}
              </select>
            </div>

            {/* Response */}
            <div>
              <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1">
                Response Status *
              </label>
              <select
                value={response}
                onChange={(e) => setResponse(e.target.value as any)}
                className="w-full px-3 py-2 text-xs sm:text-sm rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-900 dark:text-white min-h-[40px] focus:ring-2 focus:ring-indigo-500 focus:outline-none"
              >
                {RESPONSE_OPTIONS.map((res) => (
                  <option key={res} value={res}>
                    {res}
                  </option>
                ))}
              </select>
            </div>
          </div>

          {/* Subject (Optional for email) */}
          {(channel === "Cold Email" || subject) && (
            <div>
              <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1">
                Subject Line (Optional)
              </label>
              <input
                type="text"
                placeholder="e.g. Quick question on your course setup"
                value={subject}
                onChange={(e) => setSubject(e.target.value)}
                className="w-full px-3 py-2 text-xs sm:text-sm rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-900 dark:text-white min-h-[40px] focus:ring-2 focus:ring-indigo-500 focus:outline-none"
              />
            </div>
          )}

          {/* Sent Message */}
          <div>
            <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1">
              Actual Message Sent *
            </label>
            <textarea
              required
              rows={4}
              placeholder="Paste or edit the exact message sent to this prospect..."
              value={message}
              onChange={(e) => setMessage(e.target.value)}
              className="w-full px-3 py-2.5 text-xs sm:text-sm rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-900 dark:text-white focus:ring-2 focus:ring-indigo-500 focus:outline-none font-sans leading-relaxed"
            />
          </div>

          {/* Notes */}
          <div>
            <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1">
              Follow-up Notes / Context (Optional)
            </label>
            <textarea
              rows={2}
              placeholder="Notes on replies, objections, affiliate link requests, or next step date..."
              value={notes}
              onChange={(e) => setNotes(e.target.value)}
              className="w-full px-3 py-2 text-xs sm:text-sm rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-900 dark:text-white focus:ring-2 focus:ring-indigo-500 focus:outline-none"
            />
          </div>

          <div className="flex items-center justify-end gap-2 pt-2 border-t border-slate-100 dark:border-slate-800">
            <button
              type="button"
              onClick={resetForm}
              className="px-4 py-2 rounded-xl text-xs font-semibold text-slate-600 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors min-h-[40px]"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="px-5 py-2 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white text-xs font-bold transition-all shadow-sm min-h-[40px]"
            >
              {editingId ? "Update Entry" : "Save to History"}
            </button>
          </div>
        </form>
      )}

      {/* Filter Toolbar */}
      {historyEntries.length > 0 && (
        <div className="flex flex-wrap items-center justify-between gap-2 text-xs">
          <div className="flex flex-wrap items-center gap-2">
            <span className="font-semibold text-slate-500">Filter:</span>
            <select
              value={channelFilter}
              onChange={(e) => setChannelFilter(e.target.value)}
              className="px-2.5 py-1.5 rounded-lg bg-slate-100 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-800 dark:text-slate-200 min-h-[36px]"
            >
              <option value="all">All Channels</option>
              {CHANNEL_OPTIONS.map((c) => (
                <option key={c} value={c}>
                  {c}
                </option>
              ))}
            </select>

            <select
              value={responseFilter}
              onChange={(e) => setResponseFilter(e.target.value)}
              className="px-2.5 py-1.5 rounded-lg bg-slate-100 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-800 dark:text-slate-200 min-h-[36px]"
            >
              <option value="all">All Responses</option>
              {RESPONSE_OPTIONS.map((r) => (
                <option key={r} value={r}>
                  {r}
                </option>
              ))}
            </select>
          </div>

          <span className="text-slate-400 font-medium">
            {filteredEntries.length} of {historyEntries.length} logged message{historyEntries.length === 1 ? "" : "s"}
          </span>
        </div>
      )}

      {/* Entries List */}
      {filteredEntries.length > 0 ? (
        <div className="space-y-3.5">
          {filteredEntries.map((entry) => (
            <div
              key={entry.id}
              className="p-4 sm:p-5 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-xs hover:border-indigo-200 dark:hover:border-indigo-900 transition-all space-y-3"
            >
              {/* Header Info */}
              <div className="flex flex-wrap items-center justify-between gap-2 pb-2 border-b border-slate-100 dark:border-slate-800">
                <div className="flex items-center gap-2">
                  <div className="p-1.5 rounded-lg bg-slate-100 dark:bg-slate-800">
                    {getChannelIcon(entry.channel)}
                  </div>
                  <div>
                    <span className="font-bold text-xs sm:text-sm text-slate-900 dark:text-white">
                      {entry.channel}
                    </span>
                    <span className="text-xs text-slate-400 ml-2">
                      {entry.date}
                    </span>
                  </div>
                </div>

                <div className="flex items-center gap-2">
                  <span
                    className={`text-[11px] font-bold px-2.5 py-0.5 rounded-full border ${getResponseBadgeClass(
                      entry.response
                    )}`}
                  >
                    {entry.response}
                  </span>

                  <button
                    type="button"
                    onClick={() => handleCopy(entry.message, entry.id)}
                    className="p-1.5 rounded-lg text-slate-400 hover:text-slate-700 dark:hover:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors min-h-[36px] min-w-[36px] flex items-center justify-center"
                    title="Copy message"
                  >
                    {copiedId === entry.id ? (
                      <Check className="w-4 h-4 text-emerald-500" />
                    ) : (
                      <Copy className="w-4 h-4" />
                    )}
                  </button>

                  <button
                    type="button"
                    onClick={() => handleStartEdit(entry)}
                    className="p-1.5 rounded-lg text-slate-400 hover:text-slate-700 dark:hover:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors min-h-[36px] min-w-[36px] flex items-center justify-center"
                    title="Edit entry"
                  >
                    <Edit2 className="w-4 h-4" />
                  </button>

                  <button
                    type="button"
                    onClick={() => {
                      if (confirm("Delete this outreach history record?")) {
                        onDeleteEntry(entry.id);
                      }
                    }}
                    className="p-1.5 rounded-lg text-rose-400 hover:text-rose-600 hover:bg-rose-50 dark:hover:bg-rose-950/40 transition-colors min-h-[36px] min-w-[36px] flex items-center justify-center"
                    title="Delete record"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                </div>
              </div>

              {/* Subject if email */}
              {entry.subject && (
                <div className="text-xs">
                  <span className="font-bold text-slate-500 dark:text-slate-400">Subject: </span>
                  <span className="font-semibold text-slate-800 dark:text-slate-200">
                    {entry.subject}
                  </span>
                </div>
              )}

              {/* Message Content */}
              <div className="p-3 rounded-xl bg-slate-50 dark:bg-slate-800/60 border border-slate-100 dark:border-slate-800 text-xs sm:text-sm text-slate-800 dark:text-slate-200 font-mono whitespace-pre-wrap leading-relaxed">
                {entry.message}
              </div>

              {/* Notes if present */}
              {entry.notes && (
                <div className="p-2.5 rounded-xl bg-amber-50/60 dark:bg-amber-950/30 border border-amber-100 dark:border-amber-900/40 text-xs text-amber-950 dark:text-amber-200">
                  <span className="font-bold block mb-0.5">Context / Notes:</span>
                  <p>{entry.notes}</p>
                </div>
              )}
            </div>
          ))}
        </div>
      ) : (
        <div className="text-center py-10 px-4 bg-slate-50 dark:bg-slate-800/40 rounded-3xl border border-dashed border-slate-200 dark:border-slate-800">
          <Send className="w-10 h-10 text-slate-400 mx-auto mb-2" />
          <h4 className="text-sm font-bold text-slate-800 dark:text-slate-200 mb-1">
            No Outreach History Logged Yet
          </h4>
          <p className="text-xs text-slate-500 dark:text-slate-400 max-w-md mx-auto mb-4">
            When you send a cold email, LinkedIn note, or DM to this prospect, log the message here or click "Save to Outreach History" on any generated message draft.
          </p>
          <button
            type="button"
            onClick={() => setShowAddForm(true)}
            className="px-4 py-2 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white text-xs font-bold transition-all min-h-[44px] shadow-sm inline-flex items-center gap-1.5"
          >
            <Plus className="w-4 h-4" />
            <span>Record First Outreach</span>
          </button>
        </div>
      )}
    </div>
  );
};
