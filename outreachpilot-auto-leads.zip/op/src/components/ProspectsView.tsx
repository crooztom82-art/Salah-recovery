import React, { useState, useMemo } from "react";
import { Prospect, ProspectStatus } from "../types";
import { NICHE_OPTIONS, COUNTRY_OPTIONS, PIPELINE_STAGES } from "../data/sampleProspects";
import {
  Search,
  Filter,
  Download,
  Upload,
  Plus,
  SlidersHorizontal,
  X,
  Users,
  Sparkles,
  ArrowUpDown
} from "lucide-react";
import { ProspectCard } from "./ProspectCard";
import { exportProspectsToCSV, downloadCSV } from "../utils/csv";

interface ProspectsViewProps {
  prospects: Prospect[];
  onSelectProspect: (prospect: Prospect, tab?: "overview" | "analysis" | "outreach" | "followups") => void;
  onStatusChange: (id: string, newStatus: ProspectStatus) => void;
  onOpenAddProspect: () => void;
  onOpenImportModal: () => void;
  onOpenFindProspects: () => void;
  onBulkAnalyze: (prospects: Prospect[]) => void;
  onShowToast: (msg: string, type: "success" | "error" | "info") => void;
}

export const ProspectsView: React.FC<ProspectsViewProps> = ({
  prospects,
  onSelectProspect,
  onStatusChange,
  onOpenAddProspect,
  onOpenImportModal,
  onOpenFindProspects,
  onBulkAnalyze,
  onShowToast
}) => {
  const [searchQuery, setSearchQuery] = useState("");
  const [selectedStatus, setSelectedStatus] = useState<string>("All");
  const [selectedNiche, setSelectedNiche] = useState<string>("All");
  const [selectedCountry, setSelectedCountry] = useState<string>("All");
  const [selectedScoreRange, setSelectedScoreRange] = useState<string>("All");
  const [sortBy, setSortBy] = useState<"score-desc" | "score-asc" | "newest" | "name-asc">("score-desc");
  const [showFilters, setShowFilters] = useState(false);
  const [selectedIds, setSelectedIds] = useState<Set<string>>(new Set());

  // Available unique niches and countries from current prospects
  const availableNiches = useMemo(() => {
    const set = new Set<string>();
    prospects.forEach((p) => {
      if (p.niche) set.add(p.niche);
    });
    return Array.from(set).sort();
  }, [prospects]);

  const availableCountries = useMemo(() => {
    const set = new Set<string>();
    prospects.forEach((p) => {
      if (p.country) set.add(p.country);
    });
    return Array.from(set).sort();
  }, [prospects]);

  // Filtering & Sorting
  const filteredProspects = useMemo(() => {
    return prospects
      .filter((p) => {
        // Search text
        if (searchQuery.trim()) {
          const q = searchQuery.toLowerCase();
          const matches =
            p.businessName.toLowerCase().includes(q) ||
            p.contactName.toLowerCase().includes(q) ||
            (p.publicBusinessEmail && p.publicBusinessEmail.toLowerCase().includes(q)) ||
            (p.notes && p.notes.toLowerCase().includes(q)) ||
            (p.websiteUrl && p.websiteUrl.toLowerCase().includes(q)) ||
            (p.niche && p.niche.toLowerCase().includes(q)) ||
            (p.city && p.city.toLowerCase().includes(q)) ||
            (p.country && p.country.toLowerCase().includes(q));
          if (!matches) return false;
        }

        // Status filter
        if (selectedStatus !== "All" && p.status !== selectedStatus) {
          return false;
        }

        // Niche filter
        if (selectedNiche !== "All" && p.niche !== selectedNiche) {
          return false;
        }

        // Country filter
        if (selectedCountry !== "All" && p.country !== selectedCountry) {
          return false;
        }

        // Opportunity score / classification filter
        if (selectedScoreRange !== "All") {
          const sc = p.analysis?.fitScore ?? p.analysis?.opportunityScore ?? -1;
          if (selectedScoreRange === "80+") {
            if (sc < 80) return false;
          } else if (selectedScoreRange === "65-79") {
            if (sc < 65 || sc > 79) return false;
          } else if (selectedScoreRange === "50-64") {
            if (sc < 50 || sc > 64) return false;
          } else if (selectedScoreRange === "<50") {
            if (sc >= 50 || sc < 0) return false;
          } else if (selectedScoreRange === "unscored") {
            if (sc !== -1) return false;
          }
        }

        return true;
      })
      .sort((a, b) => {
        const scA = a.analysis?.fitScore ?? a.analysis?.opportunityScore ?? -1;
        const scB = b.analysis?.fitScore ?? b.analysis?.opportunityScore ?? -1;

        if (sortBy === "score-desc") {
          return scB - scA;
        }
        if (sortBy === "score-asc") {
          return scA - scB;
        }
        if (sortBy === "newest") {
          return new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime();
        }
        if (sortBy === "name-asc") {
          return a.businessName.localeCompare(b.businessName);
        }
        return 0;
      });
  }, [prospects, searchQuery, selectedStatus, selectedNiche, selectedCountry, selectedScoreRange, sortBy]);

  // Selection handlers
  const toggleSelect = (id: string) => {
    const next = new Set(selectedIds);
    if (next.has(id)) {
      next.delete(id);
    } else {
      next.add(id);
    }
    setSelectedIds(next);
  };

  const handleSelectAll = () => {
    if (selectedIds.size === filteredProspects.length) {
      setSelectedIds(new Set());
    } else {
      setSelectedIds(new Set(filteredProspects.map((p) => p.id)));
    }
  };

  const handleTriggerBulkAnalysis = () => {
    const selected = prospects.filter((p) => selectedIds.has(p.id));
    if (selected.length === 0) {
      onShowToast("Select at least one prospect to analyze", "info");
      return;
    }
    onBulkAnalyze(selected);
  };

  // Export CSV handler
  const handleExportCSV = () => {
    try {
      const csvStr = exportProspectsToCSV(filteredProspects);
      downloadCSV(csvStr, `outreach-prospects-${new Date().toISOString().slice(0, 10)}.csv`);
      onShowToast(`Exported ${filteredProspects.length} prospects to CSV!`, "success");
    } catch (err: any) {
      onShowToast("Failed to export CSV.", "error");
    }
  };

  const hasActiveFilters =
    selectedStatus !== "All" ||
    selectedNiche !== "All" ||
    selectedCountry !== "All" ||
    selectedScoreRange !== "All" ||
    searchQuery.trim().length > 0;

  const resetFilters = () => {
    setSearchQuery("");
    setSelectedStatus("All");
    setSelectedNiche("All");
    setSelectedCountry("All");
    setSelectedScoreRange("All");
  };

  return (
    <div id="prospects-view" className="space-y-6 pb-16">
      {/* Header with Title and Discovery & CRM actions */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-extrabold text-slate-900 dark:text-white tracking-tight">
            Prospect Directory
          </h1>
          <p className="text-xs sm:text-sm text-slate-500 dark:text-slate-400 mt-0.5">
            Discover, qualify, and organize targeted business candidates
          </p>
        </div>

        {/* Action buttons (Find Prospects, CSV Export/Import & Add) */}
        <div className="flex flex-wrap items-center gap-2">
          <button
            id="find-prospects-header-btn"
            onClick={onOpenFindProspects}
            className="flex items-center gap-1.5 px-3.5 py-2 rounded-xl bg-gradient-to-r from-indigo-600 to-indigo-700 hover:from-indigo-700 hover:to-indigo-800 text-white text-xs font-bold shadow-sm shadow-indigo-600/25 transition-all min-h-[44px]"
            title="Discover new prospects using legitimate public search"
          >
            <Search className="w-4 h-4" />
            <span>Find Prospects</span>
          </button>

          <button
            id="export-csv-btn"
            onClick={handleExportCSV}
            className="flex items-center gap-1.5 px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-700 dark:text-slate-200 hover:bg-slate-50 dark:hover:bg-slate-700 text-xs font-semibold transition-colors min-h-[44px]"
            title="Export filtered prospects to CSV"
          >
            <Download className="w-4 h-4 text-slate-500" />
            <span>Export CSV</span>
          </button>

          <button
            id="import-csv-btn"
            onClick={onOpenImportModal}
            className="flex items-center gap-1.5 px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-700 dark:text-slate-200 hover:bg-slate-50 dark:hover:bg-slate-700 text-xs font-semibold transition-colors min-h-[44px]"
            title="Import prospects from CSV"
          >
            <Upload className="w-4 h-4 text-slate-500" />
            <span>Import CSV</span>
          </button>

          <button
            id="prospects-add-btn"
            onClick={onOpenAddProspect}
            className="flex items-center gap-1.5 px-4 py-2 rounded-xl bg-slate-900 dark:bg-white dark:text-slate-900 text-white text-xs font-bold hover:bg-slate-800 transition-all min-h-[44px]"
          >
            <Plus className="w-4 h-4" />
            <span>Add Prospect</span>
          </button>
        </div>
      </div>

      {/* Floating or Sticky Multi-Select Action Bar */}
      {selectedIds.size > 0 && (
        <div className="sticky top-16 z-30 flex items-center justify-between gap-3 p-3 sm:p-4 rounded-2xl bg-indigo-900 text-white shadow-xl shadow-indigo-950/20 border border-indigo-700 animate-in fade-in slide-in-from-top-2">
          <div className="flex items-center gap-2 sm:gap-3">
            <span className="w-6 h-6 rounded-full bg-indigo-700 flex items-center justify-center text-xs font-bold">
              {selectedIds.size}
            </span>
            <span className="text-xs sm:text-sm font-semibold">
              {selectedIds.size === 1 ? "1 prospect selected" : `${selectedIds.size} prospects selected`}
            </span>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={handleTriggerBulkAnalysis}
              className="flex items-center gap-1.5 px-3.5 py-2 rounded-xl bg-white text-indigo-900 text-xs font-bold hover:bg-indigo-50 shadow-sm transition-all min-h-[40px]"
            >
              <Sparkles className="w-4 h-4 text-indigo-600" />
              <span>Analyze Selected ({selectedIds.size})</span>
            </button>

            <button
              onClick={() => setSelectedIds(new Set())}
              className="p-2 rounded-xl text-indigo-200 hover:text-white hover:bg-indigo-800 transition-colors"
              title="Clear selection"
            >
              <X className="w-4 h-4" />
            </button>
          </div>
        </div>
      )}

      {/* Search and Filter Bar */}
      <div className="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200/80 dark:border-slate-800 p-4 shadow-sm space-y-3">
        <div className="flex items-center gap-2">
          {/* Main search input */}
          <div className="relative flex-1">
            <Search className="w-4 h-4 absolute left-3.5 top-1/2 -translate-y-1/2 text-slate-400" />
            <input
              type="text"
              id="prospect-search-input"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Search by business, contact, notes, URL, city, or niche..."
              className="w-full pl-10 pr-9 py-2.5 rounded-xl text-sm bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 focus:outline-none focus:ring-2 focus:ring-indigo-500 text-slate-900 dark:text-white placeholder-slate-400 min-h-[44px]"
            />
            {searchQuery && (
              <button
                onClick={() => setSearchQuery("")}
                className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-600"
              >
                <X className="w-4 h-4" />
              </button>
            )}
          </div>

          {/* Filter toggle button */}
          <button
            onClick={() => setShowFilters(!showFilters)}
            className={`flex items-center gap-1.5 px-3.5 py-2.5 rounded-xl border text-xs font-semibold transition-colors min-h-[44px] ${
              showFilters || hasActiveFilters
                ? "bg-indigo-50 dark:bg-indigo-950/50 border-indigo-200 dark:border-indigo-800 text-indigo-700 dark:text-indigo-300"
                : "border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-700 dark:text-slate-300 hover:bg-slate-100"
            }`}
          >
            <SlidersHorizontal className="w-4 h-4" />
            <span className="hidden sm:inline">Filters</span>
            {hasActiveFilters && (
              <span className="w-2 h-2 rounded-full bg-indigo-600" />
            )}
          </button>
        </div>

        {/* Expandable Filter Row */}
        {(showFilters || hasActiveFilters) && (
          <div className="pt-3 border-t border-slate-100 dark:border-slate-800 grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-3">
            {/* Filter by Status */}
            <div>
              <label className="block text-[11px] font-bold text-slate-500 dark:text-slate-400 mb-1">
                Status
              </label>
              <select
                id="filter-status-select"
                value={selectedStatus}
                onChange={(e) => setSelectedStatus(e.target.value)}
                className="w-full text-xs py-2 px-2.5 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-indigo-500 min-h-[40px]"
              >
                <option value="All">All Statuses ({prospects.length})</option>
                {PIPELINE_STAGES.map((st) => (
                  <option key={st} value={st}>
                    {st} ({prospects.filter((p) => p.status === st).length})
                  </option>
                ))}
              </select>
            </div>

            {/* Filter by Niche */}
            <div>
              <label className="block text-[11px] font-bold text-slate-500 dark:text-slate-400 mb-1">
                Niche / Category
              </label>
              <select
                id="filter-niche-select"
                value={selectedNiche}
                onChange={(e) => setSelectedNiche(e.target.value)}
                className="w-full text-xs py-2 px-2.5 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-indigo-500 min-h-[40px]"
              >
                <option value="All">All Niches</option>
                {availableNiches.map((n) => (
                  <option key={n} value={n}>
                    {n}
                  </option>
                ))}
              </select>
            </div>

            {/* Filter by Country */}
            <div>
              <label className="block text-[11px] font-bold text-slate-500 dark:text-slate-400 mb-1">
                Country
              </label>
              <select
                id="filter-country-select"
                value={selectedCountry}
                onChange={(e) => setSelectedCountry(e.target.value)}
                className="w-full text-xs py-2 px-2.5 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-indigo-500 min-h-[40px]"
              >
                <option value="All">All Countries</option>
                {availableCountries.map((c) => (
                  <option key={c} value={c}>
                    {c}
                  </option>
                ))}
              </select>
            </div>

            {/* Filter by Fit Score & Classification */}
            <div>
              <label className="block text-[11px] font-bold text-slate-500 dark:text-slate-400 mb-1">
                Fit Score & Classification
              </label>
              <select
                id="filter-score-select"
                value={selectedScoreRange}
                onChange={(e) => setSelectedScoreRange(e.target.value)}
                className="w-full text-xs py-2 px-2.5 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-indigo-500 min-h-[40px]"
              >
                <option value="All">All Scores (0–100)</option>
                <option value="80+">Strong Potential (80–100)</option>
                <option value="65-79">Good Potential (65–79)</option>
                <option value="50-64">Possible (50–64)</option>
                <option value="<50">Low Fit (&lt; 50)</option>
                <option value="unscored">Unscored</option>
              </select>
            </div>

            {/* Sort by */}
            <div>
              <label className="block text-[11px] font-bold text-slate-500 dark:text-slate-400 mb-1">
                Sort By
              </label>
              <select
                id="filter-sort-select"
                value={sortBy}
                onChange={(e) => setSortBy(e.target.value as any)}
                className="w-full text-xs py-2 px-2.5 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-indigo-500 min-h-[40px]"
              >
                <option value="score-desc">Highest Fit Score</option>
                <option value="score-asc">Lowest Fit Score</option>
                <option value="newest">Recently Added</option>
                <option value="name-asc">Business Name (A-Z)</option>
              </select>
            </div>

            {/* Reset button if filters active */}
            {hasActiveFilters && (
              <div className="col-span-full flex justify-end">
                <button
                  onClick={resetFilters}
                  className="text-xs text-indigo-600 dark:text-indigo-400 font-semibold hover:underline flex items-center gap-1 py-1"
                >
                  <X className="w-3.5 h-3.5" />
                  <span>Reset all filters</span>
                </button>
              </div>
            )}
          </div>
        )}
      </div>

      {/* Selection Control & Results Header */}
      <div className="flex items-center justify-between text-xs text-slate-500 dark:text-slate-400 px-1">
        <div className="flex items-center gap-2">
          <button
            onClick={handleSelectAll}
            className="font-semibold text-indigo-600 dark:text-indigo-400 hover:underline"
          >
            {selectedIds.size === filteredProspects.length && filteredProspects.length > 0
              ? "Deselect All"
              : `Select All (${filteredProspects.length})`}
          </button>
          <span>•</span>
          <span>
            Showing <strong>{filteredProspects.length}</strong> of {prospects.length} prospects
          </span>
        </div>

        {selectedIds.size > 0 && (
          <button
            onClick={handleTriggerBulkAnalysis}
            className="text-xs font-bold text-indigo-600 dark:text-indigo-400 hover:underline flex items-center gap-1"
          >
            <Sparkles className="w-3.5 h-3.5" />
            <span>Analyze {selectedIds.size} Selected</span>
          </button>
        )}
      </div>

      {/* Prospects Grid */}
      {filteredProspects.length > 0 ? (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3.5 sm:gap-4">
          {filteredProspects.map((prospect) => (
            <ProspectCard
              key={prospect.id}
              prospect={prospect}
              onSelect={onSelectProspect}
              onStatusChange={onStatusChange}
              selectable={true}
              selected={selectedIds.has(prospect.id)}
              onToggleSelect={toggleSelect}
            />
          ))}
        </div>
      ) : (
        <div className="text-center py-16 px-4 bg-white dark:bg-slate-900 rounded-3xl border border-slate-200 dark:border-slate-800">
          <div className="w-14 h-14 rounded-2xl bg-slate-100 dark:bg-slate-800 text-slate-400 flex items-center justify-center mx-auto mb-3">
            <Users className="w-7 h-7" />
          </div>
          <h3 className="text-base font-bold text-slate-900 dark:text-white mb-1">
            No prospects match your criteria
          </h3>
          <p className="text-xs text-slate-500 dark:text-slate-400 max-w-sm mx-auto mb-4">
            Try adjusting your search keywords, clearing filters, or using Find Prospects to discover candidates.
          </p>
          <div className="flex justify-center gap-2">
            {hasActiveFilters && (
              <button
                onClick={resetFilters}
                className="px-4 py-2 rounded-xl bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-200 text-xs font-semibold hover:bg-slate-200 transition-colors"
              >
                Clear Filters
              </button>
            )}
            <button
              onClick={onOpenFindProspects}
              className="flex items-center gap-1.5 px-4 py-2 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white text-xs font-bold shadow-sm"
            >
              <Search className="w-3.5 h-3.5" />
              <span>Find Prospects</span>
            </button>
          </div>
        </div>
      )}
    </div>
  );
};
