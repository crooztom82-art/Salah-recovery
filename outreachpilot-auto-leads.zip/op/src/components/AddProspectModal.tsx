import React, { useState } from "react";
import { Prospect, ProspectStatus } from "../types";
import { NICHE_OPTIONS, COUNTRY_OPTIONS } from "../data/sampleProspects";
import { X, Plus, Sparkles, Building2, User, Globe, Mail, MapPin, Tag, FileText } from "lucide-react";

interface AddProspectModalProps {
  onClose: () => void;
  onAddProspect: (prospect: Prospect, runAnalysisImmediate?: boolean) => void;
}

export const AddProspectModal: React.FC<AddProspectModalProps> = ({
  onClose,
  onAddProspect
}) => {
  const [businessName, setBusinessName] = useState("");
  const [websiteUrl, setWebsiteUrl] = useState("");
  const [contactName, setContactName] = useState("");
  const [publicEmail, setPublicEmail] = useState("");
  const [niche, setNiche] = useState(NICHE_OPTIONS[0]);
  const [country, setCountry] = useState(COUNTRY_OPTIONS[0]);
  const [notes, setNotes] = useState("");
  const [publicBusinessInfo, setPublicBusinessInfo] = useState("");
  const [analyzeImmediate, setAnalyzeImmediate] = useState(true);
  const [errors, setErrors] = useState<{ [key: string]: string }>({});

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const newErrors: { [key: string]: string } = {};

    if (!businessName.trim()) {
      newErrors.businessName = "Business name is required.";
    }
    if (!contactName.trim()) {
      newErrors.contactName = "Contact name is required.";
    }

    if (Object.keys(newErrors).length > 0) {
      setErrors(newErrors);
      return;
    }

    const newProspect: Prospect = {
      id: `prospect-${Date.now()}`,
      businessName: businessName.trim(),
      websiteUrl: websiteUrl.trim(),
      contactName: contactName.trim(),
      publicBusinessEmail: publicEmail.trim() ? publicEmail.trim() : undefined,
      niche,
      country,
      notes: notes.trim(),
      publicBusinessInfo: publicBusinessInfo.trim() ? publicBusinessInfo.trim() : undefined,
      status: "Not Contacted",
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
      history: [
        {
          date: new Date().toISOString(),
          action: "Prospect added to pipeline"
        }
      ]
    };

    onAddProspect(newProspect, analyzeImmediate);
  };

  return (
    <div
      id="add-prospect-modal-backdrop"
      className="fixed inset-0 z-50 bg-slate-950/60 backdrop-blur-xs flex items-center justify-center p-2 sm:p-4 overflow-y-auto"
    >
      <div
        id="add-prospect-modal-panel"
        className="bg-white dark:bg-slate-900 w-full max-w-xl rounded-3xl border border-slate-200 dark:border-slate-800 shadow-2xl overflow-hidden flex flex-col max-h-[92vh] my-auto"
      >
        {/* Modal Header */}
        <div className="p-4 sm:p-5 border-b border-slate-200 dark:border-slate-800 flex items-center justify-between bg-slate-50/50 dark:bg-slate-800/30">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-xl bg-indigo-100 dark:bg-indigo-950/60 text-indigo-600 dark:text-indigo-400 flex items-center justify-center font-bold">
              <Plus className="w-5 h-5" />
            </div>
            <div>
              <h3 className="font-bold text-base text-slate-900 dark:text-white">
                Add New Prospect
              </h3>
              <p className="text-xs text-slate-500 dark:text-slate-400">
                Enter publicly available business details for ethical outreach
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-2 rounded-xl text-slate-400 hover:text-slate-700 dark:hover:text-slate-200 min-h-[44px] min-w-[44px] flex items-center justify-center"
            aria-label="Close"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Modal Form Body */}
        <form onSubmit={handleSubmit} className="p-4 sm:p-6 overflow-y-auto space-y-4 flex-1">
          {/* Business Name */}
          <div>
            <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1 flex items-center gap-1.5">
              <Building2 className="w-3.5 h-3.5 text-slate-400" />
              <span>Business Name *</span>
            </label>
            <input
              type="text"
              id="input-business-name"
              value={businessName}
              onChange={(e) => {
                setBusinessName(e.target.value);
                if (errors.businessName) setErrors({ ...errors, businessName: "" });
              }}
              placeholder="e.g. Zenith Academy, Studio Nova"
              className="w-full px-3.5 py-2.5 text-sm rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-900 dark:text-white focus:ring-2 focus:ring-indigo-500 focus:outline-none min-h-[44px]"
            />
            {errors.businessName && (
              <p className="text-xs text-rose-500 mt-1 font-medium">{errors.businessName}</p>
            )}
          </div>

          {/* Website URL */}
          <div>
            <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1 flex items-center gap-1.5">
              <Globe className="w-3.5 h-3.5 text-slate-400" />
              <span>Website URL</span>
            </label>
            <input
              type="text"
              id="input-website-url"
              value={websiteUrl}
              onChange={(e) => setWebsiteUrl(e.target.value)}
              placeholder="https://example.com"
              className="w-full px-3.5 py-2.5 text-sm rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-900 dark:text-white focus:ring-2 focus:ring-indigo-500 focus:outline-none min-h-[44px]"
            />
          </div>

          {/* Contact Name */}
          <div>
            <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1 flex items-center gap-1.5">
              <User className="w-3.5 h-3.5 text-slate-400" />
              <span>Contact Name *</span>
            </label>
            <input
              type="text"
              id="input-contact-name"
              value={contactName}
              onChange={(e) => {
                setContactName(e.target.value);
                if (errors.contactName) setErrors({ ...errors, contactName: "" });
              }}
              placeholder="e.g. Sarah Jenkins"
              className="w-full px-3.5 py-2.5 text-sm rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-900 dark:text-white focus:ring-2 focus:ring-indigo-500 focus:outline-none min-h-[44px]"
            />
            {errors.contactName && (
              <p className="text-xs text-rose-500 mt-1 font-medium">{errors.contactName}</p>
            )}
          </div>

          {/* Public Business Email */}
          <div>
            <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1 flex items-center gap-1.5">
              <Mail className="w-3.5 h-3.5 text-slate-400" />
              <span>Public Business Email (Optional)</span>
            </label>
            <input
              type="email"
              id="input-public-email"
              value={publicEmail}
              onChange={(e) => setPublicEmail(e.target.value)}
              placeholder="info@business.com"
              className="w-full px-3.5 py-2.5 text-sm rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-900 dark:text-white focus:ring-2 focus:ring-indigo-500 focus:outline-none min-h-[44px]"
            />
          </div>

          {/* Niche & Country */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div>
              <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1 flex items-center gap-1.5">
                <Tag className="w-3.5 h-3.5 text-slate-400" />
                <span>Business Type / Niche</span>
              </label>
              <select
                id="input-niche-select"
                value={niche}
                onChange={(e) => setNiche(e.target.value)}
                className="w-full px-3 py-2.5 text-sm rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-900 dark:text-white focus:ring-2 focus:ring-indigo-500 focus:outline-none min-h-[44px]"
              >
                {NICHE_OPTIONS.map((n) => (
                  <option key={n} value={n}>
                    {n}
                  </option>
                ))}
              </select>
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1 flex items-center gap-1.5">
                <MapPin className="w-3.5 h-3.5 text-slate-400" />
                <span>Country</span>
              </label>
              <select
                id="input-country-select"
                value={country}
                onChange={(e) => setCountry(e.target.value)}
                className="w-full px-3 py-2.5 text-sm rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-900 dark:text-white focus:ring-2 focus:ring-indigo-500 focus:outline-none min-h-[44px]"
              >
                {COUNTRY_OPTIONS.map((c) => (
                  <option key={c} value={c}>
                    {c}
                  </option>
                ))}
              </select>
            </div>
          </div>

          {/* Notes */}
          <div>
            <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1 flex items-center gap-1.5">
              <FileText className="w-3.5 h-3.5 text-slate-400" />
              <span>Notes & Funnel Clues</span>
            </label>
            <textarea
              rows={2}
              id="input-notes"
              value={notes}
              onChange={(e) => setNotes(e.target.value)}
              placeholder="e.g. Currently uses Kajabi $199/mo with only 400 contacts; complained about high monthly costs on podcast."
              className="w-full px-3.5 py-2 text-sm rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-900 dark:text-white focus:ring-2 focus:ring-indigo-500 focus:outline-none"
            />
          </div>

          {/* Public Information for AI Analysis */}
          <div>
            <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1">
              Public Business Information (Paste raw text for AI Analysis)
            </label>
            <textarea
              rows={2}
              id="input-public-info"
              value={publicBusinessInfo}
              onChange={(e) => setPublicBusinessInfo(e.target.value)}
              placeholder="Paste public info, product page prices, or tech stack mentions..."
              className="w-full px-3.5 py-2 text-xs font-mono rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-900 dark:text-white focus:ring-2 focus:ring-indigo-500 focus:outline-none"
            />
          </div>

          {/* Immediate Analysis Checkbox */}
          <div className="flex items-center gap-2 pt-1">
            <input
              type="checkbox"
              id="analyze-immediate-check"
              checked={analyzeImmediate}
              onChange={(e) => setAnalyzeImmediate(e.target.checked)}
              className="w-4 h-4 text-indigo-600 rounded border-slate-300 focus:ring-indigo-500"
            />
            <label
              htmlFor="analyze-immediate-check"
              className="text-xs font-medium text-slate-700 dark:text-slate-300 cursor-pointer flex items-center gap-1"
            >
              <Sparkles className="w-3.5 h-3.5 text-emerald-500" />
              <span>Analyze prospect with AI immediately after adding</span>
            </label>
          </div>

          {/* Submit buttons */}
          <div className="pt-3 border-t border-slate-100 dark:border-slate-800 flex items-center justify-end gap-2">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2.5 rounded-xl text-xs font-semibold text-slate-600 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors min-h-[44px]"
            >
              Cancel
            </button>
            <button
              type="submit"
              id="submit-add-prospect-btn"
              className="px-5 py-2.5 rounded-xl bg-indigo-600 hover:bg-indigo-700 active:bg-indigo-800 text-white text-xs font-bold shadow-sm transition-all min-h-[44px]"
            >
              Add Prospect
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
