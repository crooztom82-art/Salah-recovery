import {
  Prospect,
  ProspectAnalysis,
  OutreachMessages,
  FollowUpItem,
  FitClassification,
  FitScoreBreakdown,
  AnalysisEvidenceItem
} from "../types";

export function calculateFitClassification(score: number): FitClassification {
  if (score >= 80) return "Strong Potential";
  if (score >= 65) return "Good Potential";
  if (score >= 50) return "Possible";
  if (score >= 25) return "Low Potential";
  return "Insufficient Information";
}

/**
 * Robust Client-Side AI Analysis Engine for Prospecting and Funnel Diagnosis.
 * Adheres strictly to anti-hallucination guardrails:
 * - Uses ONLY observable facts supplied by the user or publicly verified.
 * - Produces a transparent 0–100 Fit Score with a 6-part category breakdown.
 * - Documents observable opportunity signals and potential funnel/marketing gaps.
 * - Explicitly details both why this prospect may be a good fit AND why they may NOT be a good fit.
 * - When public information is missing or minimal, clearly labels: "Insufficient public information."
 */
export function generateRealAnalysis(prospect: {
  businessName: string;
  websiteUrl?: string;
  contactName?: string;
  niche?: string;
  country?: string;
  city?: string;
  notes?: string;
  publicBusinessInfo?: string;
  businessModel?: string;
}): ProspectAnalysis {
  const {
    businessName,
    websiteUrl,
    contactName,
    niche = "Digital Business",
    country = "Global",
    city = "",
    notes = "",
    publicBusinessInfo = "",
    businessModel = ""
  } = prospect;

  const combinedText = `${notes} ${publicBusinessInfo} ${niche} ${businessModel}`.toLowerCase();
  const analysisTimestamp = new Date().toISOString();

  // 1. Extract literal observed facts
  const observedFacts: string[] = [];
  if (businessName) {
    observedFacts.push(`Business name: "${businessName}"`);
  }
  if (niche) {
    observedFacts.push(`Operating niche: ${niche}`);
  }
  if (websiteUrl && websiteUrl.trim()) {
    observedFacts.push(`Online presence at ${websiteUrl.trim()}`);
  }
  if (contactName && contactName.trim()) {
    observedFacts.push(`Target contact: ${contactName.trim()}`);
  }
  if (country && country !== "Global") {
    const loc = city ? `${city}, ${country}` : country;
    observedFacts.push(`Headquartered / operating in ${loc}`);
  }
  if (businessModel) {
    observedFacts.push(`Stated business model: ${businessModel}`);
  }
  if (notes && notes.trim()) {
    observedFacts.push(`User observed notes: "${notes.trim().slice(0, 120)}${notes.trim().length > 120 ? '...' : ''}"`);
  }
  if (publicBusinessInfo && publicBusinessInfo.trim()) {
    observedFacts.push(`Public stack details: "${publicBusinessInfo.trim().slice(0, 120)}${publicBusinessInfo.trim().length > 120 ? '...' : ''}"`);
  }
  if (observedFacts.length < 2) {
    observedFacts.push("Minimal specific stack notes provided in profile");
  }

  // 2. Derive 3–5 specific business observations based ONLY on provided facts
  const observations: string[] = [];
  observations.push(
    `Positioned as a ${niche} business with digital touchpoints requiring lead acquisition and customer conversion.`
  );

  if (notes.trim() || publicBusinessInfo.trim()) {
    observations.push(
      `Profile notes highlight specific operational challenges: "${(notes || publicBusinessInfo).slice(0, 95)}..."`
    );
  } else {
    observations.push(
      `Specific software stack was not detailed in profile notes; evaluation is based on standard ${niche} workflows.`
    );
  }

  if (websiteUrl && websiteUrl.trim()) {
    observations.push(
      `Maintains an active digital presence (${websiteUrl.trim()}) suitable for hosting lead funnels or landing pages.`
    );
  } else {
    observations.push(
      `Currently lacks a verified public website URL, suggesting social-first sales or an early setup stage.`
    );
  }

  observations.push(
    `Requires automated follow-up sequences and seamless checkout mechanisms to nurture leads without continuous manual intervention.`
  );

  // 3. Evaluate specific opportunity signals & technology cues
  const hasWordPress = combinedText.includes("wordpress") || combinedText.includes("woocommerce") || combinedText.includes("wp ") || combinedText.includes("plugin");
  const hasHighCostTools = combinedText.includes("kajabi") || combinedText.includes("clickfunnels") || combinedText.includes("teachable") || combinedText.includes("kartra") || combinedText.includes("expensive") || combinedText.includes("cost") || combinedText.includes("$");
  const hasEmailGaps = combinedText.includes("mailchimp") || combinedText.includes("convertkit") || combinedText.includes("activecampaign") || combinedText.includes("newsletter") || combinedText.includes("email");
  const hasCoachingOrCourses = combinedText.includes("coach") || combinedText.includes("course") || combinedText.includes("consult") || combinedText.includes("agency") || combinedText.includes("program") || combinedText.includes("mastermind") || combinedText.includes("fitness") || combinedText.includes("creator");
  const hasManualSales = combinedText.includes("manual") || combinedText.includes("dm") || combinedText.includes("invoicing") || combinedText.includes("calendly") || combinedText.includes("call");

  // Observable opportunity signals
  const opportunitySignals: string[] = [];
  if (hasCoachingOrCourses) {
    opportunitySignals.push("Coaching, digital product, or service business model");
  }
  opportunitySignals.push("Audience & lead-generation opportunity present");
  if (hasWordPress) {
    opportunitySignals.push("Multi-plugin WordPress overhead or update maintenance risk");
  }
  if (hasHighCostTools) {
    opportunitySignals.push("Paying premium SaaS rates ($150-$300+/mo) for separate funnel tools");
  }
  if (hasEmailGaps) {
    opportunitySignals.push("Disjointed email broadcasting or lack of triggered nurture sequences");
  }
  if (hasManualSales) {
    opportunitySignals.push("Manual back-and-forth booking and payment collection");
  }
  opportunitySignals.push("No visible unified all-in-one funnel and email automation platform");

  // Potential platform opportunities
  const potentialOpportunities: string[] = [
    "Sales Funnel (Opt-in pages, upsells, thank you pages)",
    "Email Marketing & Automated Tag-based Sequences",
    "Lead Capture Magnets & Automated Delivery"
  ];
  if (hasCoachingOrCourses) {
    potentialOpportunities.push("Course & Membership Area Hosting (Unlimited video storage)");
  }
  potentialOpportunities.push("Full Workflow Automation (replacing Zapier zaps)");

  // 4. Calculate Transparent 6-Category Fit Score Breakdown (0-100)
  // Categories:
  // - businessModelFit: max 20
  // - digitalProductCoaching: max 20
  // - funnelOpportunity: max 20
  // - emailLeadCapture: max 15
  // - automationOpportunity: max 15
  // - publicEvidenceQuality: max 10

  let businessModelFit = 14;
  let digitalProductCoaching = 12;
  let funnelOpportunity = 14;
  let emailLeadCapture = 11;
  let automationOpportunity = 10;
  let publicEvidenceQuality = 6;

  if (hasCoachingOrCourses) {
    businessModelFit = Math.min(20, businessModelFit + 4);
    digitalProductCoaching = Math.min(20, digitalProductCoaching + 6);
  }
  if (hasWordPress) {
    funnelOpportunity = Math.min(20, funnelOpportunity + 5);
    automationOpportunity = Math.min(15, automationOpportunity + 4);
    publicEvidenceQuality = Math.min(10, publicEvidenceQuality + 3);
  }
  if (hasHighCostTools) {
    funnelOpportunity = Math.min(20, funnelOpportunity + 5);
    businessModelFit = Math.min(20, businessModelFit + 4);
    publicEvidenceQuality = Math.min(10, publicEvidenceQuality + 3);
  }
  if (hasEmailGaps || hasManualSales) {
    emailLeadCapture = Math.min(15, emailLeadCapture + 4);
    automationOpportunity = Math.min(15, automationOpportunity + 4);
    publicEvidenceQuality = Math.min(10, publicEvidenceQuality + 2);
  }

  // If no website or notes, reflect insufficient evidence
  if (!websiteUrl && !notes.trim() && !publicBusinessInfo.trim()) {
    publicEvidenceQuality = 2;
    businessModelFit = 6;
    digitalProductCoaching = 6;
    funnelOpportunity = 5;
    emailLeadCapture = 4;
    automationOpportunity = 4;
  }

  const calculatedTotal = Math.min(
    100,
    Math.max(
      15,
      businessModelFit +
        digitalProductCoaching +
        funnelOpportunity +
        emailLeadCapture +
        automationOpportunity +
        publicEvidenceQuality
    )
  );

  const scoreBreakdown: FitScoreBreakdown = {
    businessModelFit,
    digitalProductCoaching,
    funnelOpportunity,
    emailLeadCapture,
    automationOpportunity,
    publicEvidenceQuality,
    total: calculatedTotal
  };

  const fitScore = calculatedTotal;
  const fitClassification = calculateFitClassification(fitScore);

  let confidence: "High" | "Medium" | "Low" = "Medium";
  let confidenceReasoning = "Moderate input data provided. Fit score reflects verified public details and niche norms.";

  if (hasWordPress || hasHighCostTools || (notes.trim().length > 60 && publicBusinessInfo.trim().length > 40)) {
    confidence = "High";
    confidenceReasoning = "High confidence: Profile notes contain explicit technical stack or workflow pain points.";
  } else if (!notes.trim() && !publicBusinessInfo.trim()) {
    confidence = "Low";
    confidenceReasoning = "Low confidence: Minimal business notes provided. Score is an estimation based on general niche patterns.";
  }

  // 5. Funnel gaps, platform features, why good & why NOT good
  const funnelGaps: string[] = [];
  const systemeFeatures: string[] = [];
  let salesAngle = "Consolidating digital marketing tools into one platform with a unified workflow";
  const whyGood: string[] = [];
  const whyNotGood: string[] = [];

  if (hasWordPress) {
    funnelGaps.push("Fragile multi-plugin stack: relying on separate plugins for forms, checkout, and email captures risks security breaks and update conflicts.");
    funnelGaps.push("Technical maintenance overhead: constant PHP and plugin updates distract from client acquisition and sales.");
    funnelGaps.push("Broken customer tracking between disparate checkout plugins and third-party email responders.");

    systemeFeatures.push("Fully hosted sales funnels replace brittle WordPress checkout & landing page builders with zero maintenance.");
    systemeFeatures.push("Native tag-based email automations trigger instantly upon purchase without needing Zapier.");
    systemeFeatures.push("Integrated membership and digital product hosting eliminates expensive LMS plugin licenses.");

    salesAngle = "Eliminating WordPress plugin maintenance headaches, update breakage, and recurring plugin license fees";
    whyGood.push("Directly solves the technical maintenance and plugin fatigue noted in their profile.");
    whyGood.push("A low-risk evaluation can help compare the workflow before any migration decision.");
    whyGood.push("Single login for email, courses, and checkout keeps admin overhead minimal.");

    whyNotGood.push("If they have extensive custom PHP themes or complex physical warehouse inventory, migration requires workflow adaptation.");
    whyNotGood.push("If they have an in-house WordPress webmaster or agency managing everything smoothly, they may have little appetite for change.");
  } else if (hasHighCostTools) {
    funnelGaps.push("Excessive recurring software overhead ($150 to $300+/month) creating cash-flow drag on the business.");
    funnelGaps.push("Tier-based pricing penalties where software bills increase simply as list size grows.");
    funnelGaps.push("Overpaying for bloated features that their actual sales process does not require.");

    systemeFeatures.push("Provides full course and membership hosting with unlimited video storage starting on a free or paid plan.");
    systemeFeatures.push("All-in-one sales funnels and automated email broadcasting under one plan, with the actual savings depending on their current stack and plan choices.");
    systemeFeatures.push("Zero platform transaction fees charged (only standard Stripe/PayPal processing rates).");

    salesAngle = "Slashing monthly software subscription costs by depending on the current stack and plan choices while retaining full course and email capabilities";
    whyGood.push("Immediate cash flow savings: replacing high-cost tools with a current plan options up to 2,000 contacts or affordable all-in-one plan.");
    whyGood.push("Feature-for-feature equivalence for digital courses, email marketing, and lead capture.");
    whyGood.push("Unlimited student enrollment and video hosting on all plans.");

    whyNotGood.push("Rebuilding existing complex course modules or multi-step funnels requires an initial migration time investment.");
    whyNotGood.push("They may be entrenched in their current community ecosystem and hesitant to migrate existing active students.");
  } else if (hasEmailGaps || hasManualSales) {
    funnelGaps.push("Disconnected lead collection: manual back-and-forth messaging or un-automated payment links leading to dropped prospects.");
    funnelGaps.push("Paying separate fees for email marketing while lacking automated conversion funnels.");
    funnelGaps.push("Missed follow-up revenue due to lack of triggered nurture sequences after initial contact.");

    systemeFeatures.push("Pre-built funnel templates that capture client leads and automatically deliver booking or payment links.");
    systemeFeatures.push("Automated email follow-up sequences that nurture prospects 24/7 without manual emailing.");
    systemeFeatures.push("One-click upsells and automated invoice generation upon checkout.");

    salesAngle = "Automating manual client follow-ups and capturing more sales with a frictionless 1-page checkout";
    whyGood.push("Saves significant hours each week by automating manual onboarding and invoice follow-ups.");
    whyGood.push("Can be launched in an afternoon using pre-built templates without writing code.");
    whyGood.push("A trial or low-risk evaluation may help them compare the workflow, depending on current plan availability.");

    whyNotGood.push("The business owner must set aside 1–2 hours to configure their initial lead magnet and email sequences.");
    whyNotGood.push("If they intentionally prefer bespoke high-touch manual messaging for every client, funnel automation may feel less personal to them.");
  } else {
    funnelGaps.push("Likely paying for multiple separate subscriptions for email capture, landing pages, and checkout.");
    funnelGaps.push("Potential leakage between marketing interest and customer payment due to disconnected tools.");
    funnelGaps.push("Manual customer follow-up workload without unified automation triggers.");

    systemeFeatures.push("All-in-one lead capture, landing pages, and email automation in a single centralized dashboard.");
    systemeFeatures.push("A unified platform can combine relevant funnel, email, and digital-product workflows.");
    systemeFeatures.push("Integrated affiliate management system to let their partners promote their products.");

    salesAngle = "Simplifying your digital marketing tech stack into one cost-effective system with a low-risk evaluation";
    whyGood.push("Zero financial risk: generous current plan options with no trial expiration allows full testing before committing.");
    whyGood.push("Consolidates disparate tools into one intuitive interface.");
    whyGood.push("Built specifically for creators, coaches, and digital entrepreneurs.");

    whyNotGood.push("If the business is strictly brick-and-mortar with no digital sales or lead generation goals, funnels may not be their primary priority.");
    whyNotGood.push("If they have a custom enterprise tech stack, an all-in-one consumer tool may not fit bespoke API requirements.");
  }

  // 6. Evidence and sources (Strictly anti-hallucination)
  const evidenceSources: AnalysisEvidenceItem[] = [];
  if (websiteUrl && websiteUrl.trim()) {
    evidenceSources.push({
      sourceUrl: websiteUrl.trim(),
      pageSection: "Homepage / Public Site",
      observation: `Verified digital web presence for ${businessName}.`,
      timestamp: analysisTimestamp
    });
  }
  if (publicBusinessInfo && publicBusinessInfo.trim()) {
    evidenceSources.push({
      sourceUrl: websiteUrl || "Public Web Profile",
      pageSection: "Observed Stack / Footer / Metadata",
      observation: publicBusinessInfo.slice(0, 140),
      timestamp: analysisTimestamp
    });
  }
  if (notes && notes.trim()) {
    evidenceSources.push({
      sourceUrl: "User Sourced Notes",
      pageSection: "Field Notes & Observations",
      observation: notes.slice(0, 140),
      timestamp: analysisTimestamp
    });
  }
  if (evidenceSources.length === 0) {
    evidenceSources.push({
      sourceUrl: "Public Domain Search",
      pageSection: "General Directory",
      observation: "Insufficient public information available to verify specific software plugins.",
      timestamp: analysisTimestamp
    });
  }

  // Reasoned assumptions strictly separated from facts
  const assumptions: string[] = [
    `Assumes ${businessName || "the business"} sells digital products, services, coaching, or generates leads online.`,
    `Assumes reducing recurring monthly software expenses and operational complexity is an attractive priority.`,
    `Specific current software tools and customer list size must be verified during personal dialogue.`
  ];

  return {
    opportunityScore: fitScore,
    fitScore,
    fitClassification,
    scoreBreakdown,
    opportunitySignals,
    potentialOpportunities,
    evidenceSources,
    confidenceLevel: confidence,
    confidenceReasoning,
    businessObservations: observations.slice(0, 4),
    observedFacts: observedFacts.slice(0, 5),
    funnelGaps,
    potentialProblems: funnelGaps,
    systemeSolvingFeatures: systemeFeatures,
    systemeFitReasoning: `Strong practical fit (${fitScore}/100) because an all-in-one platform unifies sales funnels, email marketing, digital courses, and checkout with a plan that matches their needs.`,
    fitReasons: systemeFeatures,
    recommendedSalesAngle: salesAngle,
    recommendedOutreachAngle: salesAngle,
    whyGoodOrNot: {
      summary: `An all-in-one platform offers a ${fitScore >= 80 ? "high" : "moderate"} probability of solving operational and cost pain points for ${businessName || "this prospect"}.`,
      whyGood,
      whyNotGoodOrLimitations: whyNotGood
    },
    whyGoodOrNotGood: {
      summary: `An all-in-one platform offers a ${fitScore >= 80 ? "high" : "moderate"} probability of solving operational and cost pain points for ${businessName || "this prospect"}.`,
      whyGood: whyGood.join(". "),
      whyNot: whyNotGood.join(". ")
    },
    assumptions,
    lastAnalyzedAt: analysisTimestamp
  };
}

export const analyzeProspectLocally = generateRealAnalysis;

/**
 * Robust Client-Side Outreach Generator
 * Generates:
 * - Message A: Short DM (for Instagram, Twitter/X, or short contact form)
 * - Message B: Email (Subject + Body)
 * - Message C: Longer personalized message (deep-dive, consultative)
 * Optionally appends ethical affiliate disclosure.
 */
export function generateRealOutreach(
  prospect: Prospect,
  affiliateLink?: string,
  options?: {
    includeDisclosure?: boolean;
    disclosureText?: string;
  }
): OutreachMessages {
  const firstName = prospect.contactName ? prospect.contactName.trim().split(" ")[0] : "there";
  const biz = prospect.businessName || "your business";
  const niche = prospect.niche || "online business";
  const linkStr = affiliateLink && affiliateLink.trim() ? affiliateLink.trim() : "[Partner/Platform Free Plan Link]";

  const includeDisclosure = options?.includeDisclosure ?? false;
  const disclosureStr = includeDisclosure
    ? `\n\n(Full transparency: If you decide to upgrade to a paid plan down the line, I may earn an affiliate commission at zero extra cost to you. I only recommend tools I genuinely believe provide massive value.)`
    : "";

  const notesLower = (prospect.notes || "").toLowerCase();
  const hasWordPress = notesLower.includes("wordpress") || notesLower.includes("plugin");
  const hasHighCost = notesLower.includes("kajabi") || notesLower.includes("clickfunnels") || notesLower.includes("expensive");

  let shortDmBody = "";
  let emailSubject = "";
  let emailBody = "";
  let longerMessageBody = "";

  if (hasWordPress) {
    shortDmBody = `Hi ${firstName},\n\nReaching out with a quick operational tip for ${biz}. If you're ever looking to eliminate WordPress plugin maintenance for your sales funnels and email list, take a look at this all-in-one platform (${linkStr}). It has a current plan options for up to 2,000 contacts that replaces multiple subscriptions. Hope it's helpful!${disclosureStr}`;

    emailSubject = `Quick thought on WordPress plugin maintenance for ${biz}`;
    emailBody = `Hi ${firstName},

I was looking at ${biz} and noticed your work in the ${niche} space.

I'm reaching out because many business owners running on WordPress end up juggling multiple separate plugins for checkout, lead capture forms, and email delivery—which frequently leads to update conflicts and surprise breakage.

Not sure if you've explored all-in-one solutions, but a modern unified platform replaces fragile WordPress sales plugins with hosted sales funnels, automated email sequences, and course hosting in a single dashboard. 

The best part is there is a 100% current plan options for up to 2,000 contacts with zero transaction fees, so you can test it without touching your current site:
${linkStr}

If your current setup is working smoothly, no worries at all! Just wanted to share in case you're looking to simplify maintenance.${disclosureStr}

Best regards,
[Your Name]`;

    longerMessageBody = `Hi ${firstName},

Hope you're having a great week. I spent some time reviewing ${biz} and was really impressed with your positioning in the ${niche} market.

From what I could see of your digital footprint, you're likely managing multiple disparate tools or WordPress plugins to handle your sales funnels, email captures, and customer transactions. In working with similar creators, the most common frustration is the endless cycle of software updates, plugin compatibility breaks, and disconnected customer databases.

I wanted to share an all-in-one sales funnel platform as an ethical alternative. It was built specifically to solve this exact headache by combining:
1. Drag-and-drop sales funnels and landing pages that don't rely on WordPress hosting.
2. Built-in email broadcast & automated tag-based drip sequences.
3. Native digital product and video course hosting with automated student logins.
4. Seamless Stripe/PayPal checkouts with 1-click upsells and zero platform fees.

Unlike most software platforms that push aggressive 14-day trials with credit card traps, this platform has a generous permanent current plan options (up to 2,000 contacts and 3 full sales funnels) so you can test it completely risk-free:
${linkStr}

If you're already completely satisfied with your current technical stack, please feel free to disregard this note. But if streamlining your operations and cutting maintenance hours sounds appealing, I'd be happy to share how other ${niche} founders handled their transition.${disclosureStr}

Warm regards,
[Your Name]`;
  } else if (hasHighCost) {
    shortDmBody = `Hi ${firstName},\n\nQuick thought for ${biz}: if you're ever looking to reduce monthly software costs for your sales funnels and email lists, check out this all-in-one platform (${linkStr}). It offers an all-in-one setup with a current plan options up to 2,000 contacts. Hope it's valuable!${disclosureStr}`;

    emailSubject = `Cutting software overhead for ${biz} (quick comparison)`;
    emailBody = `Hi ${firstName},

Hope your week is going well. I was reviewing ${biz} and wanted to reach out regarding your digital setup in the ${niche} space.

A lot of entrepreneurs in your industry are currently spending $150 to $300+ every month across separate subscriptions for funnels, email marketing, and course hosting.

If you haven't seen an all-in-one funnel platform yet, it brings all of those capabilities together under one roof. It includes a completely current plan options for up to 2,000 contacts, and their paid tiers are a fraction of typical industry pricing:
${linkStr}

If you're already locked into your current stack, absolutely no pressure! But if you ever evaluate your software budget this quarter, it's worth having on your radar.${disclosureStr}

Best regards,
[Your Name]`;

    longerMessageBody = `Hi ${firstName},

Hope your month is off to a productive start! I was analyzing ${biz} and wanted to share a constructive observation about software efficiency in the ${niche} industry.

Many high-growth digital businesses eventually hit a point of "SaaS fatigue"—paying $150, $200, or even $300+ per month to host courses, send email newsletters, and manage sales funnels. Often, these platforms penalize your growth by raising your tier price simply because your contact list grows.

An all-in-one sales funnel platform was created specifically to eliminate this cash-flow drag. It offers:
- Full course & digital product hosting with unlimited video storage
- Sales funnel builder with 1-click upsells and order bumps
- Email marketing automation with tags and behavioral triggers
- Transparent pricing with a free or paid plan up to 2,000 contacts and paid plans starting at just $27/month

Here is the direct link to explore their current plan options:
${linkStr}

There is no obligation whatsoever—if your current tools are already paying for themselves smoothly, that's what matters most. But if saving $1,500+ a year while simplifying your tech sounds helpful, it's well worth exploring.${disclosureStr}

Wishing you continued success with ${biz}!

Best regards,
[Your Name]`;
  } else {
    shortDmBody = `Hi ${firstName},\n\nReaching out with a quick resource for ${biz}. If you're looking for a simpler way to run sales funnels and email automations without high monthly bills, check out this all-in-one platform (${linkStr}). It has a current plan options for up to 2,000 contacts. Hope this helps!${disclosureStr}`;

    emailSubject = `Quick thought on ${biz}'s lead capture & sales setup`;
    emailBody = `Hi ${firstName},

I was looking over ${biz} and wanted to send a quick note regarding your digital sales setup in the ${niche} space.

Many growing brands find themselves stitching together separate tools for landing pages, email broadcasts, and checkout, which can get disorganized and costly.

An all-in-one platform provides a simple alternative with sales funnels, email marketing automation, and course/digital product hosting in one place. They offer a free or paid plan up to 2,000 contacts with no expiration date:
${linkStr}

If you're completely satisfied with your current workflow, please disregard! But if you ever look to streamline your tech, you might find it useful.${disclosureStr}

Best regards,
[Your Name]`;

    longerMessageBody = `Hi ${firstName},

Hope you're having a great week. I came across ${biz} and was impressed by what you're building in the ${niche} space.

As digital brands expand their offers, managing lead magnets, automated follow-ups, and customer checkouts across disparate tools often becomes messy and expensive. 

An all-in-one sales funnel platform unifies the entire client journey:
1. High-converting opt-in pages and sales funnels
2. Automated email drip campaigns that nurture leads 24/7
3. Membership/course portal and digital checkout in one spot
4. Free plan for up to 2,000 contacts with no credit card required

You can test-drive the free setup here:
${linkStr}

No pressure at all—just wanted to share a genuine recommendation that has saved many founders hundreds of dollars and hours of tech frustration.${disclosureStr}

Best regards,
[Your Name]`;
  }

  const shortDm = { body: shortDmBody };
  const email = { subject: emailSubject, body: emailBody };
  const longerPersonalizedMessage = { subject: emailSubject, body: longerMessageBody };

  return {
    shortDm,
    email,
    longerPersonalizedMessage,
    coldEmail: email,
    linkedIn: {
      body: `Hi ${firstName}, saw the great work you're doing with ${biz} in the ${niche} space. Many creators I talk to are consolidating their funnels, checkout, and email into an all-in-one platform (which has a 100% current plan options up to 2k contacts: ${linkStr}). Thought it might be a helpful resource to keep on your radar. Wishing you continued growth!${disclosureStr}`
    },
    shortDmOrContactForm: shortDm,
    contactForm: shortDm,
    affiliateDisclosureIncluded: includeDisclosure,
    generatedAt: new Date().toISOString()
  };
}

/**
 * Robust Client-Side Follow-up Generator
 * Generates 3 polite, progressive follow-ups
 */
export function generateRealFollowups(
  prospect: Prospect,
  affiliateLink?: string,
  options?: {
    includeDisclosure?: boolean;
  }
): FollowUpItem[] {
  const firstName = prospect.contactName ? prospect.contactName.trim().split(" ")[0] : "there";
  const biz = prospect.businessName || "your business";
  const niche = prospect.niche || "your industry";
  const linkStr = affiliateLink && affiliateLink.trim() ? affiliateLink.trim() : "[Platform Free Plan Link]";

  return [
    {
      step: 1,
      label: "Gentle Value Check",
      timing: "Send 3–4 days after initial message",
      subject: `Re: Quick thought for ${biz}`,
      body: `Hi ${firstName},

Just floating this to the top of your inbox in case it slipped past you. I know how busy running ${biz} can get!

One specific detail people in ${niche} appreciate about modern all-in-one platforms is that you can build full email automations and sales funnels without needing third-party connectors like Zapier. The current plan options has no expiration date:
${linkStr}

No pressure at all—hope you have a productive week!

Best,
[Your Name]`,
      sent: false
    },
    {
      step: 2,
      label: "Tool & Cost Comparison",
      timing: "Send 7–10 days after first follow-up",
      subject: `Cutting software overhead for ${biz}`,
      body: `Hi ${firstName},

Wanted to share a brief perspective—many entrepreneurs in ${niche} find that consolidating separate tools into one platform saves $100–$250/mo right away while eliminating sync headaches between tools.

Here is the current plan options overview if you'd like to benchmark your current setup:
${linkStr}

Always glad to answer any questions if you decide to take a look.

Best regards,
[Your Name]`,
      sent: false
    },
    {
      step: 3,
      label: "Respectful Breakup / Closing Loop",
      timing: "Send 14–21 days later",
      subject: `Closing the loop on ${biz}`,
      body: `Hi ${firstName},

I want to respect your inbox space, so this will be my last note! I assume you're completely satisfied with your current tech setup for ${biz}, which is wonderful.

Should your needs change down the road or you ever want to test an all-in-one platform with the applicable current plan cost, the current plan options is always open at:
${linkStr}

Wishing you and ${biz} all the best!

Warmly,
[Your Name]`,
      sent: false
    }
  ];
}
