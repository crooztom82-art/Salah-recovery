import React, { useState } from "react";
import {
  X,
  Search,
  Sliders,
  ExternalLink,
  Plus,
  Check,
  AlertCircle,
  Sparkles,
  Key,
  Globe,
  MapPin,
  Building2,
  Copy,
  ArrowRight,
  ShieldCheck,
  Loader2
} from "lucide-react";
import {
  AppSettings,
  Prospect,
  DiscoveredProspectCandidate,
  ProspectDiscoveryParams,
  FitClassification
} from "../types";
import { WORLD_COUNTRIES } from "../data/countries";

interface FindProspectsModalProps {
  isOpen: boolean;
  onClose: () => void;
  settings: AppSettings;
  onAddProspects: (newProspects: Prospect[]) => void;
  onNavigateToSettings: () => void;
  onShowToast: (msg: string, type: "success" | "error" | "info") => void;
}

const NICHES = [
  "Fitness & Wellness Coaching",
  "Life Coaching & Personal Growth",
  "Business & Executive Consulting",
  "Digital Marketing & Social Media Agency",
  "Course Creators & Online Educators",
  "Finance & Wealth Advisory",
  "Career & Resume Coaching",
  "Creative & Design Services"
];

const COUNTRIES = WORLD_COUNTRIES;

export const FindProspectsModal: React.FC<FindProspectsModalProps> = ({
  isOpen,
  onClose,
  settings,
  onAddProspects,
  onNavigateToSettings,
  onShowToast
}) => {
  const [country, setCountry] = useState(settings.defaultTargetCountry || "Worldwide / Any Country");
  const [customCountry, setCustomCountry] = useState("");
  const [stateRegion, setStateRegion] = useState("");
  const [city, setCity] = useState("");
  const [niche, setNiche] = useState(settings.defaultNiches?.[0] || NICHES[0]);
  const [customNiche, setCustomNiche] = useState("");
  const [desiredCount, setDesiredCount] = useState(5);
  const [minFitScore, setMinFitScore] = useState(settings.minimumFitScore || 65);
  const [keywords, setKeywords] = useState("");

  const [isLoading, setIsLoading] = useState(false);
  const [candidates, setCandidates] = useState<DiscoveredProspectCandidate[]>([]);
  const [selectedCandidateUrls, setSelectedCandidateUrls] = useState<Set<string>>(new Set());
  const [isConfigured, setIsConfigured] = useState<boolean | null>(null);
  const [hasSearched, setHasSearched] = useState(false);
  const [suggestedQueries, setSuggestedQueries] = useState<string[]>([]);
  const [quickAddUrl, setQuickAddUrl] = useState("");
  const [quickAddName, setQuickAddName] = useState("");

  if (!isOpen) return null;

  const effectiveCountry = country === "Custom" ? customCountry.trim() : country;
  const activeNiche = niche === "Custom" ? customNiche.trim() || "Online Business" : niche;

  const handleSearch = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsLoading(true);
    setCandidates([]);
    setSelectedCandidateUrls(new Set());
    setHasSearched(true);

    try {
      const response = await fetch("/api/discover-prospects", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          country: effectiveCountry,
          stateRegion: stateRegion.trim(),
          city: city.trim(),
          niche: activeNiche,
          desiredCount,
          minFitScore,
          keywords: keywords.trim(),
          searchProviderConfig: settings.searchProvider
        })
      });

      const data = await response.json();

      if (data.success) {
        setIsConfigured(data.configured);
        if (data.configured) {
          setCandidates(data.candidates || []);
          // Auto-select all returned candidates
          const allUrls = new Set<string>((data.candidates || []).map((c: any) => c.websiteUrl));
          setSelectedCandidateUrls(allUrls);
          if ((data.candidates || []).length === 0) {
            onShowToast("No businesses matched all filters. Try lowering the minimum Fit Score or broadening keywords.", "info");
          } else {
            onShowToast(`Found ${data.candidates.length} real public businesses. Review them, then run Analyze Prospect for verified fit scores.`, "success");
          }
        } else {
          const locText = [city.trim(), stateRegion.trim(), effectiveCountry !== "Worldwide / Any Country" ? effectiveCountry : ""].filter(Boolean).join(" ");
          setSuggestedQueries(
            data.suggestedQueries || [
              `${activeNiche} ${locText} "work with me" OR "contact"`,
              `${activeNiche} ${locText} "courses" OR "programs"`,
              `${activeNiche} ${locText} site:*.com "book a call"`
            ]
          );
        }
      } else {
        onShowToast(data.error || "Search error occurred", "error");
      }
    } catch (err: any) {
      console.error(err);
      onShowToast("Failed to connect to discovery service", "error");
    } finally {
      setIsLoading(false);
    }
  };

  const toggleSelectCandidate = (url: string) => {
    const next = new Set(selectedCandidateUrls);
    if (next.has(url)) {
      next.delete(url);
    } else {
      next.add(url);
    }
    setSelectedCandidateUrls(next);
  };

  const handleAddSelectedToCRM = () => {
    const toAdd = candidates.filter((c) => selectedCandidateUrls.has(c.websiteUrl));
    if (toAdd.length === 0) {
      onShowToast("Please select at least one prospect to add", "info");
      return;
    }

    const newProspects: Prospect[] = toAdd.map((c, idx) => {
      const estScore = typeof c.estimatedFitScore === "number" ? c.estimatedFitScore : 0;
      const fitClass: FitClassification = c.fitClassification || "Insufficient Information";
      return {
        id: `prospect-discovered-${Date.now()}-${idx}`,
        businessName: c.businessName,
        websiteUrl: c.websiteUrl,
        contactName: c.contactName || "Founder",
        niche: c.niche,
        country: c.country,
        stateRegion: c.stateRegion || stateRegion.trim() || undefined,
        city: c.city || city.trim() || undefined,
        notes: c.notes || `Discovered via Prospect Finder (${activeNiche})`,
        publicBusinessInfo: c.publicBusinessInfo,
        status: "Not Contacted",
        fitClassification: fitClass,
        analysis: {
          opportunityScore: estScore,
          fitScore: estScore,
          fitClassification: fitClass,
          potentialProblems: [],
          platformSolvingFeatures: [],
          systemeSolvingFeatures: [],
          systemeFitReasoning: "Discovery found a real public business website. Run Analyze Prospect to verify the website and determine actual fit.",
          fitReasons: [],
          recommendedOutreachAngle: "Verify the prospect's public marketing workflow before personalizing outreach.",
          assumptions: ["Fit has not been verified yet. Run Analyze Prospect to score the prospect from public website evidence."],
          observedFacts: c.publicBusinessInfo ? [c.publicBusinessInfo.slice(0, 240)] : [],
          evidenceSources: [{ sourceUrl: c.sourceUrl, pageSection: "Live public search result", observation: c.notes || "Candidate discovered through live public web search.", timestamp: new Date().toISOString() }]
        },
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString(),
        history: [
          {
            date: new Date().toISOString(),
            action: `Discovered & added to CRM via Prospect Finder (${activeNiche})`
          }
        ]
      };
    });

    onAddProspects(newProspects);
    onShowToast(`Successfully added ${newProspects.length} prospects to your CRM!`, "success");
    onClose();
  };

  const handleQuickAddManually = (e: React.FormEvent) => {
    e.preventDefault();
    if (!quickAddName.trim()) {
      onShowToast("Please enter a business name", "error");
      return;
    }

    const estScore = 0;
    const fitClass: FitClassification = "Insufficient Information";
    const locationSummary = [city.trim(), stateRegion.trim(), effectiveCountry !== "Worldwide / Any Country" ? effectiveCountry : ""].filter(Boolean).join(", ");
    const newProspect: Prospect = {
      id: `prospect-discovered-manual-${Date.now()}`,
      businessName: quickAddName.trim(),
      websiteUrl: quickAddUrl.trim() || "",
      contactName: "Founder",
      niche: activeNiche,
      country: effectiveCountry,
      stateRegion: stateRegion.trim() || undefined,
      city: city.trim() || undefined,
      notes: `Discovered from public query: ${activeNiche}${locationSummary ? ` in ${locationSummary}` : ""}`,
      publicBusinessInfo: "",
      status: "Not Contacted",
      fitClassification: fitClass,
      analysis: {
        opportunityScore: estScore,
        fitScore: estScore,
        fitClassification: fitClass,
        potentialProblems: [],
        platformSolvingFeatures: [],
        systemeSolvingFeatures: [],
        systemeFitReasoning: "Insufficient public information. Analyze the website before making a fit recommendation.",
        fitReasons: [],
        recommendedOutreachAngle: "Verify the public business workflow before personalizing outreach.",
        assumptions: [],
        evidenceSources: quickAddUrl.trim() ? [{ sourceUrl: quickAddUrl.trim(), pageSection: "User-supplied public website", observation: "Website supplied for later public verification.", timestamp: new Date().toISOString() }] : []
      },
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
      history: [
        {
          date: new Date().toISOString(),
          action: "Added via Public Discovery Assistant"
        }
      ]
    };

    onAddProspects([newProspect]);
    onShowToast(`Added "${quickAddName}" to CRM!`, "success");
    setQuickAddName("");
    setQuickAddUrl("");
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-slate-950/60 backdrop-blur-xs overflow-y-auto">
      <div
        id="find-prospects-modal"
        className="w-full max-w-2xl bg-white dark:bg-slate-900 rounded-3xl border border-slate-200/80 dark:border-slate-800 shadow-2xl overflow-hidden my-auto animate-in fade-in zoom-in-95 duration-200 max-h-[92vh] flex flex-col"
      >
        {/* Header */}
        <div className="flex items-center justify-between px-5 sm:px-6 py-4 border-b border-slate-100 dark:border-slate-800 shrink-0">
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-xl bg-indigo-50 dark:bg-indigo-950/70 text-indigo-600 dark:text-indigo-400 flex items-center justify-center">
              <Search className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-base font-bold text-slate-900 dark:text-white">
                Find Prospects
              </h2>
              <p className="text-xs text-slate-500 dark:text-slate-400">
                Ethical discovery using legitimate public business information
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-2 rounded-xl text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Scrollable Content */}
        <div className="p-5 sm:p-6 overflow-y-auto space-y-6 flex-1">
          {/* Search Form */}
          <form onSubmit={handleSearch} className="space-y-4">
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
              {/* Target Country */}
              <div>
                <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1.5 flex items-center gap-1.5">
                  <Globe className="w-3.5 h-3.5 text-indigo-500" />
                  <span>Country (Worldwide)</span>
                </label>
                <select
                  value={country}
                  onChange={(e) => setCountry(e.target.value)}
                  className="w-full text-xs sm:text-sm py-2.5 px-3 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-900 dark:text-white focus:ring-2 focus:ring-indigo-500 min-h-[44px]"
                >
                  {COUNTRIES.map((c) => (
                    <option key={c} value={c}>
                      {c}
                    </option>
                  ))}
                  <option value="Custom">Type another country...</option>
                </select>
                {country === "Custom" && (
                  <input
                    type="text"
                    value={customCountry}
                    onChange={(e) => setCustomCountry(e.target.value)}
                    placeholder="Enter any country (e.g. UAE, Pakistan, Germany)"
                    className="w-full text-xs sm:text-sm py-2 px-3 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-900 dark:text-white focus:ring-2 focus:ring-indigo-500 min-h-[40px] mt-1.5"
                  />
                )}
              </div>

              {/* State / Province / Region */}
              <div>
                <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1.5 flex items-center gap-1.5">
                  <MapPin className="w-3.5 h-3.5 text-indigo-500" />
                  <span>State / Province / Region (Optional)</span>
                </label>
                <input
                  type="text"
                  value={stateRegion}
                  onChange={(e) => setStateRegion(e.target.value)}
                  placeholder="e.g. California, Ontario, Punjab, Dubai"
                  className="w-full text-xs sm:text-sm py-2.5 px-3 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-900 dark:text-white focus:ring-2 focus:ring-indigo-500 min-h-[44px]"
                />
              </div>

              {/* City */}
              <div>
                <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1.5 flex items-center gap-1.5">
                  <MapPin className="w-3.5 h-3.5 text-indigo-500" />
                  <span>City (Optional)</span>
                </label>
                <input
                  type="text"
                  value={city}
                  onChange={(e) => setCity(e.target.value)}
                  placeholder="e.g. Austin, London, Toronto, Sydney"
                  className="w-full text-xs sm:text-sm py-2.5 px-3 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-900 dark:text-white focus:ring-2 focus:ring-indigo-500 min-h-[44px]"
                />
              </div>
            </div>

            {/* Business Niche */}
            <div>
              <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1.5 flex items-center gap-1.5">
                <Building2 className="w-3.5 h-3.5 text-indigo-500" />
                <span>Business Niche</span>
              </label>
              <select
                value={niche}
                onChange={(e) => setNiche(e.target.value)}
                className="w-full text-xs sm:text-sm py-2.5 px-3 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-900 dark:text-white focus:ring-2 focus:ring-indigo-500 min-h-[44px]"
              >
                {NICHES.map((n) => (
                  <option key={n} value={n}>
                    {n}
                  </option>
                ))}
                <option value="Custom">Custom niche...</option>
              </select>

              {niche === "Custom" && (
                <input
                  type="text"
                  value={customNiche}
                  onChange={(e) => setCustomNiche(e.target.value)}
                  placeholder="e.g. Real Estate Investors, Yoga Instructors"
                  className="w-full text-xs sm:text-sm py-2.5 px-3 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-900 dark:text-white focus:ring-2 focus:ring-indigo-500 min-h-[44px] mt-2"
                />
              )}
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
              {/* Desired Count */}
              <div>
                <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1.5">
                  Number Desired
                </label>
                <select
                  value={desiredCount}
                  onChange={(e) => setDesiredCount(parseInt(e.target.value, 10))}
                  className="w-full text-xs sm:text-sm py-2.5 px-3 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-900 dark:text-white focus:ring-2 focus:ring-indigo-500 min-h-[44px]"
                >
                  <option value={3}>3 prospects</option>
                  <option value={5}>5 prospects</option>
                  <option value={10}>10 prospects</option>
                  <option value={15}>15 prospects</option>
                </select>
              </div>

              {/* Minimum Fit Score */}
              <div>
                <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1.5">
                  Minimum Fit Score ({minFitScore})
                </label>
                <select
                  value={minFitScore}
                  onChange={(e) => setMinFitScore(parseInt(e.target.value, 10))}
                  className="w-full text-xs sm:text-sm py-2.5 px-3 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-900 dark:text-white focus:ring-2 focus:ring-indigo-500 min-h-[44px]"
                >
                  <option value={50}>50+ (Possible)</option>
                  <option value={65}>65+ (Good Potential)</option>
                  <option value={80}>80+ (Strong Potential)</option>
                </select>
              </div>

              {/* Optional Keywords */}
              <div>
                <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1.5">
                  Keywords (Optional)
                </label>
                <input
                  type="text"
                  value={keywords}
                  onChange={(e) => setKeywords(e.target.value)}
                  placeholder="e.g. membership, courses"
                  className="w-full text-xs sm:text-sm py-2.5 px-3 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-900 dark:text-white focus:ring-2 focus:ring-indigo-500 min-h-[44px]"
                />
              </div>
            </div>

            {/* Submit Action */}
            <div className="flex items-center justify-between pt-2">
              <div className="flex items-center gap-1.5 text-xs text-slate-500">
                <ShieldCheck className="w-4 h-4 text-emerald-500" />
                <span>Zero scraping. Only verified public search.</span>
              </div>

              <button
                type="submit"
                disabled={isLoading}
                id="execute-find-prospects-btn"
                className="flex items-center gap-2 px-5 py-2.5 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white text-xs font-bold shadow-md shadow-indigo-600/25 transition-all min-h-[44px] disabled:opacity-50"
              >
                {isLoading ? (
                  <>
                    <Loader2 className="w-4 h-4 animate-spin" />
                    <span>Searching Public Web...</span>
                  </>
                ) : (
                  <>
                    <Search className="w-4 h-4" />
                    <span>Discover Prospects</span>
                  </>
                )}
              </button>
            </div>
          </form>

          {/* RESULTS AREA */}
          {hasSearched && (
            <div className="pt-4 border-t border-slate-100 dark:border-slate-800 space-y-4">
              {/* CASE 1: SEARCH PROVIDER NOT CONFIGURED IN SETTINGS */}
              {isConfigured === false && (
                <div className="p-4 sm:p-5 rounded-2xl bg-amber-50/70 dark:bg-amber-950/40 border border-amber-200 dark:border-amber-900/60 space-y-4">
                  <div className="flex items-start gap-3">
                    <div className="p-2 rounded-xl bg-amber-100 dark:bg-amber-900/50 text-amber-700 dark:text-amber-300 shrink-0">
                      <Key className="w-5 h-5" />
                    </div>
                    <div className="space-y-1">
                      <h4 className="text-sm font-bold text-amber-900 dark:text-amber-200">
                        Search / Data Provider Setup Required
                      </h4>
                      <p className="text-xs text-amber-800 dark:text-amber-300/90 leading-relaxed">
                        To automatically fetch live web results from within the app, OutreachPilot uses your configured Google Custom Search API or SerpApi key. We strictly never fabricate mock business data.
                      </p>
                    </div>
                  </div>

                  <div className="flex flex-wrap items-center gap-3">
                    <button
                      type="button"
                      onClick={() => {
                        onClose();
                        onNavigateToSettings();
                      }}
                      className="flex items-center gap-1.5 px-4 py-2 rounded-xl bg-amber-600 hover:bg-amber-700 text-white text-xs font-bold shadow-sm transition-all min-h-[44px]"
                    >
                      <Key className="w-4 h-4" />
                      <span>Configure Search Provider in Settings</span>
                    </button>
                  </div>

                  {/* Public Search Assistant: Ready-to-Run Queries */}
                  <div className="mt-4 pt-4 border-t border-amber-200/60 dark:border-amber-900/40 space-y-3">
                    <div className="flex items-center justify-between">
                      <h5 className="text-xs font-bold text-slate-800 dark:text-slate-200">
                        Instant Public Search Queries (Open in Google/Bing):
                      </h5>
                      <span className="text-[11px] text-slate-500">Click to search live</span>
                    </div>

                    <div className="space-y-2">
                      {suggestedQueries.map((q, idx) => {
                        const searchUrl = `https://www.google.com/search?q=${encodeURIComponent(q)}`;
                        return (
                          <div
                            key={idx}
                            className="flex items-center justify-between gap-2 p-2.5 rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 text-xs"
                          >
                            <span className="font-mono text-slate-700 dark:text-slate-300 truncate">
                              {q}
                            </span>
                            <div className="flex items-center gap-1.5 shrink-0">
                              <button
                                type="button"
                                onClick={() => {
                                  navigator.clipboard.writeText(q);
                                  onShowToast("Search query copied to clipboard!", "success");
                                }}
                                title="Copy search query"
                                className="p-1.5 rounded-lg text-slate-500 hover:bg-slate-100 dark:hover:bg-slate-800"
                              >
                                <Copy className="w-3.5 h-3.5" />
                              </button>
                              <a
                                href={searchUrl}
                                target="_blank"
                                rel="noreferrer"
                                className="flex items-center gap-1 px-2.5 py-1 rounded-lg bg-indigo-50 dark:bg-indigo-950/60 text-indigo-600 dark:text-indigo-400 font-semibold hover:bg-indigo-100 text-[11px]"
                              >
                                <span>Search</span>
                                <ExternalLink className="w-3 h-3" />
                              </a>
                            </div>
                          </div>
                        );
                      })}
                    </div>

                    {/* Quick-add found prospect */}
                    <form
                      onSubmit={handleQuickAddManually}
                      className="mt-3 p-3 rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 space-y-2"
                    >
                      <span className="block text-xs font-bold text-slate-800 dark:text-slate-200">
                        Quick Add from Found Search Result:
                      </span>
                      <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                        <input
                          type="text"
                          value={quickAddName}
                          onChange={(e) => setQuickAddName(e.target.value)}
                          placeholder="Business Name (e.g. Elevate Nutrition)"
                          className="px-3 py-2 text-xs rounded-lg bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-900 dark:text-white"
                          required
                        />
                        <input
                          type="url"
                          value={quickAddUrl}
                          onChange={(e) => setQuickAddUrl(e.target.value)}
                          placeholder="Website URL (e.g. https://elevatenutrition.com)"
                          className="px-3 py-2 text-xs rounded-lg bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-900 dark:text-white"
                        />
                      </div>
                      <div className="flex justify-end">
                        <button
                          type="submit"
                          className="flex items-center gap-1 px-3 py-1.5 rounded-lg bg-indigo-600 hover:bg-indigo-700 text-white text-xs font-bold"
                        >
                          <Plus className="w-3.5 h-3.5" />
                          <span>Add to CRM</span>
                        </button>
                      </div>
                    </form>
                  </div>
                </div>
              )}

              {/* CASE 2: SEARCH RETURNED CANDIDATES */}
              {isConfigured && candidates.length > 0 && (
                <div className="space-y-3">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      <span className="text-xs font-bold text-slate-900 dark:text-white">
                        Discovered Public Candidates ({candidates.length})
                      </span>
                      <span className="text-[11px] text-slate-500">
                        ({selectedCandidateUrls.size} selected)
                      </span>
                    </div>

                    <button
                      type="button"
                      onClick={() => {
                        if (selectedCandidateUrls.size === candidates.length) {
                          setSelectedCandidateUrls(new Set());
                        } else {
                          setSelectedCandidateUrls(new Set(candidates.map((c) => c.websiteUrl)));
                        }
                      }}
                      className="text-xs text-indigo-600 dark:text-indigo-400 font-semibold hover:underline"
                    >
                      {selectedCandidateUrls.size === candidates.length ? "Deselect All" : "Select All"}
                    </button>
                  </div>

                  <div className="space-y-2.5 max-h-72 overflow-y-auto pr-1">
                    {candidates.map((cand) => {
                      const isSelected = selectedCandidateUrls.has(cand.websiteUrl);
                      const est = cand.estimatedFitScore || 70;
                      return (
                        <div
                          key={cand.websiteUrl}
                          onClick={() => toggleSelectCandidate(cand.websiteUrl)}
                          className={`p-3.5 rounded-2xl border transition-all cursor-pointer flex items-start gap-3 ${
                            isSelected
                              ? "bg-indigo-50/70 dark:bg-indigo-950/40 border-indigo-300 dark:border-indigo-800"
                              : "bg-white dark:bg-slate-900 border-slate-200 dark:border-slate-800 hover:border-slate-300"
                          }`}
                        >
                          <input
                            type="checkbox"
                            checked={isSelected}
                            onChange={() => {}}
                            className="mt-1 w-4 h-4 text-indigo-600 rounded border-slate-300 focus:ring-indigo-500"
                          />

                          <div className="flex-1 min-w-0">
                            <div className="flex items-center justify-between gap-2">
                              <h5 className="text-xs font-bold text-slate-900 dark:text-white truncate">
                                {cand.businessName}
                              </h5>
                              <span
                                className={`text-[10px] px-2 py-0.5 rounded-full font-bold shrink-0 ${
                                  est >= 80
                                    ? "bg-emerald-100 text-emerald-800 dark:bg-emerald-950/70 dark:text-emerald-300"
                                    : est >= 65
                                    ? "bg-indigo-100 text-indigo-800 dark:bg-indigo-950/70 dark:text-indigo-300"
                                    : "bg-amber-100 text-amber-800 dark:bg-amber-950/70 dark:text-amber-300"
                                }`}
                              >
                                {est}/100 Fit
                              </span>
                            </div>

                            <a
                              href={cand.websiteUrl}
                              target="_blank"
                              rel="noreferrer"
                              onClick={(e) => e.stopPropagation()}
                              className="text-[11px] text-indigo-600 dark:text-indigo-400 hover:underline flex items-center gap-1 mt-0.5 truncate"
                            >
                              <span className="truncate">{cand.websiteUrl}</span>
                              <ExternalLink className="w-2.5 h-2.5 shrink-0" />
                            </a>

                            {cand.notes && (
                              <p className="text-[11px] text-slate-500 dark:text-slate-400 mt-1 line-clamp-2 leading-relaxed">
                                {cand.notes}
                              </p>
                            )}
                          </div>
                        </div>
                      );
                    })}
                  </div>

                  <div className="pt-2 flex justify-end">
                    <button
                      type="button"
                      onClick={handleAddSelectedToCRM}
                      disabled={selectedCandidateUrls.size === 0}
                      className="flex items-center gap-2 px-5 py-2.5 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white text-xs font-bold shadow-md shadow-indigo-600/25 transition-all min-h-[44px] disabled:opacity-50"
                    >
                      <Plus className="w-4 h-4" />
                      <span>Add Selected ({selectedCandidateUrls.size}) to CRM</span>
                    </button>
                  </div>
                </div>
              )}
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
